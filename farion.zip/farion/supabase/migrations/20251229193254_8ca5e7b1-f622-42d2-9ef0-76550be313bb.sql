-- Add donation support to meme_uploads
ALTER TABLE meme_uploads ADD COLUMN IF NOT EXISTS donation_amount numeric DEFAULT 0;
ALTER TABLE meme_uploads ADD COLUMN IF NOT EXISTS donation_tx_signature text;

-- Create user activity log for dashboard
CREATE TABLE IF NOT EXISTS user_activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address TEXT NOT NULL,
  activity_type TEXT NOT NULL,
  details JSONB,
  amount NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on user_activity_log
ALTER TABLE user_activity_log ENABLE ROW LEVEL SECURITY;

-- Create policies for user_activity_log
CREATE POLICY "Allow public insert on user_activity_log" 
ON user_activity_log 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public read on user_activity_log" 
ON user_activity_log 
FOR SELECT 
USING (true);

-- Enable realtime for user_activity_log
ALTER PUBLICATION supabase_realtime ADD TABLE user_activity_log;