-- Add column to store encrypted mint keypair for real SPL token minting
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS encrypted_mint_keypair TEXT;

-- Add column to track if tokens have been minted on-chain
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS tokens_minted_onchain BOOLEAN DEFAULT FALSE;

-- Add column for the actual mint address (different from contract_address which is vanity)
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS actual_token_mint TEXT;