-- Create referral tasks table
CREATE TABLE public.referral_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  task_type TEXT NOT NULL CHECK (task_type IN ('twitter_follow', 'community_join', 'twitter_posts')),
  requirements JSONB NOT NULL,
  min_reward NUMERIC NOT NULL DEFAULT 5,
  max_reward NUMERIC NOT NULL DEFAULT 50,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user task submissions table
CREATE TABLE public.user_task_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  task_id UUID NOT NULL REFERENCES public.referral_tasks(id) ON DELETE CASCADE,
  submission_data JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  admin_notes TEXT,
  submitted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  reviewed_at TIMESTAMP WITH TIME ZONE,
  reviewed_by TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, task_id)
);

-- Create user rewards table
CREATE TABLE public.user_rewards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  task_submission_id UUID NOT NULL REFERENCES public.user_task_submissions(id) ON DELETE CASCADE,
  reward_amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'distributed', 'failed')),
  transaction_hash TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.referral_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_task_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_rewards ENABLE ROW LEVEL SECURITY;

-- RLS Policies for referral_tasks
CREATE POLICY "Tasks are viewable by everyone" 
ON public.referral_tasks 
FOR SELECT 
USING (is_active = true);

-- RLS Policies for user_task_submissions
CREATE POLICY "Users can view their own submissions" 
ON public.user_task_submissions 
FOR SELECT 
USING (wallet_address = wallet_address);

CREATE POLICY "Users can create their own submissions" 
ON public.user_task_submissions 
FOR INSERT 
WITH CHECK (wallet_address = wallet_address);

CREATE POLICY "Users can update their own submissions" 
ON public.user_task_submissions 
FOR UPDATE 
USING (wallet_address = wallet_address);

-- RLS Policies for user_rewards
CREATE POLICY "Users can view their own rewards" 
ON public.user_rewards 
FOR SELECT 
USING (wallet_address = wallet_address);

-- Create triggers for updated_at
CREATE TRIGGER update_referral_tasks_updated_at
BEFORE UPDATE ON public.referral_tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_task_submissions_updated_at
BEFORE UPDATE ON public.user_task_submissions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_rewards_updated_at
BEFORE UPDATE ON public.user_rewards
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default tasks
INSERT INTO public.referral_tasks (title, description, task_type, requirements, min_reward, max_reward) VALUES
(
  'Follow @auklora on X',
  'Follow our official X account to stay updated with the latest news and announcements.',
  'twitter_follow',
  '{"twitter_url": "https://x.com/auklora", "account_handle": "@auklora"}'::jsonb,
  5,
  50
),
(
  'Join AUKLORA X Community',
  'Join our X community and stay active for at least 24 hours to complete this task.',
  'community_join',
  '{"community_url": "https://x.com/i/communities/1942521754447917339", "required_duration_hours": 24}'::jsonb,
  5,
  50
),
(
  'Post about AUKLORA on X',
  'Create 3 posts on X mentioning #AUKLORA, $AUK, or tagging @auklora to spread the word!',
  'twitter_posts',
  '{"required_posts": 3, "required_tags": ["#AUKLORA", "$AUK", "@auklora"], "min_posts": 3}'::jsonb,
  5,
  50
);