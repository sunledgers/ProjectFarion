-- Create function to get or create active jackpot round
CREATE OR REPLACE FUNCTION get_or_create_active_jackpot_round()
RETURNS UUID AS $$
DECLARE
    active_round_id UUID;
    new_round_number INTEGER;
BEGIN
    -- Try to find an existing active round
    SELECT id INTO active_round_id
    FROM jackpot_rounds
    WHERE status IN ('waiting', 'active')
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- If no active round exists, create a new one
    IF active_round_id IS NULL THEN
        -- Get the next round number
        SELECT COALESCE(MAX(round_number), 0) + 1 INTO new_round_number
        FROM jackpot_rounds;
        
        -- Create new round
        INSERT INTO jackpot_rounds (
            round_number,
            status,
            total_pot,
            participant_count,
            min_participants,
            min_bet_amount
        ) VALUES (
            new_round_number,
            'waiting',
            0,
            0,
            5,
            0.01
        ) RETURNING id INTO active_round_id;
    END IF;
    
    RETURN active_round_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;