-- Create initial Powerball round for testing (without conflict handling)
INSERT INTO powerball_rounds (
  round_number,
  status,
  volume_threshold,
  current_volume,
  prize_pool,
  creator_fee,
  participant_count,
  ends_at
) 
SELECT 1, 'waiting', 10000, 0, 0, 0, 0, now() + INTERVAL '6 hours'
WHERE NOT EXISTS (SELECT 1 FROM powerball_rounds WHERE status IN ('waiting', 'active'));