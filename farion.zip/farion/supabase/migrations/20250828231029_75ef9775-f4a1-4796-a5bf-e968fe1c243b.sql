-- Update NFT collections to support new permanent structure
-- First, clear existing test data and rebuild with new requirements

-- Delete existing data 
DELETE FROM nft_purchases;
DELETE FROM nft_collections;

-- Add purchased_by field to track ownership
ALTER TABLE nft_collections ADD COLUMN purchased_by_wallet text;
ALTER TABLE nft_collections ADD COLUMN purchased_at timestamp with time zone;

-- Remove duration-based logic from NFT system
ALTER TABLE nft_purchases DROP COLUMN IF EXISTS expires_at;
ALTER TABLE nft_collections DROP COLUMN IF EXISTS boost_duration;

-- Seed 50 new permanent NFT items with realistic values
INSERT INTO nft_collections (name, description, boost_type, boost_value, price_sol, rarity, is_available) VALUES

-- APY Boost NFTs (15 items) - 5% to 25% realistic percentage boosts
('Staking Master', 'Increases staking APY by 5% permanently', 'staking_apy', 5, 0.5, 'common', true),
('Yield Hunter', 'Boosts staking returns by 8% forever', 'staking_apy', 8, 0.8, 'common', true),
('Interest Amplifier', 'Permanent 10% APY increase', 'staking_apy', 10, 1.2, 'rare', true),
('Compound King', '12% APY boost that never expires', 'staking_apy', 12, 1.5, 'rare', true),
('Staking Legend', 'Legendary 15% APY enhancement', 'staking_apy', 15, 1.8, 'epic', true),
('APY Dominator', 'Elite 18% staking boost', 'staking_apy', 18, 2.0, 'epic', true),
('Yield Titan', 'Massive 20% APY increase', 'staking_apy', 20, 2.2, 'legendary', true),
('Staking Godmode', 'Ultimate 22% APY boost', 'staking_apy', 22, 2.3, 'legendary', true),
('Interest Oracle', 'Divine 25% APY enhancement', 'staking_apy', 25, 2.5, 'legendary', true),
('Compound Beast', '7% APY boost for steady gains', 'staking_apy', 7, 0.7, 'common', true),
('Yield Optimizer', '9% APY increase for smart investors', 'staking_apy', 9, 1.0, 'common', true),
('Staking Wizard', 'Magical 13% APY enhancement', 'staking_apy', 13, 1.6, 'rare', true),
('APY Overlord', 'Powerful 16% staking boost', 'staking_apy', 16, 1.9, 'epic', true),
('Interest Sovereign', 'Royal 19% APY increase', 'staking_apy', 19, 2.1, 'epic', true),
('Yield Supremacy', 'Supreme 24% APY boost', 'staking_apy', 24, 2.4, 'legendary', true),

-- Jackpot Lucky Boost NFTs (20 items) - 0.1% to 2% luck percentage  
('Lucky Charm', 'Increases jackpot luck by 0.1%', 'jackpot_luck', 0.1, 0.1, 'common', true),
('Fortune Cookie', '0.2% boost to jackpot chances', 'jackpot_luck', 0.2, 0.15, 'common', true),
('Rabbit Foot', 'Permanent 0.3% luck increase', 'jackpot_luck', 0.3, 0.2, 'common', true),
('Horseshoe', '0.4% jackpot luck enhancement', 'jackpot_luck', 0.4, 0.25, 'common', true),
('Four Leaf Clover', '0.5% luck boost forever', 'jackpot_luck', 0.5, 0.3, 'rare', true),
('Lucky Penny', '0.6% jackpot advantage', 'jackpot_luck', 0.6, 0.4, 'rare', true),
('Magic 8-Ball', '0.7% luck enhancement', 'jackpot_luck', 0.7, 0.5, 'rare', true),
('Crystal Ball', '0.8% jackpot luck boost', 'jackpot_luck', 0.8, 0.6, 'rare', true),
('Golden Ticket', '0.9% permanent luck increase', 'jackpot_luck', 0.9, 0.7, 'epic', true),
('Lucky Star', '1.0% jackpot enhancement', 'jackpot_luck', 1.0, 0.8, 'epic', true),
('Fortune Talisman', '1.1% luck multiplier', 'jackpot_luck', 1.1, 0.9, 'epic', true),
('Blessed Amulet', '1.2% jackpot advantage', 'jackpot_luck', 1.2, 1.0, 'epic', true),
('Divine Favor', '1.3% luck from the gods', 'jackpot_luck', 1.3, 1.2, 'legendary', true),
('Cosmic Luck', '1.4% universal fortune', 'jackpot_luck', 1.4, 1.4, 'legendary', true),
('Fate Controller', '1.5% destiny manipulation', 'jackpot_luck', 1.5, 1.6, 'legendary', true),
('Probability Bender', '1.6% reality alteration', 'jackpot_luck', 1.6, 1.8, 'legendary', true),
('Quantum Luck', '1.7% multiverse advantage', 'jackpot_luck', 1.7, 2.0, 'legendary', true),
('Jackpot Magnet', '1.8% ultimate attraction', 'jackpot_luck', 1.8, 2.2, 'legendary', true),
('Fortune God', '1.9% divine intervention', 'jackpot_luck', 1.9, 2.3, 'legendary', true),
('Luck Incarnate', '2.0% maximum fortune', 'jackpot_luck', 2.0, 2.5, 'legendary', true),

-- Virtual World Coin Multipliers (15 items) - 2x to 5x multiplier
('Coin Collector', 'Doubles virtual world coins earned', 'coin_multiplier', 2, 0.3, 'common', true),
('Treasure Hunter', '2.2x coin earning multiplier', 'coin_multiplier', 2.2, 0.4, 'common', true),
('Gold Digger', '2.5x virtual coin boost', 'coin_multiplier', 2.5, 0.6, 'common', true),
('Wealth Builder', '2.8x coin generation', 'coin_multiplier', 2.8, 0.8, 'rare', true),
('Fortune Maker', '3x permanent coin boost', 'coin_multiplier', 3, 1.0, 'rare', true),
('Coin King', '3.2x virtual currency multiplier', 'coin_multiplier', 3.2, 1.2, 'rare', true),
('Golden Touch', '3.5x coin earning power', 'coin_multiplier', 3.5, 1.4, 'epic', true),
('Midas Blessing', '3.8x coin multiplication', 'coin_multiplier', 3.8, 1.6, 'epic', true),
('Treasure Tyrant', '4x virtual wealth boost', 'coin_multiplier', 4, 1.8, 'epic', true),
('Coin Emperor', '4.2x ultimate earning power', 'coin_multiplier', 4.2, 2.0, 'legendary', true),
('Wealth Incarnate', '4.5x divine coin blessing', 'coin_multiplier', 4.5, 2.2, 'legendary', true),
('Golden God', '4.8x supreme coin power', 'coin_multiplier', 4.8, 2.4, 'legendary', true),
('Infinite Wealth', '5x maximum coin multiplier', 'coin_multiplier', 5, 2.5, 'legendary', true),
('Money Magnet', '2.3x steady coin increase', 'coin_multiplier', 2.3, 0.5, 'common', true),
('Cash Flow', '2.7x improved earnings', 'coin_multiplier', 2.7, 0.7, 'common', true);

-- Update chat system to properly handle offline tracking
-- Set existing online users to offline who haven't been seen in 5 minutes
UPDATE user_sessions 
SET is_online = false 
WHERE last_seen < NOW() - INTERVAL '5 minutes';

-- Create trigger to automatically set users offline after inactivity
CREATE OR REPLACE FUNCTION update_user_offline_status()
RETURNS void AS $$
BEGIN
    UPDATE user_sessions 
    SET is_online = false 
    WHERE is_online = true 
    AND last_seen < NOW() - INTERVAL '5 minutes';
END;
$$ LANGUAGE plpgsql;

-- Create a function to be called periodically (every minute)
CREATE OR REPLACE FUNCTION cleanup_inactive_sessions()
RETURNS void AS $$
BEGIN
    PERFORM update_user_offline_status();
END;
$$ LANGUAGE plpgsql;