-- Add new columns for full Meteora DBC integration
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS pool_config_address text,
ADD COLUMN IF NOT EXISTS graduation_tx text,
ADD COLUMN IF NOT EXISTS creator_claimed_fees numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS initial_buy_sol numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS vanity_attempts integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS migration_status text DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS damm_pool_address text,
ADD COLUMN IF NOT EXISTS lp_mint_address text;

-- Add index for quick graduation checks
CREATE INDEX IF NOT EXISTS idx_launchpad_tokens_migration_status ON public.launchpad_tokens(migration_status);

-- Add index for creator wallet lookups
CREATE INDEX IF NOT EXISTS idx_launchpad_tokens_creator_wallet ON public.launchpad_tokens(creator_wallet);