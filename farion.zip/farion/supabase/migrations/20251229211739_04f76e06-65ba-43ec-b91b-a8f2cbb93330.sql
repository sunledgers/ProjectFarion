-- Add creator fee columns to launchpad_tokens
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS creator_fee_percentage numeric DEFAULT 0 CHECK (creator_fee_percentage >= 0 AND creator_fee_percentage <= 5),
ADD COLUMN IF NOT EXISTS creator_earnings numeric DEFAULT 0;

-- Add payout_status to escrow_transactions
ALTER TABLE public.escrow_transactions
ADD COLUMN IF NOT EXISTS payout_status text DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS payout_tx_signature text,
ADD COLUMN IF NOT EXISTS payout_processed_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS creator_fee numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS platform_fee numeric DEFAULT 0;