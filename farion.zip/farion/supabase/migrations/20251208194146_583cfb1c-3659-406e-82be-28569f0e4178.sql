-- Drop and recreate tables with correct schema

-- Update token_balances with missing columns
ALTER TABLE public.token_balances ADD COLUMN IF NOT EXISTS username TEXT;
ALTER TABLE public.token_balances ADD COLUMN IF NOT EXISTS auk_balance NUMERIC DEFAULT 0;
ALTER TABLE public.token_balances ADD COLUMN IF NOT EXISTS token_id TEXT;
ALTER TABLE public.token_balances RENAME COLUMN token_address TO token_id_old;
ALTER TABLE public.token_balances DROP COLUMN token_id_old;
ALTER TABLE public.token_balances ADD COLUMN IF NOT EXISTS token_balance NUMERIC DEFAULT 0;
DROP INDEX IF EXISTS token_balances_wallet_address_token_address_key;
CREATE UNIQUE INDEX IF NOT EXISTS token_balances_wallet_token_idx ON public.token_balances(wallet_address, token_id);

-- Update auk_claims with missing columns
ALTER TABLE public.auk_claims ADD COLUMN IF NOT EXISTS username TEXT;
ALTER TABLE public.auk_claims ADD COLUMN IF NOT EXISTS claim_amount NUMERIC;
ALTER TABLE public.auk_claims ADD COLUMN IF NOT EXISTS claimed_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- Update jackpot_participants with missing columns
ALTER TABLE public.jackpot_participants ADD COLUMN IF NOT EXISTS username TEXT;
ALTER TABLE public.jackpot_participants ADD COLUMN IF NOT EXISTS bet_amount NUMERIC;
ALTER TABLE public.jackpot_participants ADD COLUMN IF NOT EXISTS odds_percentage NUMERIC DEFAULT 0;
ALTER TABLE public.jackpot_participants ADD COLUMN IF NOT EXISTS joined_at TIMESTAMP WITH TIME ZONE DEFAULT now();
ALTER TABLE public.jackpot_participants ADD COLUMN IF NOT EXISTS transaction_verified BOOLEAN DEFAULT false;

-- Update powerball_rounds with missing columns
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS volume_threshold NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS current_volume NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS prize_pool NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS creator_fee NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS winner_username TEXT;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS started_at TIMESTAMP WITH TIME ZONE DEFAULT now();
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS participant_count INTEGER DEFAULT 0;
ALTER TABLE public.powerball_rounds ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- Update powerball_participants with missing columns
ALTER TABLE public.powerball_participants ADD COLUMN IF NOT EXISTS username TEXT;
ALTER TABLE public.powerball_participants ADD COLUMN IF NOT EXISTS token_balance NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_participants ADD COLUMN IF NOT EXISTS qualification_verified BOOLEAN DEFAULT false;
ALTER TABLE public.powerball_participants ADD COLUMN IF NOT EXISTS qualification_checked_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.powerball_participants ADD COLUMN IF NOT EXISTS joined_at TIMESTAMP WITH TIME ZONE DEFAULT now();

-- Update powerball_winners with missing columns
ALTER TABLE public.powerball_winners ADD COLUMN IF NOT EXISTS username TEXT;
ALTER TABLE public.powerball_winners ADD COLUMN IF NOT EXISTS prize_amount NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_winners ADD COLUMN IF NOT EXISTS volume_at_win NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_winners ADD COLUMN IF NOT EXISTS token_balance_at_win NUMERIC DEFAULT 0;
ALTER TABLE public.powerball_winners ADD COLUMN IF NOT EXISTS payout_completed BOOLEAN DEFAULT false;
ALTER TABLE public.powerball_winners ADD COLUMN IF NOT EXISTS payout_completed_at TIMESTAMP WITH TIME ZONE;

-- Update created_tokens with missing columns
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS creator_wallet_address TEXT;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS creator_username TEXT;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS logo_url TEXT;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS tax_percentage NUMERIC DEFAULT 0;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS total_supply NUMERIC DEFAULT 0;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS current_supply NUMERIC DEFAULT 0;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS holders_count INTEGER DEFAULT 0;
ALTER TABLE public.created_tokens ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- Update referral_tasks with missing columns
ALTER TABLE public.referral_tasks ADD COLUMN IF NOT EXISTS requirements JSONB DEFAULT '{}';
ALTER TABLE public.referral_tasks ADD COLUMN IF NOT EXISTS min_reward NUMERIC;
ALTER TABLE public.referral_tasks ADD COLUMN IF NOT EXISTS max_reward NUMERIC;

-- Update user_task_submissions with missing columns
ALTER TABLE public.user_task_submissions ADD COLUMN IF NOT EXISTS wallet_address TEXT;
ALTER TABLE public.user_task_submissions ADD COLUMN IF NOT EXISTS username TEXT;
ALTER TABLE public.user_task_submissions ADD COLUMN IF NOT EXISTS submission_data JSONB DEFAULT '{}';
ALTER TABLE public.user_task_submissions ADD COLUMN IF NOT EXISTS admin_notes TEXT;

-- Update user_rewards with missing columns
ALTER TABLE public.user_rewards ADD COLUMN IF NOT EXISTS transaction_hash TEXT;
ALTER TABLE public.user_rewards ADD COLUMN IF NOT EXISTS submission_id UUID REFERENCES public.user_task_submissions(id);

-- Update jackpot_rounds with missing columns for JackpotRound interface
ALTER TABLE public.jackpot_rounds ADD COLUMN IF NOT EXISTS participant_count INTEGER DEFAULT 0;
ALTER TABLE public.jackpot_rounds ADD COLUMN IF NOT EXISTS min_participants INTEGER DEFAULT 5;
ALTER TABLE public.jackpot_rounds ADD COLUMN IF NOT EXISTS min_bet_amount NUMERIC DEFAULT 0.01;
ALTER TABLE public.jackpot_rounds ADD COLUMN IF NOT EXISTS started_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.jackpot_rounds ADD COLUMN IF NOT EXISTS winner_username TEXT;

-- Create token_transactions table
CREATE TABLE IF NOT EXISTS public.token_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token_id TEXT NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT,
  transaction_type TEXT NOT NULL,
  token_amount NUMERIC NOT NULL,
  auk_amount NUMERIC NOT NULL,
  token_price NUMERIC NOT NULL,
  tax_amount NUMERIC DEFAULT 0,
  market_cap_before NUMERIC,
  market_cap_after NUMERIC,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.token_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read" ON public.token_transactions FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.token_transactions FOR INSERT WITH CHECK (true);