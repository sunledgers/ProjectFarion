-- Add escrow and real token tracking columns to launchpad_tokens
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS escrow_sol_balance numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_real_token boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS escrow_account text,
ADD COLUMN IF NOT EXISTS mint_authority text;

-- Create escrow_transactions table to track all SOL movements
CREATE TABLE IF NOT EXISTS public.escrow_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id uuid REFERENCES public.launchpad_tokens(id),
  wallet_address text NOT NULL,
  username text,
  transaction_type text NOT NULL, -- 'deposit' (buy), 'withdrawal' (sell), 'fee'
  sol_amount numeric NOT NULL,
  token_amount numeric,
  tx_signature text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.escrow_transactions ENABLE ROW LEVEL SECURITY;

-- RLS policies for escrow_transactions
CREATE POLICY "Allow public read escrow_transactions" 
ON public.escrow_transactions 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert escrow_transactions" 
ON public.escrow_transactions 
FOR INSERT 
WITH CHECK (true);