-- Insert default chat rooms
INSERT INTO public.chat_rooms (id, name, description, is_private) 
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'general', 'General discussion for the Farion community', false),
  ('22222222-2222-2222-2222-222222222222', 'trading', 'Trading signals and market discussion', false),
  ('33333333-3333-3333-3333-333333333333', 'memes', 'Share and discuss memes', false)
ON CONFLICT (id) DO NOTHING;

-- Create loans table for P2P collateral loans
CREATE TABLE IF NOT EXISTS public.loans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  borrower_wallet TEXT NOT NULL,
  borrower_username TEXT,
  collateral_sol NUMERIC NOT NULL,
  loan_amount_sol NUMERIC NOT NULL,
  interest_rate NUMERIC NOT NULL DEFAULT 5,
  duration_days INTEGER NOT NULL CHECK (duration_days >= 1 AND duration_days <= 14),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'repaid', 'defaulted', 'cancelled')),
  ltv_ratio NUMERIC NOT NULL,
  due_at TIMESTAMP WITH TIME ZONE,
  repaid_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on loans
ALTER TABLE public.loans ENABLE ROW LEVEL SECURITY;

-- RLS policies for loans
CREATE POLICY "Allow public read loans" ON public.loans FOR SELECT USING (true);
CREATE POLICY "Allow public insert loans" ON public.loans FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update loans" ON public.loans FOR UPDATE USING (true);

-- Create p2p_trades table for SOL-to-cash escrow
CREATE TABLE IF NOT EXISTS public.p2p_trades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  seller_wallet TEXT NOT NULL,
  seller_username TEXT,
  buyer_wallet TEXT,
  buyer_username TEXT,
  sol_amount NUMERIC NOT NULL,
  fiat_amount NUMERIC NOT NULL,
  fiat_currency TEXT NOT NULL DEFAULT 'USD',
  escrow_status TEXT NOT NULL DEFAULT 'open' CHECK (escrow_status IN ('open', 'locked', 'seller_confirmed', 'buyer_confirmed', 'completed', 'disputed', 'cancelled')),
  seller_confirmed BOOLEAN DEFAULT false,
  buyer_confirmed BOOLEAN DEFAULT false,
  payment_method TEXT,
  payment_details TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  locked_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on p2p_trades
ALTER TABLE public.p2p_trades ENABLE ROW LEVEL SECURITY;

-- RLS policies for p2p_trades
CREATE POLICY "Allow public read p2p_trades" ON public.p2p_trades FOR SELECT USING (true);
CREATE POLICY "Allow public insert p2p_trades" ON public.p2p_trades FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update p2p_trades" ON public.p2p_trades FOR UPDATE USING (true);