-- Create meme uploads table
CREATE TABLE public.meme_uploads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  filename TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  content_type TEXT NOT NULL,
  token_balance DECIMAL,
  supply_percentage DECIMAL,
  verification_status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.meme_uploads ENABLE ROW LEVEL SECURITY;

-- Create policies for meme uploads
CREATE POLICY "Meme uploads are viewable by everyone" 
ON public.meme_uploads 
FOR SELECT 
USING (true);

CREATE POLICY "Users can create their own meme uploads" 
ON public.meme_uploads 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own meme uploads" 
ON public.meme_uploads 
FOR UPDATE 
USING (wallet_address = wallet_address);

-- Create storage bucket for memes
INSERT INTO storage.buckets (id, name, public) VALUES ('memes', 'memes', true);

-- Create storage policies
CREATE POLICY "Meme images are publicly accessible" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'memes');

CREATE POLICY "Users can upload meme images" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'memes');

-- Create trigger for automatic timestamp updates on meme_uploads
CREATE TRIGGER update_meme_uploads_updated_at
BEFORE UPDATE ON public.meme_uploads
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();