-- Create user_profiles table
CREATE TABLE public.user_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL UNIQUE,
  username TEXT,
  custom_username TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create token_balances table
CREATE TABLE public.token_balances (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  token_address TEXT NOT NULL,
  balance NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(wallet_address, token_address)
);

-- Create auk_claims table
CREATE TABLE public.auk_claims (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  next_claim_available_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create chat_rooms table
CREATE TABLE public.chat_rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  is_private BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create chat_messages table
CREATE TABLE public.chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID REFERENCES public.chat_rooms(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  username TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_sessions table
CREATE TABLE public.user_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL UNIQUE,
  username TEXT,
  is_online BOOLEAN DEFAULT false,
  last_seen TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create jackpot_rounds table
CREATE TABLE public.jackpot_rounds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_number INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  total_pot NUMERIC DEFAULT 0,
  winner_address TEXT,
  ends_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create jackpot_participants table
CREATE TABLE public.jackpot_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID REFERENCES public.jackpot_rounds(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create jackpot_winners table
CREATE TABLE public.jackpot_winners (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID REFERENCES public.jackpot_rounds(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create powerball_rounds table
CREATE TABLE public.powerball_rounds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_number INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  total_pot NUMERIC DEFAULT 0,
  winner_address TEXT,
  ends_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create powerball_participants table
CREATE TABLE public.powerball_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID REFERENCES public.powerball_rounds(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create powerball_winners table
CREATE TABLE public.powerball_winners (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID REFERENCES public.powerball_rounds(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create created_tokens table
CREATE TABLE public.created_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  contract_address TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  symbol TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  creator_address TEXT NOT NULL,
  market_cap NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create referral_tasks table
CREATE TABLE public.referral_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  reward_amount NUMERIC NOT NULL,
  task_type TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_task_submissions table
CREATE TABLE public.user_task_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id TEXT NOT NULL,
  task_id UUID REFERENCES public.referral_tasks(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending',
  submitted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_rewards table
CREATE TABLE public.user_rewards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  reward_amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create function to get or create active jackpot round
CREATE OR REPLACE FUNCTION public.get_or_create_active_jackpot_round()
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  active_round_id UUID;
  new_round_number INTEGER;
BEGIN
  SELECT id INTO active_round_id FROM jackpot_rounds WHERE status = 'active' LIMIT 1;
  
  IF active_round_id IS NULL THEN
    SELECT COALESCE(MAX(round_number), 0) + 1 INTO new_round_number FROM jackpot_rounds;
    INSERT INTO jackpot_rounds (round_number, status, ends_at)
    VALUES (new_round_number, 'active', now() + interval '24 hours')
    RETURNING id INTO active_round_id;
  END IF;
  
  RETURN active_round_id;
END;
$$;

-- Enable RLS on all tables
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.token_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auk_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jackpot_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jackpot_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jackpot_winners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.powerball_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.powerball_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.powerball_winners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.created_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_task_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_rewards ENABLE ROW LEVEL SECURITY;

-- Create permissive policies for public read access (since this is a crypto app without auth)
CREATE POLICY "Allow public read" ON public.user_profiles FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.user_profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.user_profiles FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.token_balances FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.token_balances FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.token_balances FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.auk_claims FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.auk_claims FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.chat_rooms FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.chat_rooms FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.chat_messages FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.chat_messages FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.user_sessions FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.user_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.user_sessions FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.jackpot_rounds FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.jackpot_rounds FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.jackpot_rounds FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.jackpot_participants FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.jackpot_participants FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.jackpot_winners FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.jackpot_winners FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.powerball_rounds FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.powerball_rounds FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.powerball_rounds FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.powerball_participants FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.powerball_participants FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.powerball_winners FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.powerball_winners FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.created_tokens FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.created_tokens FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.created_tokens FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.referral_tasks FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.referral_tasks FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.user_task_submissions FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.user_task_submissions FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.user_task_submissions FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.user_rewards FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.user_rewards FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.user_rewards FOR UPDATE USING (true);