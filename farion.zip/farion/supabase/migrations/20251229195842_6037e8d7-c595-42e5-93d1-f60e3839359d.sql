-- Create token watchlist table
CREATE TABLE public.token_watchlist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  token_id UUID NOT NULL REFERENCES public.launchpad_tokens(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(wallet_address, token_id)
);

-- Enable Row Level Security
ALTER TABLE public.token_watchlist ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read their own watchlist
CREATE POLICY "Users can view their own watchlist"
ON public.token_watchlist
FOR SELECT
USING (true);

-- Allow users to add to their watchlist
CREATE POLICY "Users can add to watchlist"
ON public.token_watchlist
FOR INSERT
WITH CHECK (true);

-- Allow users to remove from their watchlist
CREATE POLICY "Users can remove from watchlist"
ON public.token_watchlist
FOR DELETE
USING (true);

-- Add index for faster lookups
CREATE INDEX idx_token_watchlist_wallet ON public.token_watchlist(wallet_address);
CREATE INDEX idx_token_watchlist_token ON public.token_watchlist(token_id);