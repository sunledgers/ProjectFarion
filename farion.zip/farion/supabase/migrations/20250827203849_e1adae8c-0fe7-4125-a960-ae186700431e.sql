-- Create NFT collections table to store 100+ different NFT boost items
CREATE TABLE public.nft_collections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  boost_type TEXT NOT NULL, -- 'coin_multiplier', 'staking_apy', 'xp_multiplier', 'rare_drop', 'energy_regen', 'building_speed', 'resource_gathering', 'pvp_advantage', 'exclusive_access', 'cosmetic'
  boost_value NUMERIC NOT NULL, -- The boost amount (e.g., 2.0 for 2x multiplier, 25 for 25% increase)
  boost_duration INTEGER, -- Duration in hours (null for permanent boosts)
  price_sol NUMERIC NOT NULL, -- Price in SOL (0.1 to 1.5)
  is_available BOOLEAN NOT NULL DEFAULT true,
  rarity TEXT NOT NULL DEFAULT 'common', -- 'common', 'rare', 'epic', 'legendary'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create NFT purchases table to track ownership and transfers
CREATE TABLE public.nft_purchases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nft_id UUID NOT NULL REFERENCES public.nft_collections(id),
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  purchase_price_sol NUMERIC NOT NULL,
  transaction_hash TEXT NOT NULL,
  purchased_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true,
  activated_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE
);

-- Create NFT boosts table for active boost effects
CREATE TABLE public.nft_boosts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  purchase_id UUID NOT NULL REFERENCES public.nft_purchases(id),
  wallet_address TEXT NOT NULL,
  boost_type TEXT NOT NULL,
  boost_value NUMERIC NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false,
  activated_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.nft_collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nft_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nft_boosts ENABLE ROW LEVEL SECURITY;

-- NFT Collections policies (viewable by everyone, no modifications by users)
CREATE POLICY "NFT collections are viewable by everyone" 
ON public.nft_collections 
FOR SELECT 
USING (true);

-- NFT Purchases policies
CREATE POLICY "NFT purchases are viewable by everyone" 
ON public.nft_purchases 
FOR SELECT 
USING (true);

CREATE POLICY "Users can create their own NFT purchases" 
ON public.nft_purchases 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own NFT purchases" 
ON public.nft_purchases 
FOR UPDATE 
USING (wallet_address = wallet_address);

-- NFT Boosts policies
CREATE POLICY "Users can view their own NFT boosts" 
ON public.nft_boosts 
FOR SELECT 
USING (wallet_address = wallet_address);

CREATE POLICY "Users can create their own NFT boosts" 
ON public.nft_boosts 
FOR INSERT 
WITH CHECK (wallet_address = wallet_address);

CREATE POLICY "Users can update their own NFT boosts" 
ON public.nft_boosts 
FOR UPDATE 
USING (wallet_address = wallet_address);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
NEW.updated_at = now();
RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_nft_collections_updated_at
BEFORE UPDATE ON public.nft_collections
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_nft_boosts_updated_at
BEFORE UPDATE ON public.nft_boosts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert 100+ NFT boost items with varied prices and effects
INSERT INTO public.nft_collections (name, description, boost_type, boost_value, boost_duration, price_sol, rarity) VALUES
-- Coin Multipliers (15 items)
('Bronze Coin Magnet', 'Increases in-game coin collection by 50%', 'coin_multiplier', 1.5, 168, 0.1, 'common'),
('Silver Coin Magnet', 'Doubles your in-game coin collection', 'coin_multiplier', 2.0, 168, 0.2, 'common'),
('Gold Coin Magnet', 'Triples your in-game coin collection', 'coin_multiplier', 3.0, 336, 0.4, 'rare'),
('Platinum Coin Magnet', '4x boost to in-game coin collection', 'coin_multiplier', 4.0, 504, 0.7, 'epic'),
('Diamond Coin Magnet', '5x boost to in-game coin collection', 'coin_multiplier', 5.0, null, 1.5, 'legendary'),
('Mystic Coin Aura', '2.5x coin collection with magical effects', 'coin_multiplier', 2.5, 336, 0.5, 'rare'),
('Ancient Coin Relic', '3.5x coin boost from ancient powers', 'coin_multiplier', 3.5, 504, 0.9, 'epic'),
('Celestial Coin Blessing', '4.5x coin boost blessed by the stars', 'coin_multiplier', 4.5, 720, 1.2, 'legendary'),
('Temporal Coin Flux', '6x coin boost manipulating time itself', 'coin_multiplier', 6.0, null, 1.4, 'legendary'),
('Quantum Coin Generator', '7x coin boost through quantum mechanics', 'coin_multiplier', 7.0, null, 1.5, 'legendary'),
('Elemental Coin Storm', '2.2x coin boost with elemental power', 'coin_multiplier', 2.2, 240, 0.3, 'common'),
('Ethereal Coin Wisp', '2.8x coin boost from ethereal realm', 'coin_multiplier', 2.8, 360, 0.6, 'rare'),
('Infernal Coin Forge', '3.2x coin boost forged in hellfire', 'coin_multiplier', 3.2, 480, 0.8, 'epic'),
('Arctic Coin Crystal', '1.8x coin boost with freezing effect', 'coin_multiplier', 1.8, 192, 0.25, 'common'),
('Volcanic Coin Eruption', '4.2x coin boost from volcanic energy', 'coin_multiplier', 4.2, 600, 1.1, 'epic'),

-- Staking APY Boosts (15 items)
('Basic Staking Enhancer', 'Increases staking APY by 10%', 'staking_apy', 10, 168, 0.15, 'common'),
('Advanced Staking Booster', 'Increases staking APY by 25%', 'staking_apy', 25, 336, 0.3, 'common'),
('Elite Staking Amplifier', 'Increases staking APY by 50%', 'staking_apy', 50, 504, 0.6, 'rare'),
('Master Staking Catalyst', 'Doubles your staking APY (+100%)', 'staking_apy', 100, 720, 1.0, 'epic'),
('Legendary Staking Oracle', 'Triples your staking APY (+200%)', 'staking_apy', 200, null, 1.3, 'legendary'),
('Compound Interest Engine', 'Increases staking APY by 75%', 'staking_apy', 75, 600, 0.8, 'rare'),
('Yield Farming Protocol', 'Increases staking APY by 150%', 'staking_apy', 150, 840, 1.15, 'epic'),
('DeFi Maximizer Pod', 'Increases staking APY by 300%', 'staking_apy', 300, null, 1.45, 'legendary'),
('Liquidity Mining Rig', 'Increases staking APY by 40%', 'staking_apy', 40, 480, 0.45, 'rare'),
('Validator Node Access', 'Increases staking APY by 120%', 'staking_apy', 120, 720, 0.95, 'epic'),
('Treasury Bond Multiplier', 'Increases staking APY by 20%', 'staking_apy', 20, 240, 0.25, 'common'),
('Smart Contract Optimizer', 'Increases staking APY by 60%', 'staking_apy', 60, 540, 0.65, 'rare'),
('Algorithmic Trading Bot', 'Increases staking APY by 180%', 'staking_apy', 180, 960, 1.25, 'epic'),
('Cross-Chain Bridge Access', 'Increases staking APY by 15%', 'staking_apy', 15, 192, 0.2, 'common'),
('Flash Loan Accelerator', 'Increases staking APY by 250%', 'staking_apy', 250, null, 1.4, 'legendary'),

-- XP Multipliers (12 items)
('XP Booster Charm', 'Increases experience gain by 50%', 'xp_multiplier', 1.5, 168, 0.12, 'common'),
('XP Amplification Ring', 'Doubles your experience gain', 'xp_multiplier', 2.0, 336, 0.28, 'common'),
('XP Mastery Medallion', 'Triples your experience gain', 'xp_multiplier', 3.0, 504, 0.55, 'rare'),
('XP Transcendence Orb', '4x experience gain boost', 'xp_multiplier', 4.0, null, 1.1, 'epic'),
('Scholar''s Wisdom Tome', '2.5x experience with ancient knowledge', 'xp_multiplier', 2.5, 360, 0.42, 'rare'),
('Mentor''s Guidance Scroll', '1.8x experience from wise teachings', 'xp_multiplier', 1.8, 240, 0.22, 'common'),
('Academy Graduate Badge', '3.5x experience from advanced studies', 'xp_multiplier', 3.5, 600, 0.85, 'epic'),
('Phoenix Feather of Learning', '5x experience reborn from knowledge', 'xp_multiplier', 5.0, null, 1.35, 'legendary'),
('Time Dilation Chamber', '2.2x experience through time manipulation', 'xp_multiplier', 2.2, 300, 0.35, 'common'),
('Neural Enhancement Chip', '3.2x experience through brain augmentation', 'xp_multiplier', 3.2, 480, 0.72, 'rare'),
('Enlightenment Crystal', '4.5x experience from spiritual awakening', 'xp_multiplier', 4.5, 720, 1.25, 'legendary'),
('Memory Palace Key', '2.8x experience through perfect recall', 'xp_multiplier', 2.8, 384, 0.48, 'rare'),

-- Rare Drop Rate Increases (10 items)
('Lucky Rabbit''s Foot', 'Increases rare drop chance by 10%', 'rare_drop', 10, 168, 0.18, 'common'),
('Fortune Teller''s Crystal', 'Increases rare drop chance by 25%', 'rare_drop', 25, 336, 0.38, 'rare'),
('Dragon''s Lucky Scale', 'Increases rare drop chance by 50%', 'rare_drop', 50, null, 0.95, 'epic'),
('Serendipity Charm', 'Increases rare drop chance by 15%', 'rare_drop', 15, 240, 0.24, 'common'),
('Treasure Hunter''s Map', 'Increases rare drop chance by 35%', 'rare_drop', 35, 480, 0.62, 'rare'),
('Pirate''s Lucky Doubloon', 'Increases rare drop chance by 40%', 'rare_drop', 40, 600, 0.78, 'epic'),
('Archaeologist''s Compass', 'Increases rare drop chance by 20%', 'rare_drop', 20, 312, 0.32, 'common'),
('Midas Touch Glove', 'Increases rare drop chance by 60%', 'rare_drop', 60, null, 1.2, 'legendary'),
('Prospector''s Pickaxe', 'Increases rare drop chance by 30%', 'rare_drop', 30, 420, 0.52, 'rare'),
('Ancient Relic Detector', 'Increases rare drop chance by 75%', 'rare_drop', 75, null, 1.4, 'legendary'),

-- Energy Regeneration (8 items)
('Energy Drink Formula', 'Regenerates energy 25% faster', 'energy_regen', 25, 168, 0.16, 'common'),
('Stamina Enhancement Serum', 'Regenerates energy 50% faster', 'energy_regen', 50, 336, 0.34, 'rare'),
('Eternal Vigor Elixir', 'Regenerates energy 100% faster', 'energy_regen', 100, null, 0.88, 'epic'),
('Lightning Rod Implant', 'Regenerates energy 75% faster', 'energy_regen', 75, 504, 0.66, 'rare'),
('Solar Panel Backpack', 'Regenerates energy 40% faster', 'energy_regen', 40, 384, 0.28, 'common'),
('Nuclear Battery Core', 'Regenerates energy 150% faster', 'energy_regen', 150, null, 1.25, 'legendary'),
('Wind Turbine Accessory', 'Regenerates energy 30% faster', 'energy_regen', 30, 288, 0.21, 'common'),
('Perpetual Motion Engine', 'Regenerates energy 200% faster', 'energy_regen', 200, null, 1.45, 'legendary'),

-- Building Speed Boosts (8 items)
('Construction Blueprint', 'Increases building speed by 20%', 'building_speed', 20, 168, 0.14, 'common'),
('Architect''s Drafting Tools', 'Increases building speed by 40%', 'building_speed', 40, 336, 0.31, 'rare'),
('Master Builder''s Hammer', 'Increases building speed by 75%', 'building_speed', 75, null, 0.82, 'epic'),
('Crane Operator License', 'Increases building speed by 30%', 'building_speed', 30, 240, 0.26, 'common'),
('Engineering Degree', 'Increases building speed by 60%', 'building_speed', 60, 480, 0.58, 'rare'),
('Nanobots Assembly Kit', 'Increases building speed by 100%', 'building_speed', 100, null, 1.15, 'epic'),
('Time Compression Field', 'Increases building speed by 150%', 'building_speed', 150, null, 1.38, 'legendary'),
('Instant Construction Wand', 'Increases building speed by 300%', 'building_speed', 300, null, 1.5, 'legendary'),

-- Resource Gathering (8 items)
('Miner''s Headlamp', 'Increases resource gathering by 25%', 'resource_gathering', 25, 168, 0.17, 'common'),
('Farmer''s Green Thumb', 'Increases resource gathering by 45%', 'resource_gathering', 45, 336, 0.36, 'rare'),
('Industrialist''s Factory', 'Increases resource gathering by 80%', 'resource_gathering', 80, null, 0.91, 'epic'),
('Forager''s Survival Kit', 'Increases resource gathering by 35%', 'resource_gathering', 35, 288, 0.29, 'common'),
('Botanist''s Research Lab', 'Increases resource gathering by 65%', 'resource_gathering', 65, 504, 0.63, 'rare'),
('Automated Harvester', 'Increases resource gathering by 120%', 'resource_gathering', 120, null, 1.22, 'epic'),
('Quantum Extractor', 'Increases resource gathering by 200%', 'resource_gathering', 200, null, 1.42, 'legendary'),
('Matter Converter', 'Increases resource gathering by 250%', 'resource_gathering', 250, null, 1.48, 'legendary'),

-- PvP Advantages (7 items)
('Warrior''s Battle Cry', 'Increases PvP damage by 15%', 'pvp_advantage', 15, 168, 0.19, 'common'),
('Knight''s Shield Mastery', 'Increases PvP defense by 25%', 'pvp_advantage', 25, 336, 0.39, 'rare'),
('Berserker''s Rage Mode', 'Increases PvP damage by 50%', 'pvp_advantage', 50, null, 0.86, 'epic'),
('Assassin''s Stealth Cloak', 'Increases PvP critical chance by 30%', 'pvp_advantage', 30, 480, 0.54, 'rare'),
('Paladin''s Holy Aura', 'Increases PvP healing by 40%', 'pvp_advantage', 40, 600, 0.71, 'epic'),
('Demon Hunter''s Arsenal', 'Increases all PvP stats by 35%', 'pvp_advantage', 35, null, 1.18, 'epic'),
('God Mode Activation', 'Increases all PvP stats by 100%', 'pvp_advantage', 100, null, 1.5, 'legendary'),

-- Exclusive Access (6 items)
('VIP Lounge Pass', 'Access to exclusive VIP areas', 'exclusive_access', 1, 720, 0.33, 'rare'),
('Premium Member Badge', 'Access to premium features and events', 'exclusive_access', 1, null, 0.75, 'epic'),
('Developer''s Backstage Pass', 'Behind-scenes access and early features', 'exclusive_access', 1, null, 1.1, 'epic'),
('Alpha Tester Credentials', 'First access to new game content', 'exclusive_access', 1, null, 0.92, 'epic'),
('Founder''s Legacy Token', 'Permanent founder benefits and recognition', 'exclusive_access', 1, null, 1.35, 'legendary'),
('Inner Circle Invitation', 'Access to secret developer discussions', 'exclusive_access', 1, null, 1.48, 'legendary'),

-- Cosmetic Enhancements (11 items)
('Neon Glow Effect', 'Adds vibrant neon glow to your character', 'cosmetic', 1, null, 0.13, 'common'),
('Rainbow Trail Aura', 'Leaves a rainbow trail behind you', 'cosmetic', 1, null, 0.27, 'common'),
('Particle Storm Cloud', 'Surrounds you with swirling particles', 'cosmetic', 1, null, 0.41, 'rare'),
('Golden Crown of Glory', 'Displays a golden crown above your head', 'cosmetic', 1, null, 0.67, 'rare'),
('Phoenix Wing Animation', 'Animated phoenix wings on your back', 'cosmetic', 1, null, 0.89, 'epic'),
('Dragon Flame Breath', 'Breathe colorful dragon flames', 'cosmetic', 1, null, 1.05, 'epic'),
('Celestial Star Field', 'Surrounds you with twinkling stars', 'cosmetic', 1, null, 0.74, 'rare'),
('Lightning Strike Entrance', 'Epic lightning entrance effect', 'cosmetic', 1, null, 0.96, 'epic'),
('Time Warp Distortion', 'Visual time distortion around character', 'cosmetic', 1, null, 1.21, 'epic'),
('Holographic Avatar', 'Holographic overlay on your character', 'cosmetic', 1, null, 1.33, 'legendary'),
('Reality Glitch Effect', 'Matrix-style reality glitch visuals', 'cosmetic', 1, null, 1.47, 'legendary');