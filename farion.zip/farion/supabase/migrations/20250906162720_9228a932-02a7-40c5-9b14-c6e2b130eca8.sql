-- Create Powerball system tables

-- Powerball rounds table
CREATE TABLE public.powerball_rounds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_number INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting', -- waiting, active, completed, cancelled
  volume_threshold NUMERIC NOT NULL DEFAULT 50000, -- Volume needed to trigger round
  current_volume NUMERIC NOT NULL DEFAULT 0,
  prize_pool NUMERIC NOT NULL DEFAULT 0,
  creator_fee NUMERIC NOT NULL DEFAULT 0, -- 20% of volume
  winner_wallet_address TEXT,
  winner_username TEXT,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  ends_at TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '6 hours'),
  completed_at TIMESTAMP WITH TIME ZONE,
  participant_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Powerball participants table
CREATE TABLE public.powerball_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  token_balance NUMERIC NOT NULL,
  qualification_verified BOOLEAN NOT NULL DEFAULT false,
  qualification_checked_at TIMESTAMP WITH TIME ZONE,
  joined_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Powerball winners table  
CREATE TABLE public.powerball_winners (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  prize_amount NUMERIC NOT NULL,
  volume_at_win NUMERIC NOT NULL,
  token_balance_at_win NUMERIC NOT NULL,
  payout_completed BOOLEAN NOT NULL DEFAULT false,
  payout_completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Powerball settings table
CREATE TABLE public.powerball_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_key TEXT NOT NULL UNIQUE,
  setting_value JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.powerball_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.powerball_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.powerball_winners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.powerball_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Powerball rounds are viewable by everyone" 
ON public.powerball_rounds FOR SELECT USING (true);

CREATE POLICY "Powerball participants are viewable by everyone" 
ON public.powerball_participants FOR SELECT USING (true);

CREATE POLICY "Users can join powerball as participants" 
ON public.powerball_participants FOR INSERT WITH CHECK (true);

CREATE POLICY "Powerball winners are viewable by everyone" 
ON public.powerball_winners FOR SELECT USING (true);

CREATE POLICY "Powerball settings are viewable by everyone" 
ON public.powerball_settings FOR SELECT USING (true);

-- Triggers for updated_at
CREATE TRIGGER update_powerball_rounds_updated_at
BEFORE UPDATE ON public.powerball_rounds
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_powerball_settings_updated_at
BEFORE UPDATE ON public.powerball_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default settings
INSERT INTO public.powerball_settings (setting_key, setting_value) VALUES 
('round_duration_hours', '6'),
('creator_fee_percentage', '20'),
('min_token_balance', '1'),
('volume_multiplier', '1.0');

-- Function to get or create active powerball round
CREATE OR REPLACE FUNCTION get_or_create_active_powerball_round()
RETURNS UUID AS $$
DECLARE
    active_round_id UUID;
    new_round_number INTEGER;
BEGIN
    -- Try to find an existing active round
    SELECT id INTO active_round_id
    FROM powerball_rounds
    WHERE status IN ('waiting', 'active') AND ends_at > now()
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- If no active round exists, create a new one
    IF active_round_id IS NULL THEN
        -- Get the next round number
        SELECT COALESCE(MAX(round_number), 0) + 1 INTO new_round_number
        FROM powerball_rounds;
        
        -- Create new round
        INSERT INTO powerball_rounds (
            round_number,
            status,
            volume_threshold,
            current_volume,
            prize_pool,
            creator_fee,
            ends_at
        ) VALUES (
            new_round_number,
            'waiting',
            50000,
            0,
            0,
            0,
            now() + INTERVAL '6 hours'
        ) RETURNING id INTO active_round_id;
    END IF;
    
    RETURN active_round_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;