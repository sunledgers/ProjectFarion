-- Create launchpad tokens table
CREATE TABLE IF NOT EXISTS launchpad_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_address TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  symbol TEXT NOT NULL,
  description TEXT,
  logo_url TEXT,
  creator_wallet TEXT NOT NULL,
  creator_username TEXT,
  bonding_curve_progress NUMERIC DEFAULT 0,
  total_supply NUMERIC DEFAULT 1000000000,
  current_supply NUMERIC DEFAULT 1000000000,
  current_price NUMERIC DEFAULT 0.000001,
  market_cap NUMERIC DEFAULT 0,
  volume_24h NUMERIC DEFAULT 0,
  holder_count INTEGER DEFAULT 1,
  is_graduated BOOLEAN DEFAULT false,
  graduation_threshold NUMERIC DEFAULT 85,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE launchpad_tokens ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read launchpad_tokens" 
ON launchpad_tokens 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert launchpad_tokens" 
ON launchpad_tokens 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update launchpad_tokens" 
ON launchpad_tokens 
FOR UPDATE 
USING (true);

-- Create launchpad trades table
CREATE TABLE IF NOT EXISTS launchpad_trades (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id UUID REFERENCES launchpad_tokens(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  username TEXT,
  trade_type TEXT NOT NULL CHECK (trade_type IN ('buy', 'sell')),
  sol_amount NUMERIC NOT NULL,
  token_amount NUMERIC NOT NULL,
  price_at_trade NUMERIC NOT NULL,
  tx_signature TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE launchpad_trades ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read launchpad_trades" 
ON launchpad_trades 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert launchpad_trades" 
ON launchpad_trades 
FOR INSERT 
WITH CHECK (true);

-- Create token holders table
CREATE TABLE IF NOT EXISTS launchpad_holders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id UUID REFERENCES launchpad_tokens(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  username TEXT,
  balance NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(token_id, wallet_address)
);

-- Enable RLS
ALTER TABLE launchpad_holders ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read launchpad_holders" 
ON launchpad_holders 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert launchpad_holders" 
ON launchpad_holders 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update launchpad_holders" 
ON launchpad_holders 
FOR UPDATE 
USING (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE launchpad_tokens;
ALTER PUBLICATION supabase_realtime ADD TABLE launchpad_trades;