-- Fix the get_or_create_active_powerball_round function to handle read-only context
CREATE OR REPLACE FUNCTION public.get_or_create_active_powerball_round()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
    active_round_id UUID;
    new_round_number INTEGER;
BEGIN
    -- Try to find an existing active round first
    SELECT id INTO active_round_id
    FROM powerball_rounds
    WHERE status IN ('waiting', 'active') AND ends_at > now()
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- Only create a new round if we're in a writable context and no active round exists
    IF active_round_id IS NULL THEN
        BEGIN
            -- Get the next round number
            SELECT COALESCE(MAX(round_number), 0) + 1 INTO new_round_number
            FROM powerball_rounds;
            
            -- Create new round
            INSERT INTO powerball_rounds (
                round_number,
                status,
                volume_threshold,
                current_volume,
                prize_pool,
                creator_fee,
                ends_at
            ) VALUES (
                new_round_number,
                'waiting',
                50000,
                0,
                0,
                0,
                now() + INTERVAL '6 hours'
            ) RETURNING id INTO active_round_id;
            
        EXCEPTION WHEN others THEN
            -- If we can't create (read-only context), return null
            RETURN NULL;
        END;
    END IF;
    
    RETURN active_round_id;
END;
$function$

-- Create initial powerball round if none exists
INSERT INTO powerball_rounds (
    round_number,
    status,
    volume_threshold,
    current_volume,
    prize_pool,
    creator_fee,
    ends_at
)
SELECT 
    1,
    'waiting',
    50000,
    0,
    0,
    0,
    now() + INTERVAL '6 hours'
WHERE NOT EXISTS (SELECT 1 FROM powerball_rounds);