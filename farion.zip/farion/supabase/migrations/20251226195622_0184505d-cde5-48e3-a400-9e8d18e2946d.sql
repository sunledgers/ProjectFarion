-- Add dispute fields to p2p_trades
ALTER TABLE public.p2p_trades 
ADD COLUMN IF NOT EXISTS disputed_by TEXT,
ADD COLUMN IF NOT EXISTS dispute_reason TEXT,
ADD COLUMN IF NOT EXISTS dispute_raised_at TIMESTAMP WITH TIME ZONE;

-- Add transaction signature tracking to loans
ALTER TABLE public.loans 
ADD COLUMN IF NOT EXISTS collateral_tx_signature TEXT,
ADD COLUMN IF NOT EXISTS repayment_tx_signature TEXT;

-- Add transaction signature tracking to p2p_trades
ALTER TABLE public.p2p_trades 
ADD COLUMN IF NOT EXISTS escrow_tx_signature TEXT;