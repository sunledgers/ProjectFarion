-- Create launchpad tables for token creation and trading

-- Table for user-created tokens
CREATE TABLE public.created_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  creator_wallet_address TEXT NOT NULL,
  creator_username TEXT NOT NULL,
  name TEXT NOT NULL,
  symbol TEXT NOT NULL,
  description TEXT,
  logo_url TEXT,
  tax_percentage NUMERIC(4,2) NOT NULL DEFAULT 0 CHECK (tax_percentage >= 0 AND tax_percentage <= 2),
  total_supply NUMERIC(20,2) NOT NULL DEFAULT 1000000,
  current_supply NUMERIC(20,2) NOT NULL DEFAULT 1000000,
  market_cap NUMERIC(20,2) NOT NULL DEFAULT 5000,
  holders_count INTEGER NOT NULL DEFAULT 1,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for user $AUK balances and token holdings
CREATE TABLE public.token_balances (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  auk_balance NUMERIC(20,2) NOT NULL DEFAULT 0,
  token_id UUID,
  token_balance NUMERIC(20,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(wallet_address, token_id)
);

-- Table for tracking all buy/sell transactions
CREATE TABLE public.token_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token_id UUID NOT NULL REFERENCES public.created_tokens(id),
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('buy', 'sell')),
  token_amount NUMERIC(20,2) NOT NULL,
  auk_amount NUMERIC(20,2) NOT NULL,
  token_price NUMERIC(20,6) NOT NULL,
  tax_amount NUMERIC(20,2) NOT NULL DEFAULT 0,
  market_cap_before NUMERIC(20,2) NOT NULL,
  market_cap_after NUMERIC(20,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for daily $AUK claims (5 AUK per 24h)
CREATE TABLE public.auk_claims (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  claim_amount NUMERIC(20,2) NOT NULL DEFAULT 5,
  claimed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  next_claim_available_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + INTERVAL '24 hours')
);

-- Table for token dashboard actions (burn/lock)
CREATE TABLE public.token_dashboard_actions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token_id UUID NOT NULL REFERENCES public.created_tokens(id),
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  action_type TEXT NOT NULL CHECK (action_type IN ('burn', 'lock', 'unlock')),
  token_amount NUMERIC(20,2) NOT NULL,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.created_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.token_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.token_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auk_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.token_dashboard_actions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for created_tokens
CREATE POLICY "Tokens are viewable by everyone" 
ON public.created_tokens FOR SELECT USING (true);

CREATE POLICY "Users can create their own tokens" 
ON public.created_tokens FOR INSERT WITH CHECK (true);

CREATE POLICY "Token creators can update their tokens" 
ON public.created_tokens FOR UPDATE 
USING (creator_wallet_address = creator_wallet_address);

-- RLS Policies for token_balances
CREATE POLICY "Users can view all token balances" 
ON public.token_balances FOR SELECT USING (true);

CREATE POLICY "Users can create their own balances" 
ON public.token_balances FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can update their own balances" 
ON public.token_balances FOR UPDATE 
USING (wallet_address = wallet_address);

-- RLS Policies for token_transactions
CREATE POLICY "Transactions are viewable by everyone" 
ON public.token_transactions FOR SELECT USING (true);

CREATE POLICY "Users can create transactions" 
ON public.token_transactions FOR INSERT WITH CHECK (true);

-- RLS Policies for auk_claims
CREATE POLICY "Users can view their own claims" 
ON public.auk_claims FOR SELECT 
USING (wallet_address = wallet_address);

CREATE POLICY "Users can create their own claims" 
ON public.auk_claims FOR INSERT WITH CHECK (true);

-- RLS Policies for token_dashboard_actions
CREATE POLICY "Token actions are viewable by token creator" 
ON public.token_dashboard_actions FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.created_tokens 
  WHERE id = token_id AND creator_wallet_address = wallet_address
));

CREATE POLICY "Users can create token actions" 
ON public.token_dashboard_actions FOR INSERT WITH CHECK (true);

-- Add indexes for better performance
CREATE INDEX idx_created_tokens_creator ON public.created_tokens(creator_wallet_address);
CREATE INDEX idx_created_tokens_active ON public.created_tokens(is_active);
CREATE INDEX idx_token_balances_wallet ON public.token_balances(wallet_address);
CREATE INDEX idx_token_balances_token ON public.token_balances(token_id);
CREATE INDEX idx_token_transactions_token ON public.token_transactions(token_id);
CREATE INDEX idx_token_transactions_wallet ON public.token_transactions(wallet_address);
CREATE INDEX idx_auk_claims_wallet ON public.auk_claims(wallet_address);
CREATE INDEX idx_auk_claims_next_available ON public.auk_claims(wallet_address, next_claim_available_at);

-- Create trigger for updating updated_at timestamps
CREATE TRIGGER update_created_tokens_updated_at
  BEFORE UPDATE ON public.created_tokens
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_token_balances_updated_at
  BEFORE UPDATE ON public.token_balances
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();