-- Create token comments table
CREATE TABLE public.token_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id UUID NOT NULL REFERENCES public.launchpad_tokens(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  username TEXT,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.token_comments ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Anyone can read token comments"
ON public.token_comments
FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can insert comments"
ON public.token_comments
FOR INSERT
WITH CHECK (true);

-- Enable realtime
ALTER TABLE public.token_comments REPLICA IDENTITY FULL;

-- Create index for faster queries
CREATE INDEX idx_token_comments_token_id ON public.token_comments(token_id);
CREATE INDEX idx_token_comments_created_at ON public.token_comments(created_at DESC);