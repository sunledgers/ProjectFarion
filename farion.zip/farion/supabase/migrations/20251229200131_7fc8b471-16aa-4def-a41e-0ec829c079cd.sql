-- Create price alerts table
CREATE TABLE public.price_alerts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  token_id UUID NOT NULL REFERENCES public.launchpad_tokens(id) ON DELETE CASCADE,
  target_price NUMERIC NOT NULL,
  alert_type TEXT NOT NULL CHECK (alert_type IN ('above', 'below')),
  is_triggered BOOLEAN NOT NULL DEFAULT false,
  triggered_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(wallet_address, token_id, target_price, alert_type)
);

-- Enable Row Level Security
ALTER TABLE public.price_alerts ENABLE ROW LEVEL SECURITY;

-- Allow users to view their own alerts
CREATE POLICY "Users can view their own alerts"
ON public.price_alerts
FOR SELECT
USING (true);

-- Allow users to create alerts
CREATE POLICY "Users can create alerts"
ON public.price_alerts
FOR INSERT
WITH CHECK (true);

-- Allow users to update their alerts
CREATE POLICY "Users can update alerts"
ON public.price_alerts
FOR UPDATE
USING (true);

-- Allow users to delete their alerts
CREATE POLICY "Users can delete alerts"
ON public.price_alerts
FOR DELETE
USING (true);

-- Add indexes for faster lookups
CREATE INDEX idx_price_alerts_wallet ON public.price_alerts(wallet_address);
CREATE INDEX idx_price_alerts_token ON public.price_alerts(token_id);
CREATE INDEX idx_price_alerts_active ON public.price_alerts(is_triggered) WHERE is_triggered = false;