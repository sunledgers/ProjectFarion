-- Create forum boards table
CREATE TABLE public.forum_boards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create forum threads table
CREATE TABLE public.forum_threads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  board_id UUID NOT NULL REFERENCES public.forum_boards(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  image_path TEXT,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  token_balance NUMERIC,
  supply_percentage NUMERIC,
  verification_status TEXT DEFAULT 'pending',
  reply_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create forum posts table
CREATE TABLE public.forum_posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  thread_id UUID NOT NULL REFERENCES public.forum_threads(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  image_path TEXT,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  token_balance NUMERIC,
  supply_percentage NUMERIC,
  verification_status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.forum_boards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.forum_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.forum_posts ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for forum_boards
CREATE POLICY "Boards are viewable by everyone" 
ON public.forum_boards 
FOR SELECT 
USING (true);

-- Create RLS policies for forum_threads
CREATE POLICY "Threads are viewable by everyone" 
ON public.forum_threads 
FOR SELECT 
USING (true);

CREATE POLICY "Users can create threads" 
ON public.forum_threads 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own threads" 
ON public.forum_threads 
FOR UPDATE 
USING (wallet_address = wallet_address);

-- Create RLS policies for forum_posts
CREATE POLICY "Posts are viewable by everyone" 
ON public.forum_posts 
FOR SELECT 
USING (true);

CREATE POLICY "Users can create posts" 
ON public.forum_posts 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own posts" 
ON public.forum_posts 
FOR UPDATE 
USING (wallet_address = wallet_address);

-- Create storage bucket for forum images
INSERT INTO storage.buckets (id, name, public) VALUES ('forum-images', 'forum-images', true);

-- Create storage policies for forum images
CREATE POLICY "Forum images are publicly accessible" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'forum-images');

CREATE POLICY "Users can upload forum images" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'forum-images');

CREATE POLICY "Users can update their forum images" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'forum-images');

-- Create function to update thread reply count
CREATE OR REPLACE FUNCTION public.update_thread_reply_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.forum_threads 
    SET reply_count = reply_count + 1 
    WHERE id = NEW.thread_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.forum_threads 
    SET reply_count = reply_count - 1 
    WHERE id = OLD.thread_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for reply count
CREATE TRIGGER update_thread_reply_count_trigger
AFTER INSERT OR DELETE ON public.forum_posts
FOR EACH ROW
EXECUTE FUNCTION public.update_thread_reply_count();

-- Create triggers for timestamps
CREATE TRIGGER update_forum_boards_updated_at
BEFORE UPDATE ON public.forum_boards
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_forum_threads_updated_at
BEFORE UPDATE ON public.forum_threads
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_forum_posts_updated_at
BEFORE UPDATE ON public.forum_posts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default boards
INSERT INTO public.forum_boards (name, description) VALUES 
('random', 'Random discussions and general topics'),
('biz', 'Business, cryptocurrency, and trading discussions');