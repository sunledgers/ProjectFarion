-- Create jackpot tables for SOL-based betting system

-- Enable realtime for jackpot tables
ALTER TABLE public.jackpot_rounds REPLICA IDENTITY FULL;
ALTER TABLE public.jackpot_participants REPLICA IDENTITY FULL; 
ALTER TABLE public.jackpot_winners REPLICA IDENTITY FULL;

-- Add tables to realtime publication
ALTER publication supabase_realtime ADD TABLE public.jackpot_rounds;
ALTER publication supabase_realtime ADD TABLE public.jackpot_participants;
ALTER publication supabase_realtime ADD TABLE public.jackpot_winners;

-- Update jackpot_rounds to support SOL betting
UPDATE public.jackpot_rounds SET min_bet_amount = 0.01 WHERE min_bet_amount = 1000;