-- Update user_profiles table to support custom usernames
ALTER TABLE public.user_profiles ADD COLUMN IF NOT EXISTS custom_username text UNIQUE;
ALTER TABLE public.user_profiles ADD COLUMN IF NOT EXISTS username_set_at timestamp with time zone;

-- Create index for faster username lookups
CREATE INDEX IF NOT EXISTS idx_user_profiles_custom_username ON public.user_profiles(custom_username);

-- Create function to check username availability
CREATE OR REPLACE FUNCTION check_username_availability(desired_username text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if username exists (case insensitive)
  RETURN NOT EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE LOWER(custom_username) = LOWER(desired_username)
  );
END;
$$;

-- Create function to set custom username (can only be set once)
CREATE OR REPLACE FUNCTION set_custom_username(wallet_addr text, desired_username text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  existing_username text;
  result json;
BEGIN
  -- Check if user already has a custom username
  SELECT custom_username INTO existing_username 
  FROM public.user_profiles 
  WHERE wallet_address = wallet_addr;
  
  IF existing_username IS NOT NULL THEN
    result := json_build_object(
      'success', false,
      'error', 'Username already set',
      'username', existing_username
    );
    RETURN result;
  END IF;
  
  -- Check if desired username is available
  IF NOT check_username_availability(desired_username) THEN
    result := json_build_object(
      'success', false,
      'error', 'Username not available'
    );
    RETURN result;
  END IF;
  
  -- Validate username format (3-20 chars, alphanumeric + underscore)
  IF desired_username !~ '^[a-zA-Z0-9_]{3,20}$' THEN
    result := json_build_object(
      'success', false,
      'error', 'Username must be 3-20 characters, letters, numbers, and underscores only'
    );
    RETURN result;
  END IF;
  
  -- Set the username
  INSERT INTO public.user_profiles (wallet_address, username, custom_username, username_set_at)
  VALUES (wallet_addr, desired_username, desired_username, now())
  ON CONFLICT (wallet_address) 
  DO UPDATE SET 
    username = desired_username,
    custom_username = desired_username,
    username_set_at = now(),
    updated_at = now();
  
  result := json_build_object(
    'success', true,
    'username', desired_username
  );
  RETURN result;
END;
$$;