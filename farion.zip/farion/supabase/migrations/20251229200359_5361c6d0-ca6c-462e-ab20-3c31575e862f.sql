-- Create table for comment reactions
CREATE TABLE public.comment_reactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  comment_id UUID NOT NULL REFERENCES public.token_comments(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  reaction_type TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(comment_id, wallet_address, reaction_type)
);

-- Enable RLS
ALTER TABLE public.comment_reactions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view reactions"
ON public.comment_reactions
FOR SELECT
USING (true);

CREATE POLICY "Users can add reactions"
ON public.comment_reactions
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Users can remove their own reactions"
ON public.comment_reactions
FOR DELETE
USING (true);

-- Create indexes for performance
CREATE INDEX idx_comment_reactions_comment_id ON public.comment_reactions(comment_id);
CREATE INDEX idx_comment_reactions_wallet ON public.comment_reactions(wallet_address);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.comment_reactions;