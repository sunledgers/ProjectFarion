-- Create initial Powerball round for testing
INSERT INTO powerball_rounds (
  round_number,
  status,
  volume_threshold,
  current_volume,
  prize_pool,
  creator_fee,
  participant_count,
  ends_at
) VALUES (
  1,
  'waiting',
  10000,
  0,
  0,
  0,
  0,
  now() + INTERVAL '6 hours'
) ON CONFLICT (round_number) DO NOTHING;