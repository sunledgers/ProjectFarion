-- Add Meteora-specific columns to launchpad_tokens for on-chain data
ALTER TABLE public.launchpad_tokens 
ADD COLUMN IF NOT EXISTS pool_address TEXT,
ADD COLUMN IF NOT EXISTS token_mint TEXT,
ADD COLUMN IF NOT EXISTS config_address TEXT,
ADD COLUMN IF NOT EXISTS creation_fee_tx TEXT,
ADD COLUMN IF NOT EXISTS is_on_chain BOOLEAN DEFAULT false;

-- Create platform fees tracking table
CREATE TABLE IF NOT EXISTS public.platform_fees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id UUID REFERENCES public.launchpad_tokens(id),
  fee_type TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  wallet_address TEXT NOT NULL,
  tx_signature TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on platform_fees
ALTER TABLE public.platform_fees ENABLE ROW LEVEL SECURITY;

-- Allow public read on platform_fees
CREATE POLICY "Allow public read platform_fees" 
ON public.platform_fees 
FOR SELECT 
USING (true);

-- Allow public insert on platform_fees
CREATE POLICY "Allow public insert platform_fees" 
ON public.platform_fees 
FOR INSERT 
WITH CHECK (true);

-- Enable realtime for platform_fees
ALTER PUBLICATION supabase_realtime ADD TABLE public.platform_fees;