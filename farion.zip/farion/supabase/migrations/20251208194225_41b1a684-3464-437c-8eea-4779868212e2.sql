-- Create forum_boards table
CREATE TABLE IF NOT EXISTS public.forum_boards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  thread_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create forum_threads table
CREATE TABLE IF NOT EXISTS public.forum_threads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  board_id UUID REFERENCES public.forum_boards(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  image_path TEXT,
  username TEXT NOT NULL,
  wallet_address TEXT NOT NULL,
  token_balance NUMERIC DEFAULT 0,
  supply_percentage NUMERIC DEFAULT 0,
  verification_status TEXT DEFAULT 'pending',
  reply_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create forum_posts table
CREATE TABLE IF NOT EXISTS public.forum_posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  thread_id UUID REFERENCES public.forum_threads(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  image_path TEXT,
  username TEXT NOT NULL,
  wallet_address TEXT NOT NULL,
  token_balance NUMERIC DEFAULT 0,
  supply_percentage NUMERIC DEFAULT 0,
  verification_status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create meme_uploads table
CREATE TABLE IF NOT EXISTS public.meme_uploads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_address TEXT NOT NULL,
  username TEXT NOT NULL,
  filename TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  content_type TEXT NOT NULL,
  token_balance NUMERIC,
  supply_percentage NUMERIC,
  verification_status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create nft_collections table
CREATE TABLE IF NOT EXISTS public.nft_collections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  boost_type TEXT NOT NULL,
  boost_value NUMERIC NOT NULL,
  price_sol NUMERIC NOT NULL,
  rarity TEXT NOT NULL DEFAULT 'common',
  is_available BOOLEAN DEFAULT true,
  purchased_by_wallet TEXT,
  purchased_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create nft_purchases table
CREATE TABLE IF NOT EXISTS public.nft_purchases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nft_id UUID REFERENCES public.nft_collections(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  username TEXT,
  purchase_price_sol NUMERIC NOT NULL,
  transaction_hash TEXT,
  is_active BOOLEAN DEFAULT false,
  activated_at TIMESTAMP WITH TIME ZONE,
  purchased_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create check_username_availability function
CREATE OR REPLACE FUNCTION public.check_username_availability(desired_username TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM user_profiles 
    WHERE LOWER(custom_username) = LOWER(desired_username)
  );
END;
$$;

-- Create set_custom_username function
CREATE OR REPLACE FUNCTION public.set_custom_username(wallet_addr TEXT, desired_username TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  username_available BOOLEAN;
BEGIN
  -- Check availability
  SELECT check_username_availability(desired_username) INTO username_available;
  
  IF NOT username_available THEN
    RETURN jsonb_build_object('success', false, 'error', 'Username is already taken');
  END IF;
  
  -- Update or insert profile
  INSERT INTO user_profiles (wallet_address, username, custom_username, updated_at)
  VALUES (wallet_addr, desired_username, desired_username, now())
  ON CONFLICT (wallet_address) 
  DO UPDATE SET 
    custom_username = desired_username,
    updated_at = now();
  
  RETURN jsonb_build_object('success', true, 'username', desired_username);
END;
$$;

-- Enable RLS on new tables
ALTER TABLE public.forum_boards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.forum_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meme_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nft_collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nft_purchases ENABLE ROW LEVEL SECURITY;

-- Create policies for new tables
CREATE POLICY "Allow public read" ON public.forum_boards FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.forum_boards FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.forum_threads FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.forum_threads FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.forum_posts FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.forum_posts FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.meme_uploads FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.meme_uploads FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read" ON public.nft_collections FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.nft_collections FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.nft_collections FOR UPDATE USING (true);

CREATE POLICY "Allow public read" ON public.nft_purchases FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.nft_purchases FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.nft_purchases FOR UPDATE USING (true);

-- Add username_set_at column to user_profiles
ALTER TABLE public.user_profiles ADD COLUMN IF NOT EXISTS username_set_at TIMESTAMP WITH TIME ZONE;

-- Insert some default forum boards
INSERT INTO public.forum_boards (name, description) VALUES 
  ('general', 'General Discussion'),
  ('trading', 'Trading and Market Discussion'),
  ('memes', 'Meme Sharing'),
  ('announcements', 'Official Announcements')
ON CONFLICT (name) DO NOTHING;