-- First, complete any stuck active rounds
UPDATE jackpot_rounds SET status = 'completed' WHERE status = 'active' AND ends_at < now();

-- Drop existing function and recreate with correct logic
DROP FUNCTION IF EXISTS public.get_or_create_active_jackpot_round();

-- Create function that returns waiting rounds (not active)
CREATE OR REPLACE FUNCTION public.get_or_create_active_jackpot_round()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  waiting_round_id UUID;
  new_round_number INTEGER;
BEGIN
  -- Look for a waiting round (not yet started)
  SELECT id INTO waiting_round_id FROM jackpot_rounds WHERE status = 'waiting' LIMIT 1;
  
  IF waiting_round_id IS NULL THEN
    SELECT COALESCE(MAX(round_number), 0) + 1 INTO new_round_number FROM jackpot_rounds;
    INSERT INTO jackpot_rounds (round_number, status, total_pot, participant_count)
    VALUES (new_round_number, 'waiting', 0, 0)
    RETURNING id INTO waiting_round_id;
  END IF;
  
  RETURN waiting_round_id;
END;
$function$;

-- Create function to update participant odds after each join
CREATE OR REPLACE FUNCTION public.update_jackpot_participant_odds()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  total_pot NUMERIC;
BEGIN
  -- Calculate total pot for this round
  SELECT COALESCE(SUM(bet_amount), 0) INTO total_pot 
  FROM jackpot_participants 
  WHERE round_id = NEW.round_id;
  
  -- Update odds for all participants in this round
  UPDATE jackpot_participants 
  SET odds_percentage = CASE WHEN total_pot > 0 THEN (bet_amount / total_pot) * 100 ELSE 0 END
  WHERE round_id = NEW.round_id;
  
  -- Update round totals
  UPDATE jackpot_rounds 
  SET 
    total_pot = total_pot,
    participant_count = (SELECT COUNT(*) FROM jackpot_participants WHERE round_id = NEW.round_id)
  WHERE id = NEW.round_id;
  
  RETURN NEW;
END;
$function$;

-- Create trigger for odds update
DROP TRIGGER IF EXISTS update_participant_odds ON jackpot_participants;
CREATE TRIGGER update_participant_odds
AFTER INSERT ON jackpot_participants
FOR EACH ROW
EXECUTE FUNCTION public.update_jackpot_participant_odds();

-- Create function to check if round should start (5+ participants)
CREATE OR REPLACE FUNCTION public.check_and_start_jackpot_round()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  current_participant_count INTEGER;
  current_status TEXT;
BEGIN
  -- Get current round status and participant count
  SELECT status, participant_count INTO current_status, current_participant_count
  FROM jackpot_rounds
  WHERE id = NEW.round_id;
  
  -- Recalculate participant count
  SELECT COUNT(*) INTO current_participant_count
  FROM jackpot_participants
  WHERE round_id = NEW.round_id;
  
  -- If round is waiting and we now have 5+ participants, start the countdown
  IF current_status = 'waiting' AND current_participant_count >= 5 THEN
    UPDATE jackpot_rounds
    SET 
      status = 'active',
      started_at = now(),
      ends_at = now() + interval '120 seconds',
      participant_count = current_participant_count
    WHERE id = NEW.round_id;
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger to check for round start
DROP TRIGGER IF EXISTS check_round_start ON jackpot_participants;
CREATE TRIGGER check_round_start
AFTER INSERT ON jackpot_participants
FOR EACH ROW
EXECUTE FUNCTION public.check_and_start_jackpot_round();

-- Create winner selection function with weighted randomization
CREATE OR REPLACE FUNCTION public.select_jackpot_winner(round_uuid UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  total_pot_amount NUMERIC;
  random_value NUMERIC;
  cumulative_sum NUMERIC := 0;
  winner_wallet TEXT;
  winner_name TEXT;
  winner_bet NUMERIC;
  winner_share NUMERIC;
  project_fee NUMERIC;
  participant RECORD;
  round_num INTEGER;
BEGIN
  -- Get round info
  SELECT total_pot, round_number INTO total_pot_amount, round_num
  FROM jackpot_rounds
  WHERE id = round_uuid AND status = 'active';
  
  IF total_pot_amount IS NULL OR total_pot_amount = 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'No active round or empty pot');
  END IF;
  
  -- Generate random value between 0 and total pot
  random_value := random() * total_pot_amount;
  
  -- Select winner based on weighted probability (larger bets = higher chance)
  FOR participant IN 
    SELECT wallet_address, username, bet_amount 
    FROM jackpot_participants 
    WHERE round_id = round_uuid
    ORDER BY joined_at
  LOOP
    cumulative_sum := cumulative_sum + participant.bet_amount;
    IF cumulative_sum >= random_value THEN
      winner_wallet := participant.wallet_address;
      winner_name := participant.username;
      winner_bet := participant.bet_amount;
      EXIT;
    END IF;
  END LOOP;
  
  -- Calculate payouts (10% project fee)
  project_fee := total_pot_amount * 0.10;
  winner_share := total_pot_amount - project_fee;
  
  -- Update round with winner info
  UPDATE jackpot_rounds
  SET 
    status = 'completed',
    winner_address = winner_wallet,
    winner_username = winner_name
  WHERE id = round_uuid;
  
  -- Record winner
  INSERT INTO jackpot_winners (round_id, wallet_address, amount)
  VALUES (round_uuid, winner_wallet, winner_share);
  
  -- Create new waiting round
  INSERT INTO jackpot_rounds (round_number, status, total_pot, participant_count)
  VALUES (round_num + 1, 'waiting', 0, 0);
  
  RETURN jsonb_build_object(
    'success', true,
    'winner_wallet', winner_wallet,
    'winner_username', winner_name,
    'winner_bet', winner_bet,
    'winner_share', winner_share,
    'project_fee', project_fee,
    'total_pot', total_pot_amount
  );
END;
$function$;

-- Enable realtime for jackpot tables
ALTER PUBLICATION supabase_realtime ADD TABLE jackpot_rounds;
ALTER PUBLICATION supabase_realtime ADD TABLE jackpot_participants;
ALTER PUBLICATION supabase_realtime ADD TABLE jackpot_winners;