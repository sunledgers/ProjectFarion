-- Create token_dashboard_actions table
CREATE TABLE IF NOT EXISTS public.token_dashboard_actions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token_id UUID NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT,
  action_type TEXT NOT NULL,
  token_amount NUMERIC NOT NULL,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.token_dashboard_actions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read" ON public.token_dashboard_actions FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.token_dashboard_actions FOR INSERT WITH CHECK (true);

-- Create storage buckets for images
INSERT INTO storage.buckets (id, name, public) VALUES ('forum-images', 'forum-images', true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('memes', 'memes', true) ON CONFLICT DO NOTHING;

-- Create storage policies
CREATE POLICY "Anyone can view forum images" ON storage.objects FOR SELECT USING (bucket_id = 'forum-images');
CREATE POLICY "Anyone can upload forum images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'forum-images');

CREATE POLICY "Anyone can view memes" ON storage.objects FOR SELECT USING (bucket_id = 'memes');
CREATE POLICY "Anyone can upload memes" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'memes');