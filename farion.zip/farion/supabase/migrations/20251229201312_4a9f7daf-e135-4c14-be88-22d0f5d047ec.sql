-- Create meme_donations table for tracking donations to meme creators
CREATE TABLE public.meme_donations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meme_id UUID NOT NULL,
  donor_wallet TEXT NOT NULL,
  donor_username TEXT,
  recipient_wallet TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  tx_signature TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.meme_donations ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Allow public read meme_donations" ON public.meme_donations
FOR SELECT USING (true);

CREATE POLICY "Allow public insert meme_donations" ON public.meme_donations
FOR INSERT WITH CHECK (true);

-- Create meme_comments table
CREATE TABLE public.meme_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meme_id UUID NOT NULL,
  wallet_address TEXT NOT NULL,
  username TEXT,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.meme_comments ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Allow public read meme_comments" ON public.meme_comments
FOR SELECT USING (true);

CREATE POLICY "Allow public insert meme_comments" ON public.meme_comments
FOR INSERT WITH CHECK (true);

-- Enable realtime for both tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.meme_donations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.meme_comments;