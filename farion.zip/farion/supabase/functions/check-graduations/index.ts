import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Graduation threshold in SOL
const GRADUATION_THRESHOLD = 85;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Checking for graduated tokens...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Find tokens that have reached graduation threshold but aren't marked as graduated
    const { data: tokens, error: fetchError } = await supabase
      .from('launchpad_tokens')
      .select('*')
      .eq('is_graduated', false)
      .gte('escrow_sol_balance', GRADUATION_THRESHOLD);

    if (fetchError) {
      throw fetchError;
    }

    if (!tokens || tokens.length === 0) {
      console.log('No tokens ready for graduation');
      return new Response(
        JSON.stringify({ success: true, message: 'No tokens to graduate', count: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${tokens.length} tokens ready for graduation`);

    const graduatedTokens = [];

    for (const token of tokens) {
      try {
        console.log(`Graduating token: ${token.name} (${token.symbol})`);

        // Update token to graduated status
        const { error: updateError } = await supabase
          .from('launchpad_tokens')
          .update({
            is_graduated: true,
            migration_status: 'graduated',
            bonding_curve_progress: 100,
            updated_at: new Date().toISOString(),
          })
          .eq('id', token.id);

        if (updateError) {
          console.error(`Failed to graduate token ${token.id}:`, updateError);
          continue;
        }

        // Record graduation event
        await supabase.from('platform_fees').insert({
          token_id: token.id,
          wallet_address: token.creator_wallet,
          fee_type: 'graduation',
          amount: 0, // Just logging the event
          tx_signature: null,
        });

        graduatedTokens.push({
          id: token.id,
          name: token.name,
          symbol: token.symbol,
          escrowBalance: token.escrow_sol_balance,
        });

        console.log(`Token graduated successfully: ${token.name}`);
      } catch (tokenError) {
        console.error(`Error processing token ${token.id}:`, tokenError);
      }
    }

    console.log(`Graduation check complete. Graduated ${graduatedTokens.length} tokens.`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Graduated ${graduatedTokens.length} tokens`,
        count: graduatedTokens.length,
        tokens: graduatedTokens,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error checking graduations:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message || 'Internal server error' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
