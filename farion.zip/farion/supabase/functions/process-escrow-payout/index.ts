import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const LAMPORTS_PER_SOL = 1_000_000_000;

// Base58 encoding/decoding
const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function decodeBase58(str: string): Uint8Array {
  const bytes: number[] = [];
  for (const char of str) {
    const index = BASE58_ALPHABET.indexOf(char);
    if (index === -1) throw new Error('Invalid base58 character');
    let carry = index;
    for (let i = 0; i < bytes.length; i++) {
      carry += bytes[i] * 58;
      bytes[i] = carry & 0xff;
      carry >>= 8;
    }
    while (carry > 0) {
      bytes.push(carry & 0xff);
      carry >>= 8;
    }
  }
  for (const char of str) {
    if (char === '1') bytes.push(0);
    else break;
  }
  return new Uint8Array(bytes.reverse());
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { 
      tokenId, 
      walletAddress, 
      netSolAmount, 
      tokenAmount, 
      platformFee = 0, 
      creatorFee = 0,
      creatorWallet,
      isCreatorClaim = false,
      // Legacy support
      transaction_id,
      wallet_address,
      sol_amount,
      token_id
    } = body;

    // Support both new and legacy formats
    const targetWallet = walletAddress || wallet_address;
    const payoutAmount = netSolAmount || sol_amount;
    const targetTokenId = tokenId || token_id;

    console.log('Processing payout request:', { 
      targetWallet, 
      payoutAmount, 
      targetTokenId, 
      isCreatorClaim,
      platformFee,
      creatorFee
    });

    if (!targetWallet || payoutAmount === undefined || !targetTokenId) {
      return new Response(
        JSON.stringify({ success: false, error: 'Missing required fields' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (payoutAmount < 0.0001) {
      return new Response(
        JSON.stringify({ success: false, error: 'Payout amount too small' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Verify token exists and has sufficient escrow balance
    const { data: token, error: tokenError } = await supabase
      .from('launchpad_tokens')
      .select('*')
      .eq('id', targetTokenId)
      .single();

    if (tokenError || !token) {
      console.error('Token not found:', tokenError);
      return new Response(
        JSON.stringify({ success: false, error: 'Token not found' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404 }
      );
    }

    const escrowBalance = Number(token.escrow_sol_balance || 0);
    const totalPayout = payoutAmount + platformFee + creatorFee;

    if (!isCreatorClaim && escrowBalance < totalPayout) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: `Insufficient escrow balance. Available: ${escrowBalance.toFixed(6)} SOL, needed: ${totalPayout.toFixed(6)} SOL` 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // Get escrow wallet private key
    const escrowPrivateKey = Deno.env.get('ESCROW_WALLET_PRIVATE_KEY');
    if (!escrowPrivateKey) {
      console.error('ESCROW_WALLET_PRIVATE_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'Escrow wallet not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    // Get Helius RPC URL
    const heliusApiKey = Deno.env.get('HELIUS_API_KEY');
    const rpcUrl = heliusApiKey 
      ? `https://mainnet.helius-rpc.com/?api-key=${heliusApiKey}`
      : 'https://api.mainnet-beta.solana.com';

    console.log('Using RPC for payout');

    // Decode private key
    let privateKeyBytes: Uint8Array;
    try {
      if (escrowPrivateKey.startsWith('[')) {
        const parsed = JSON.parse(escrowPrivateKey);
        privateKeyBytes = new Uint8Array(parsed);
      } else {
        privateKeyBytes = decodeBase58(escrowPrivateKey);
      }
      
      if (privateKeyBytes.length !== 64) {
        throw new Error(`Invalid key length: ${privateKeyBytes.length}`);
      }
      console.log('Private key decoded successfully');
    } catch (e) {
      console.error('Failed to decode private key:', e);
      return new Response(
        JSON.stringify({ success: false, error: 'Invalid escrow wallet configuration' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    // Import ed25519 for signing
    const { ed25519 } = await import("https://esm.sh/@noble/curves@1.2.0/ed25519");
    
    const publicKeyBytes = privateKeyBytes.slice(32, 64);
    const secretKeyBytes = privateKeyBytes.slice(0, 32);
    
    // Get recent blockhash
    const blockhashResponse = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'getLatestBlockhash',
        params: [{ commitment: 'finalized' }]
      })
    });
    
    const blockhashData = await blockhashResponse.json();
    if (blockhashData.error) {
      throw new Error(`Failed to get blockhash: ${blockhashData.error.message}`);
    }
    
    const recentBlockhash = blockhashData.result.value.blockhash;
    console.log('Got blockhash:', recentBlockhash);

    // Build transfer instruction
    const recipientPubkey = decodeBase58(targetWallet);
    const lamports = Math.floor(payoutAmount * LAMPORTS_PER_SOL);
    
    const SYSTEM_PROGRAM_ID = new Uint8Array(32);
    
    const instructionData = new Uint8Array(12);
    instructionData[0] = 2; // Transfer instruction
    const lamportsBytes = new BigUint64Array([BigInt(lamports)]);
    new Uint8Array(instructionData.buffer).set(new Uint8Array(lamportsBytes.buffer), 4);

    // Compile transaction message
    const header = new Uint8Array([1, 0, 1]);
    
    const accountKeys = new Uint8Array(32 * 3);
    accountKeys.set(publicKeyBytes, 0);
    accountKeys.set(recipientPubkey, 32);
    accountKeys.set(SYSTEM_PROGRAM_ID, 64);
    
    const blockhashBytes = decodeBase58(recentBlockhash);
    
    const instruction = new Uint8Array([
      2, 2, 0, 1, 12,
      ...instructionData
    ]);
    
    const message = new Uint8Array([
      ...header,
      3,
      ...accountKeys,
      ...blockhashBytes,
      1,
      ...instruction
    ]);
    
    // Sign message
    const signature = ed25519.sign(message, secretKeyBytes);
    
    // Assemble transaction
    const transaction_bytes = new Uint8Array([
      1,
      ...signature,
      ...message
    ]);
    
    const transactionBase64 = btoa(String.fromCharCode(...transaction_bytes));
    
    // Send transaction
    console.log('Sending payout transaction...');
    const sendResponse = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'sendTransaction',
        params: [
          transactionBase64,
          { encoding: 'base64', preflightCommitment: 'confirmed' }
        ]
      })
    });
    
    const sendResult = await sendResponse.json();
    
    if (sendResult.error) {
      console.error('Transaction failed:', sendResult.error);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: `Transaction failed: ${sendResult.error.message}` 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }
    
    const txSignature = sendResult.result;
    console.log('Payout transaction sent:', txSignature);

    // Update escrow balance if not creator claim
    if (!isCreatorClaim) {
      const newEscrowBalance = escrowBalance - totalPayout;
      await supabase
        .from('launchpad_tokens')
        .update({ 
          escrow_sol_balance: Math.max(0, newEscrowBalance),
          updated_at: new Date().toISOString()
        })
        .eq('id', targetTokenId);
    }

    // Record the payout transaction
    await supabase.from('escrow_transactions').insert({
      token_id: targetTokenId,
      wallet_address: targetWallet,
      transaction_type: isCreatorClaim ? 'creator_claim' : 'payout',
      sol_amount: payoutAmount,
      token_amount: tokenAmount || 0,
      tx_signature: txSignature,
      payout_status: 'completed',
      payout_tx_signature: txSignature,
      payout_processed_at: new Date().toISOString(),
      platform_fee: platformFee,
      creator_fee: creatorFee,
    });

    // Record platform fee if applicable
    if (platformFee > 0) {
      await supabase.from('platform_fees').insert({
        token_id: targetTokenId,
        wallet_address: targetWallet,
        fee_type: 'sell_fee',
        amount: platformFee,
        tx_signature: txSignature,
      });
    }

    console.log('Payout processed successfully:', txSignature);

    return new Response(
      JSON.stringify({
        success: true,
        txSignature,
        tx_signature: txSignature, // Legacy support
        netPayout: payoutAmount,
        platformFee,
        creatorFee,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error processing payout:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message || 'Internal server error' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
