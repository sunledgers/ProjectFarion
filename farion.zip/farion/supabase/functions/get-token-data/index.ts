import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// FARION token contract address
const FARION_CONTRACT = 'CMXuYtw7JUyoJdGVMvYfjp89GX5eA4o83477HJZypump';

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Fetching token data for FARION:', FARION_CONTRACT);
    
    // Fetch from DexScreener API (free, no API key required)
    const response = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${FARION_CONTRACT}`
    );

    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('DexScreener response:', JSON.stringify(data).slice(0, 500));

    // Get the first pair (usually the most liquid)
    const pair = data.pairs?.[0];

    if (!pair) {
      console.log('No pairs found for token');
      return new Response(
        JSON.stringify({
          price: 0,
          priceChange24h: 0,
          volume24h: 0,
          marketCap: 0,
          liquidity: 0,
          error: 'No trading pairs found'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const tokenData = {
      price: parseFloat(pair.priceUsd) || 0,
      priceChange24h: parseFloat(pair.priceChange?.h24) || 0,
      volume24h: parseFloat(pair.volume?.h24) || 0,
      marketCap: parseFloat(pair.marketCap) || parseFloat(pair.fdv) || 0,
      liquidity: parseFloat(pair.liquidity?.usd) || 0,
      pairAddress: pair.pairAddress,
      dexId: pair.dexId,
      baseToken: pair.baseToken,
      quoteToken: pair.quoteToken,
    };

    console.log('Processed token data:', tokenData);

    return new Response(
      JSON.stringify(tokenData),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error fetching token data:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Failed to fetch token data',
        details: error.message,
        price: 0,
        priceChange24h: 0,
        volume24h: 0,
        marketCap: 0
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
