import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🎰 Jackpot draw winner function triggered');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Find all active rounds that have expired (ends_at < now())
    const { data: expiredRounds, error: fetchError } = await supabase
      .from('jackpot_rounds')
      .select('id, round_number, total_pot, participant_count, ends_at')
      .eq('status', 'active')
      .lt('ends_at', new Date().toISOString());
    
    if (fetchError) {
      console.error('❌ Error fetching expired rounds:', fetchError);
      throw fetchError;
    }
    
    console.log(`📋 Found ${expiredRounds?.length || 0} expired rounds to process`);
    
    const results = [];
    
    if (expiredRounds && expiredRounds.length > 0) {
      for (const round of expiredRounds) {
        console.log(`🎯 Processing round ${round.round_number} (ID: ${round.id})`);
        console.log(`   Total pot: ${round.total_pot} SOL, Participants: ${round.participant_count}`);
        
        // Call the winner selection function
        const { data: winnerResult, error: winnerError } = await supabase
          .rpc('select_jackpot_winner', { round_uuid: round.id });
        
        if (winnerError) {
          console.error(`❌ Error selecting winner for round ${round.id}:`, winnerError);
          results.push({
            round_id: round.id,
            success: false,
            error: winnerError.message
          });
        } else {
          console.log(`✅ Winner selected for round ${round.round_number}:`, winnerResult);
          results.push({
            round_id: round.id,
            success: true,
            result: winnerResult
          });
        }
      }
    }
    
    const response = {
      success: true,
      processed_rounds: expiredRounds?.length || 0,
      results,
      timestamp: new Date().toISOString()
    };
    
    console.log('🏁 Jackpot draw complete:', response);
    
    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
    
  } catch (error) {
    console.error('❌ Error in jackpot-draw-winner function:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
