import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { Connection, PublicKey } from 'https://esm.sh/@solana/web3.js@1.95.2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { walletAddress } = await req.json();

    if (!walletAddress) {
      return new Response(
        JSON.stringify({ error: 'Wallet address is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Contract address for FARION token
    const contractAddress = 'CMXuYtw7JUyoJdGVMvYfjp89GX5eA4o83477HJZypump';
    
    // Initialize Solana connection
    const connection = new Connection('https://api.mainnet-beta.solana.com', 'confirmed');
    
    let tokenBalance = 0;
    let supplyPercentage = 0;
    let verificationStatus = 'no_tokens';
    
    try {
      // Get wallet's public key
      const walletPublicKey = new PublicKey(walletAddress);
      
      // Get token mint public key
      const mintPublicKey = new PublicKey(contractAddress);
      
      // Get all token accounts for this wallet
      const tokenAccounts = await connection.getParsedTokenAccountsByOwner(walletPublicKey, {
        mint: mintPublicKey
      });
      
      // Calculate total balance from all token accounts
      for (const tokenAccount of tokenAccounts.value) {
        const accountInfo = tokenAccount.account.data.parsed.info;
        tokenBalance += parseFloat(accountInfo.tokenAmount.uiAmount) || 0;
      }
      
      // Get token supply for percentage calculation
      const supplyInfo = await connection.getTokenSupply(mintPublicKey);
      const totalSupply = parseFloat(supplyInfo.value.uiAmount) || 1;
      supplyPercentage = (tokenBalance / totalSupply) * 100;
      
      verificationStatus = tokenBalance > 0 ? 'verified' : 'no_tokens';
      
      console.log(`Checking token balance for wallet: ${walletAddress}`);
      console.log(`Token balance: ${tokenBalance}, Supply percentage: ${supplyPercentage}%`);
      
    } catch (error) {
      console.error('Error fetching token balance:', error);
      // Keep default values (0 balance, no_tokens status)
    }

    return new Response(
      JSON.stringify({
        walletAddress,
        tokenBalance,
        supplyPercentage,
        verificationStatus,
        contractAddress
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in verify-token-holdings:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});