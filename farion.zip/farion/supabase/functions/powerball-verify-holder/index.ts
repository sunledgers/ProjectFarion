import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { walletAddress, username } = await req.json();

    if (!walletAddress || !username) {
      throw new Error('Wallet address and username are required');
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const TOKEN_ADDRESS = 'FZ8qp7qVPTSFVWu8bGpAMiz25noxhG8JNQzre7ULpump';

    // Verify token holdings using Helius API
    let tokenBalance = 0;
    let isQualified = false;

    try {
      const heliusResponse = await fetch('https://mainnet.helius-rpc.com/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 'my-id',
          method: 'getTokenAccountsByOwner',
          params: [
            walletAddress,
            {
              mint: TOKEN_ADDRESS,
            },
            {
              encoding: 'jsonParsed',
            },
          ],
        }),
      });

      if (heliusResponse.ok) {
        const data = await heliusResponse.json();
        if (data.result && data.result.value && data.result.value.length > 0) {
          const tokenAccount = data.result.value[0];
          tokenBalance = parseFloat(tokenAccount.account.data.parsed.info.tokenAmount.uiAmount) || 0;
          isQualified = tokenBalance > 0;
        }
      }
    } catch (error) {
      console.error('Error checking token balance with Helius:', error);
      
      // Fallback to Solscan API
      try {
        const solscanResponse = await fetch(`https://public-api.solscan.io/account/tokens?account=${walletAddress}`);
        if (solscanResponse.ok) {
          const solscanData = await solscanResponse.json();
          const tokenInfo = solscanData.find((token: any) => token.tokenAddress === TOKEN_ADDRESS);
          if (tokenInfo) {
            tokenBalance = parseFloat(tokenInfo.tokenAmount.uiAmount) || 0;
            isQualified = tokenBalance > 0;
          }
        }
      } catch (fallbackError) {
        console.error('Error with Solscan fallback:', fallbackError);
      }
    }

    // Get active round
    const { data: rounds, error: roundError } = await supabase
      .from('powerball_rounds')
      .select('*')
      .eq('status', 'waiting')
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (roundError) {
      console.error('Error getting active round:', roundError);
      throw roundError;
    }
    
    if (!rounds || rounds.length === 0) {
      throw new Error('No active round found');
    }
    
    const roundId = rounds[0].id;

    // Check if user is already a participant
    const { data: existingParticipant } = await supabase
      .from('powerball_participants')
      .select('*')
      .eq('round_id', roundId)
      .eq('wallet_address', walletAddress)
      .single();

    if (existingParticipant) {
      // Update existing participant
      const { error: updateError } = await supabase
        .from('powerball_participants')
        .update({
          token_balance: tokenBalance,
          qualification_verified: isQualified,
          qualification_checked_at: new Date().toISOString()
        })
        .eq('id', existingParticipant.id);

      if (updateError) {
        console.error('Error updating participant:', updateError);
        throw updateError;
      }
    } else {
      // Create new participant
      const { error: insertError } = await supabase
        .from('powerball_participants')
        .insert({
          round_id: roundId,
          wallet_address: walletAddress,
          username: username,
          token_balance: tokenBalance,
          qualification_verified: isQualified,
          qualification_checked_at: new Date().toISOString()
        });

      if (insertError) {
        console.error('Error creating participant:', insertError);
        throw insertError;
      }
    }

    // Update participant count in round
    if (isQualified && !existingParticipant) {
      const { data: currentRound } = await supabase
        .from('powerball_rounds')
        .select('participant_count')
        .eq('id', roundId)
        .single();
      
      if (currentRound) {
        await supabase
          .from('powerball_rounds')
          .update({
            participant_count: currentRound.participant_count + 1
          })
          .eq('id', roundId);
      }
    }

    console.log(`Verification result for ${username}: Balance ${tokenBalance}, Qualified: ${isQualified}`);

    return new Response(
      JSON.stringify({
        success: true,
        isQualified,
        tokenBalance,
        roundId
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Error in powerball holder verification:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});