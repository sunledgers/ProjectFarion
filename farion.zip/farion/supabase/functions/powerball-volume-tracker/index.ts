import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const TOKEN_ADDRESS = 'FZ8qp7qVPTSFVWu8bGpAMiz25noxhG8JNQzre7ULpump';

    // Fetch current volume from Pump.fun API
    const pumpResponse = await fetch(`https://frontend-api.pump.fun/coins/${TOKEN_ADDRESS}`);
    let currentVolume = 0;

    if (pumpResponse.ok) {
      const pumpData = await pumpResponse.json();
      currentVolume = pumpData.volume_24h || 0;
      console.log('Pump.fun volume data:', pumpData.volume_24h);
    } else {
      // Fallback to DexScreener
      const dexResponse = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${TOKEN_ADDRESS}`);
      if (dexResponse.ok) {
        const dexData = await dexResponse.json();
        if (dexData.pairs && dexData.pairs.length > 0) {
          currentVolume = dexData.pairs[0].volume?.h24 || 0;
          console.log('DexScreener volume data:', dexData.pairs[0].volume?.h24);
        }
      }
    }

    // Get active round or create one if none exists
    let { data: rounds, error: roundError } = await supabase
      .from('powerball_rounds')
      .select('*')
      .eq('status', 'waiting')
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (roundError) {
      console.error('Error getting active round:', roundError);
      throw roundError;
    }
    
    // Auto-create a new round if none exists
    if (!rounds || rounds.length === 0) {
      console.log('No active powerball round found, creating one...');
      
      // Get the last round number
      const { data: lastRound } = await supabase
        .from('powerball_rounds')
        .select('round_number')
        .order('round_number', { ascending: false })
        .limit(1);
      
      const nextRoundNumber = (lastRound && lastRound.length > 0) ? lastRound[0].round_number + 1 : 1;
      
      const { data: newRound, error: createError } = await supabase
        .from('powerball_rounds')
        .insert({
          round_number: nextRoundNumber,
          status: 'waiting',
          volume_threshold: 10000,
          prize_pool: 0,
          current_volume: 0,
          participant_count: 0,
          started_at: new Date().toISOString(),
          ends_at: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString()
        })
        .select()
        .single();
      
      if (createError) {
        console.error('Error creating round:', createError);
        throw createError;
      }
      
      rounds = [newRound];
      console.log('Created new powerball round:', nextRoundNumber);
    }
    
    const currentRound = rounds[0];
    const roundData = currentRound.id;

    // Calculate prize pool (80% of volume, 20% goes to creator)
    const prizePool = currentVolume * 0.8;
    const creatorFee = currentVolume * 0.2;

    // Update round with current volume data
    const { error: updateError } = await supabase
      .from('powerball_rounds')
      .update({
        current_volume: currentVolume,
        prize_pool: prizePool,
        creator_fee: creatorFee,
        updated_at: new Date().toISOString()
      })
      .eq('id', roundData);

    if (updateError) {
      console.error('Error updating round:', updateError);
      throw updateError;
    }

    // Check if round should be completed (volume threshold reached or time expired)
    const { data: roundInfo } = await supabase
      .from('powerball_rounds')
      .select('*')
      .eq('id', roundData)
      .single();

    if (roundInfo && 
        (currentVolume >= roundInfo.volume_threshold || new Date() >= new Date(roundInfo.ends_at))) {
      
      // Get all qualified participants
      const { data: participants } = await supabase
        .from('powerball_participants')
        .select('*')
        .eq('round_id', roundData)
        .eq('qualification_verified', true);

      if (participants && participants.length > 0) {
        // Select random winner
        const winnerIndex = Math.floor(Math.random() * participants.length);
        const winner = participants[winnerIndex];

        // Mark round as completed and set winner
        await supabase
          .from('powerball_rounds')
          .update({
            status: 'completed',
            winner_wallet_address: winner.wallet_address,
            winner_username: winner.username,
            completed_at: new Date().toISOString()
          })
          .eq('id', roundData);

        // Create winner record
        await supabase
          .from('powerball_winners')
          .insert({
            round_id: roundData,
            wallet_address: winner.wallet_address,
            username: winner.username,
            prize_amount: prizePool,
            volume_at_win: currentVolume,
            token_balance_at_win: winner.token_balance
          });

        console.log(`Winner selected: ${winner.username} - Prize: ${prizePool}`);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        currentVolume,
        prizePool,
        creatorFee,
        roundId: roundData
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Error in powerball volume tracker:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});