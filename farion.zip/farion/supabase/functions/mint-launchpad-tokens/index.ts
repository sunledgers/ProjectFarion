import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const HELIUS_RPC_URL = `https://mainnet.helius-rpc.com/?api-key=${Deno.env.get('HELIUS_API_KEY') || '848e04fa-8f26-4116-baca-c2cef9d75186'}`;
const LAMPORTS_PER_SOL = 1_000_000_000;
const TOKEN_DECIMALS = 9;

// Base58 alphabet
const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function decodeBase58(str: string): Uint8Array {
  const bytes: number[] = [];
  for (const char of str) {
    const idx = BASE58_ALPHABET.indexOf(char);
    if (idx === -1) throw new Error('Invalid base58 character');
    let carry = idx;
    for (let i = 0; i < bytes.length; i++) {
      carry += bytes[i] * 58;
      bytes[i] = carry & 0xff;
      carry >>= 8;
    }
    while (carry > 0) {
      bytes.push(carry & 0xff);
      carry >>= 8;
    }
  }
  for (const char of str) {
    if (char === '1') bytes.push(0);
    else break;
  }
  return new Uint8Array(bytes.reverse());
}

function encodeBase58(bytes: Uint8Array): string {
  const digits: number[] = [0];
  for (const byte of bytes) {
    let carry = byte;
    for (let i = 0; i < digits.length; i++) {
      carry += digits[i] << 8;
      digits[i] = carry % 58;
      carry = Math.floor(carry / 58);
    }
    while (carry > 0) {
      digits.push(carry % 58);
      carry = Math.floor(carry / 58);
    }
  }
  let result = '';
  for (const byte of bytes) {
    if (byte === 0) result += '1';
    else break;
  }
  for (let i = digits.length - 1; i >= 0; i--) {
    result += BASE58_ALPHABET[digits[i]];
  }
  return result;
}

// Simple encryption/decryption using XOR with a key
function encryptKeypair(keypairBytes: Uint8Array, secretKey: string): string {
  const keyBytes = new TextEncoder().encode(secretKey);
  const encrypted = new Uint8Array(keypairBytes.length);
  for (let i = 0; i < keypairBytes.length; i++) {
    encrypted[i] = keypairBytes[i] ^ keyBytes[i % keyBytes.length];
  }
  return encodeBase58(encrypted);
}

function decryptKeypair(encryptedStr: string, secretKey: string): Uint8Array {
  const encrypted = decodeBase58(encryptedStr);
  const keyBytes = new TextEncoder().encode(secretKey);
  const decrypted = new Uint8Array(encrypted.length);
  for (let i = 0; i < encrypted.length; i++) {
    decrypted[i] = encrypted[i] ^ keyBytes[i % keyBytes.length];
  }
  return decrypted;
}

// Token Program ID
const TOKEN_PROGRAM_ID = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
const ASSOCIATED_TOKEN_PROGRAM_ID = 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL';
const SYSTEM_PROGRAM_ID = '11111111111111111111111111111111';
const SYSVAR_RENT_ID = 'SysvarRent111111111111111111111111111111111';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      tokenId, 
      action, // 'create_mint', 'mint_tokens', 'burn_tokens'
      recipientWallet,
      tokenAmount,
      mintKeypairBytes, // For storing during creation
    } = await req.json();

    console.log(`Mint action: ${action} for token ${tokenId}`);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') || '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
    );

    const encryptionKey = Deno.env.get('ESCROW_WALLET_PRIVATE_KEY') || 'default-key';

    if (action === 'store_mint_keypair') {
      // Store encrypted mint keypair
      if (!mintKeypairBytes || !tokenId) {
        throw new Error('Missing mintKeypairBytes or tokenId');
      }

      const keypairArray = new Uint8Array(mintKeypairBytes);
      const encryptedKeypair = encryptKeypair(keypairArray, encryptionKey);

      const { error: updateError } = await supabase
        .from('launchpad_tokens')
        .update({ 
          encrypted_mint_keypair: encryptedKeypair,
          tokens_minted_onchain: false,
        })
        .eq('id', tokenId);

      if (updateError) throw updateError;

      console.log(`Stored encrypted mint keypair for token ${tokenId}`);
      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'mint_tokens') {
      // Mint tokens to a recipient
      if (!tokenId || !recipientWallet || !tokenAmount) {
        throw new Error('Missing tokenId, recipientWallet, or tokenAmount');
      }

      // Get token data
      const { data: token, error: fetchError } = await supabase
        .from('launchpad_tokens')
        .select('*')
        .eq('id', tokenId)
        .single();

      if (fetchError || !token) {
        throw new Error('Token not found');
      }

      if (!token.encrypted_mint_keypair) {
        throw new Error('Mint keypair not stored for this token');
      }

      // Decrypt the mint keypair
      const mintKeypair = decryptKeypair(token.encrypted_mint_keypair, encryptionKey);
      const mintPublicKey = token.token_mint || token.contract_address;

      console.log(`Minting ${tokenAmount} tokens to ${recipientWallet}`);

      // Calculate the Associated Token Address
      const recipientPubkeyBytes = decodeBase58(recipientWallet);
      const mintPubkeyBytes = decodeBase58(mintPublicKey);

      // Build the mint transaction
      // This requires building raw transaction bytes - complex without SDK
      // For now, we'll use Helius API to build and submit

      const response = await fetch(HELIUS_RPC_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 'mint-tokens',
          method: 'getLatestBlockhash',
          params: [{ commitment: 'confirmed' }],
        }),
      });

      const blockhashResult = await response.json();
      const blockhash = blockhashResult.result?.value?.blockhash;

      if (!blockhash) {
        throw new Error('Failed to get blockhash');
      }

      // For now, we track minting in the database
      // Full on-chain minting requires ed25519 signing which is complex without proper SDK
      // The tokens are tracked off-chain until we implement full on-chain minting

      console.log(`Token minting tracked for ${recipientWallet}: ${tokenAmount} tokens`);
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Token minting tracked',
          tokenAmount,
          recipientWallet,
          note: 'Full on-chain SPL minting requires additional SDK integration'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'get_mint_info') {
      // Get mint info for verification
      const { data: token } = await supabase
        .from('launchpad_tokens')
        .select('token_mint, contract_address, tokens_minted_onchain, encrypted_mint_keypair')
        .eq('id', tokenId)
        .single();

      return new Response(
        JSON.stringify({ 
          success: true,
          mintAddress: token?.token_mint || token?.contract_address,
          hasMintKeypair: !!token?.encrypted_mint_keypair,
          mintedOnChain: token?.tokens_minted_onchain,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    throw new Error(`Unknown action: ${action}`);
  } catch (error: any) {
    console.error('Mint token error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  }
});
