<p align="center">
  <img src="public/farion-logo.png" alt="Farion Logo" width="120" height="120" />
</p>

<h1 align="center">Farion</h1>

<p align="center">
  <strong>Next-Generation Token Launchpad on Solana</strong>
</p>

<p align="center">
  <a href="WHITEPAPER.md">📄 Whitepaper</a> •
  <a href="#features">Features</a> •
  <a href="#how-it-works">How It Works</a> •
  <a href="#technology">Technology</a> •
  <a href="#security">Security</a> •
  <a href="#roadmap">Roadmap</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Solana-Mainnet-9945FF?style=for-the-badge&logo=solana&logoColor=white" alt="Solana" />
  <img src="https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React" />
  <img src="https://img.shields.io/badge/TypeScript-5-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript" />
  <img src="https://img.shields.io/badge/License-Source%20Available-blue?style=for-the-badge" alt="License" />
</p>

---

## 🚀 Overview

**Farion** is a decentralized token launchpad built on Solana that enables anyone to create and trade tokens with fair, transparent bonding curve mechanics. Launch your token in seconds with customizable creator fees and automatic liquidity graduation.

### Key Highlights

- 🎯 **Fair Launch** — No presales, no team allocations, everyone starts equal
- 📈 **Bonding Curve** — Transparent pricing that increases with demand
- 💰 **Creator Rewards** — Earn 0-5% on every trade of your token
- 🎓 **Auto-Graduation** — Tokens automatically migrate to DEX at 85 SOL threshold
- ⚡ **Instant Trading** — Buy and sell tokens immediately after launch

---

## ✨ Features

### 🪙 Token Launchpad
- Create tokens with custom name, symbol, and description
- **Vanity addresses** — Get a token address starting with your desired prefix
- **Customizable creator fees** (0-5%) on all trades
- Low creation fee of just **0.01 SOL**
- Automatic logo upload and metadata

### 📊 Bonding Curve Trading
- Fair price discovery through mathematical bonding curves
- Real-time price updates based on supply/demand
- **1% platform fee** on sells only (buys are fee-free!)
- Transparent trade history and holder tracking

### 🎰 Gamification
- **Jackpot System** — Community prize pools
- **Powerball** — Holder-exclusive lottery
- **Staking** — Earn rewards by staking tokens
- **NFT Marketplace** — Boost your earnings with NFT power-ups

### 💬 Community
- Real-time chat rooms
- Forum with holder verification badges
- Meme uploads and community engagement

---

## 🔧 How It Works

### 1. Create Your Token
```
Name: MyToken
Symbol: MTK
Creator Fee: 2%
Initial Buy: 0.1 SOL (optional)
```
Pay 0.01 SOL creation fee → Your token is live!

### 2. Trading Mechanics
```
Price = f(supply) — Bonding curve formula

Buy:  You pay SOL → Receive tokens → Price increases
Sell: You sell tokens → Receive SOL → Price decreases
```

### 3. Graduation
When a token reaches **85 SOL** in the bonding curve:
- Trading pauses
- Liquidity migrates to Raydium
- Token becomes freely tradeable on DEX

### Fee Structure
| Action | Platform Fee | Creator Fee |
|--------|-------------|-------------|
| Buy    | 0%          | 0-5%        |
| Sell   | 1%          | 0-5%        |
| Create | 0.01 SOL    | —           |

---

## 🛠 Technology

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Framer Motion** for animations
- **Shadcn/UI** component library

### Blockchain
- **Solana** (Mainnet-Beta)
- **SPL Token** standard
- Multi-wallet support (Phantom, Solflare, Backpack, Trust)

### Backend
- **Edge Functions** for secure operations
- **PostgreSQL** database
- Real-time subscriptions

### Key Dependencies
```json
{
  "@solana/web3.js": "^1.98.4",
  "@solana/spl-token": "^0.4.9",
  "@solana/wallet-adapter-react": "^0.15.39",
  "react": "^18.3.1",
  "typescript": "^5.0.0"
}
```

---

## 🔒 Security

### What's Protected
- ✅ **Private keys** stored in secure environment variables
- ✅ **Escrow system** for safe trading
- ✅ **No hardcoded secrets** in codebase
- ✅ **Row-Level Security** on all database tables

### Transparency
- 📖 Open source codebase
- 🔍 Verifiable smart contract interactions
- 📊 Public trade history and holder data

### Escrow Wallet
All trades go through a secure escrow system:
```
User → Escrow Wallet → Token/SOL Distribution
```
This ensures safe, atomic transactions.

---

## 🗺 Roadmap

### Phase 1: Foundation ✅
- [x] Token creation with bonding curves
- [x] Buy/sell trading system
- [x] Creator fee customization
- [x] Wallet integration (Phantom, Solflare, etc.)
- [x] Community features (chat, forum)
- [x] Jackpot and staking systems

### Phase 2: Enhancement 🔄
- [ ] Real SPL token minting on-chain
- [ ] Raydium pool migration on graduation
- [ ] Advanced trading charts
- [ ] Mobile app

### Phase 3: Expansion 🔮
- [ ] Cross-chain support
- [ ] DAO governance
- [ ] Advanced analytics dashboard
- [ ] API for developers

---

## 📜 Contract

**$FARION Token:**
```
CMXuYtw7JUyoJdGVMvYfjp89GX5eA4o83477HJZypump
```

---

## 🤝 Contributing

We welcome contributions! Please read our contributing guidelines before submitting PRs.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

This project is **Source Available** - you can view and study the code, but copying, modifying, or commercial use is prohibited. See the [LICENSE](LICENSE) file for full terms.

**Why Source Available?**
- 🔍 **Transparency** - See exactly how Farion works
- 🔒 **Protection** - Prevents unauthorized copies and scams
- 🤝 **Trust** - Build confidence through open visibility

---

<p align="center">
  <strong>Built with 💚 on Solana</strong>
</p>

<p align="center">
  <a href="https://farion.io">Website</a> •
  <a href="https://x.com/ProjectFarion">X</a> •
  <a href="https://t.me/FarionPortal">Telegram</a>
</p>
