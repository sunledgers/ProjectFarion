import { useState, useCallback } from 'react';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';
import { ESCROW_WALLET } from '@/config/wallets';

// Mainnet Helius RPC endpoints for production
const RPC_ENDPOINTS = [
  'https://mainnet.helius-rpc.com/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186',
  'https://rpc.helius.xyz/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186',
];

export const useEscrowTransactions = () => {
  const { selectedWallet, walletAddress, username } = useMultiWallet();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [currentRPCIndex, setCurrentRPCIndex] = useState(0);

  const getConnection = useCallback(() => {
    return new Connection(RPC_ENDPOINTS[currentRPCIndex], 'confirmed');
  }, [currentRPCIndex]);

  const sendSOLToEscrow = useCallback(async (amountSOL: number): Promise<string | null> => {
    if (!selectedWallet?.adapter?.connected || !selectedWallet.adapter.publicKey || !walletAddress) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet first.",
        variant: "destructive"
      });
      return null;
    }

    if (amountSOL <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid SOL amount.",
        variant: "destructive"
      });
      return null;
    }

    setLoading(true);
    let attempts = 0;
    const maxAttempts = RPC_ENDPOINTS.length;

    while (attempts < maxAttempts) {
      try {
        const connection = new Connection(RPC_ENDPOINTS[(currentRPCIndex + attempts) % RPC_ENDPOINTS.length], 'confirmed');
        const fromPubkey = new PublicKey(walletAddress);
        const escrowPubkey = new PublicKey(ESCROW_WALLET);

        // Check balance
        const balance = await connection.getBalance(fromPubkey);
        const requiredLamports = Math.floor(amountSOL * LAMPORTS_PER_SOL);
        const estimatedFee = 5000;

        if (balance < requiredLamports + estimatedFee) {
          toast({
            title: "Insufficient Balance",
            description: `You need at least ${((requiredLamports + estimatedFee) / LAMPORTS_PER_SOL).toFixed(6)} SOL.`,
            variant: "destructive"
          });
          setLoading(false);
          return null;
        }

        // Create transaction
        const transaction = new Transaction().add(
          SystemProgram.transfer({
            fromPubkey,
            toPubkey: escrowPubkey,
            lamports: requiredLamports,
          })
        );

        const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
        transaction.recentBlockhash = blockhash;
        transaction.feePayer = fromPubkey;

        // Send transaction using available wallet method
        let signature: string;
        
        if ('sendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.sendTransaction === 'function') {
          signature = await selectedWallet.adapter.sendTransaction(transaction, connection);
        } else if ('signAndSendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signAndSendTransaction === 'function') {
          signature = await selectedWallet.adapter.signAndSendTransaction(transaction);
        } else if ('signTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signTransaction === 'function') {
          const signedTransaction = await selectedWallet.adapter.signTransaction(transaction);
          signature = await connection.sendRawTransaction(signedTransaction.serialize());
        } else {
          throw new Error('Wallet does not support transaction signing');
        }

        // Confirm transaction
        const confirmation = await connection.confirmTransaction({
          signature,
          blockhash,
          lastValidBlockHeight,
        }, 'confirmed');

        if (confirmation.value.err) {
          throw new Error(`Transaction failed: ${confirmation.value.err}`);
        }

        toast({
          title: "SOL Sent to Escrow",
          description: `${amountSOL} SOL successfully sent to escrow.`,
        });

        setLoading(false);
        return signature;

      } catch (error) {
        console.error(`Escrow transfer attempt ${attempts + 1} failed:`, error);
        attempts++;
        
        if (attempts < maxAttempts) {
          setCurrentRPCIndex((prev) => (prev + 1) % RPC_ENDPOINTS.length);
          await new Promise(resolve => setTimeout(resolve, 1000));
        } else {
          const errorMsg = error instanceof Error ? error.message : 'Transaction failed';
          
          if (errorMsg.includes('User rejected') || errorMsg.includes('rejected')) {
            toast({
              title: "Transaction Cancelled",
              description: "Transaction was cancelled by user.",
              variant: "destructive"
            });
          } else {
            toast({
              title: "Transaction Failed",
              description: errorMsg,
              variant: "destructive"
            });
          }
          setLoading(false);
          return null;
        }
      }
    }

    setLoading(false);
    return null;
  }, [selectedWallet, walletAddress, toast, currentRPCIndex]);

  return {
    sendSOLToEscrow,
    loading,
    escrowWallet: ESCROW_WALLET,
  };
};
