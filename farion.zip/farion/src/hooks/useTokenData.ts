import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface CreatedToken {
  id: string;
  creator_wallet_address: string;
  creator_username: string;
  name: string;
  symbol: string;
  description: string | null;
  logo_url: string | null;
  tax_percentage: number;
  total_supply: number;
  current_supply: number;
  market_cap: number;
  holders_count: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface TokenBalance {
  id: string;
  wallet_address: string;
  username: string;
  auk_balance: number;
  token_id: string | null;
  token_balance: number;
  created_at: string;
  updated_at: string;
}

export interface TokenTransaction {
  id: string;
  token_id: string;
  wallet_address: string;
  username: string;
  transaction_type: 'buy' | 'sell';
  token_amount: number;
  auk_amount: number;
  token_price: number;
  tax_amount: number;
  market_cap_before: number;
  market_cap_after: number;
  created_at: string;
}

export const useTokenData = () => {
  const [tokens, setTokens] = useState<CreatedToken[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTokens = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error } = await supabase
        .from('created_tokens')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTokens(data || []);
    } catch (err) {
      console.error('Error fetching tokens:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch tokens');
    } finally {
      setLoading(false);
    }
  };

  const getTokenById = async (tokenId: string): Promise<CreatedToken | null> => {
    try {
      const { data, error } = await supabase
        .from('created_tokens')
        .select('*')
        .eq('id', tokenId)
        .single();

      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Error fetching token:', err);
      return null;
    }
  };

  const createToken = async (tokenData: {
    name: string;
    symbol: string;
    description?: string;
    logo_url?: string;
    tax_percentage: number;
    creator_wallet_address: string;
    creator_username: string;
  }): Promise<CreatedToken | null> => {
    try {
      const { data, error } = await supabase
        .from('created_tokens')
        .insert({
          ...tokenData,
          contract_address: `AUK${Date.now()}`,
          creator_address: tokenData.creator_wallet_address
        } as any)
        .select()
        .single();

      if (error) throw error;
      return data as CreatedToken;
    } catch (err) {
      console.error('Error creating token:', err);
      return null;
    }
  };

  useEffect(() => {
    fetchTokens();
  }, []);

  return {
    tokens,
    loading,
    error,
    fetchTokens,
    getTokenById,
    createToken
  };
};