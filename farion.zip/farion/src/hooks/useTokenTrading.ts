import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const AUK_USD_RATE = 180; // $1 AUK = $180

export interface TradeCalculation {
  tokenPrice: number;
  aukNeeded: number;
  taxAmount: number;
  finalAukAmount: number;
  newMarketCap: number;
}

export const useTokenTrading = () => {
  const [loading, setLoading] = useState(false);

  const calculateTradeAmount = useCallback((
    marketCap: number,
    totalSupply: number,
    tokenAmount: number,
    taxPercentage: number,
    isBuy: boolean
  ): TradeCalculation => {
    const tokenPrice = marketCap / totalSupply;
    const baseAukNeeded = (tokenAmount * tokenPrice) / AUK_USD_RATE;
    const taxAmount = baseAukNeeded * (taxPercentage / 100);
    const finalAukAmount = baseAukNeeded + taxAmount;
    
    const marketCapChange = finalAukAmount * AUK_USD_RATE;
    const newMarketCap = isBuy ? marketCap + marketCapChange : marketCap - marketCapChange;

    return {
      tokenPrice,
      aukNeeded: baseAukNeeded,
      taxAmount,
      finalAukAmount,
      newMarketCap: Math.max(newMarketCap, 100) // Minimum market cap of $100
    };
  }, []);

  const executeTrade = useCallback(async (
    tokenId: string,
    walletAddress: string,
    username: string,
    tokenAmount: number,
    tradeType: 'buy' | 'sell',
    calculation: TradeCalculation
  ): Promise<boolean> => {
    if (!walletAddress || !username) return false;

    setLoading(true);
    try {
      // Start transaction-like operations
      const { data: tokenData, error: tokenError } = await supabase
        .from('created_tokens')
        .select('*')
        .eq('id', tokenId)
        .single();

      if (tokenError) throw tokenError;

      // Update token market cap
      const { error: updateTokenError } = await supabase
        .from('created_tokens')
        .update({ 
          market_cap: calculation.newMarketCap,
          updated_at: new Date().toISOString()
        })
        .eq('id', tokenId);

      if (updateTokenError) throw updateTokenError;

      // Record transaction
      const { error: transactionError } = await supabase
        .from('token_transactions')
        .insert({
          token_id: tokenId,
          wallet_address: walletAddress,
          username: username,
          transaction_type: tradeType,
          token_amount: tokenAmount,
          auk_amount: calculation.finalAukAmount,
          token_price: calculation.tokenPrice,
          tax_amount: calculation.taxAmount,
          market_cap_before: tokenData.market_cap,
          market_cap_after: calculation.newMarketCap
        });

      if (transactionError) throw transactionError;

      // Update user's AUK balance
      const { data: currentBalance } = await supabase
        .from('token_balances')
        .select('auk_balance')
        .eq('wallet_address', walletAddress)
        .is('token_id', null)
        .single();

      const currentAuk = currentBalance?.auk_balance || 0;
      const newAukBalance = tradeType === 'buy' 
        ? currentAuk - calculation.finalAukAmount 
        : currentAuk + calculation.finalAukAmount;

      const { error: aukBalanceError } = await supabase
        .from('token_balances')
        .upsert({
          wallet_address: walletAddress,
          username: username,
          auk_balance: newAukBalance,
          token_id: null,
          token_balance: 0
        }, { onConflict: 'wallet_address,token_id' });

      if (aukBalanceError) throw aukBalanceError;

      // Update user's token balance
      const { data: currentTokenBalance } = await supabase
        .from('token_balances')
        .select('token_balance')
        .eq('wallet_address', walletAddress)
        .eq('token_id', tokenId)
        .single();

      const currentTokens = currentTokenBalance?.token_balance || 0;
      const newTokenBalance = tradeType === 'buy' 
        ? currentTokens + tokenAmount 
        : currentTokens - tokenAmount;

      const { error: tokenBalanceError } = await supabase
        .from('token_balances')
        .upsert({
          wallet_address: walletAddress,
          username: username,
          auk_balance: 0,
          token_id: tokenId,
          token_balance: newTokenBalance
        }, { onConflict: 'wallet_address,token_id' });

      if (tokenBalanceError) throw tokenBalanceError;

      return true;
    } catch (err) {
      console.error('Error executing trade:', err);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    calculateTradeAmount,
    executeTrade
  };
};