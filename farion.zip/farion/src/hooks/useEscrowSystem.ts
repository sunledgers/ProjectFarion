import { useState, useCallback } from 'react';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ESCROW_WALLET } from '@/config/wallets';
import { HELIUS_RPC_URL } from '@/config/meteora';

export interface EscrowDepositResult {
  success: boolean;
  txSignature?: string;
  solAmount?: number;
  error?: string;
}

export interface EscrowWithdrawResult {
  success: boolean;
  txSignature?: string;
  solAmount?: number;
  error?: string;
}

/**
 * Hook for managing SOL escrow for token trading
 * - Buy: User deposits SOL to escrow, receives tokens
 * - Sell: User returns tokens, receives SOL from escrow
 */
export function useEscrowSystem() {
  const { selectedWallet, walletAddress, username } = useMultiWallet();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const connection = new Connection(HELIUS_RPC_URL, 'confirmed');

  /**
   * Deposit SOL to escrow when buying tokens
   */
  const depositToEscrow = useCallback(async (
    tokenId: string,
    solAmount: number,
    tokenAmount: number
  ): Promise<EscrowDepositResult> => {
    if (!selectedWallet?.adapter?.publicKey || !walletAddress) {
      return { success: false, error: 'Wallet not connected' };
    }

    setLoading(true);
    try {
      const pubkey = selectedWallet.adapter.publicKey;
      const escrowPubkey = new PublicKey(ESCROW_WALLET);

      // Check balance
      const balance = await connection.getBalance(pubkey);
      const requiredLamports = Math.floor(solAmount * LAMPORTS_PER_SOL);
      const estimatedFee = 10000; // ~0.00001 SOL

      if (balance < requiredLamports + estimatedFee) {
        return { 
          success: false, 
          error: `Insufficient balance. Need ${((requiredLamports + estimatedFee) / LAMPORTS_PER_SOL).toFixed(6)} SOL` 
        };
      }

      // Create transfer transaction
      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: pubkey,
          toPubkey: escrowPubkey,
          lamports: requiredLamports,
        })
      );

      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
      transaction.recentBlockhash = blockhash;
      transaction.feePayer = pubkey;

      // Send transaction
      const txSignature = await selectedWallet.adapter.sendTransaction(transaction, connection);
      
      // Confirm transaction
      await connection.confirmTransaction({
        signature: txSignature,
        blockhash,
        lastValidBlockHeight,
      }, 'confirmed');

      // Record escrow transaction in database
      await supabase.from('escrow_transactions').insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        username: username || walletAddress.slice(0, 8),
        transaction_type: 'deposit',
        sol_amount: solAmount,
        token_amount: tokenAmount,
        tx_signature: txSignature,
      });

      // Update token's escrow balance
      const { data: token } = await supabase
        .from('launchpad_tokens')
        .select('escrow_sol_balance')
        .eq('id', tokenId)
        .single();

      const currentEscrowBalance = Number(token?.escrow_sol_balance || 0);
      await supabase
        .from('launchpad_tokens')
        .update({ 
          escrow_sol_balance: currentEscrowBalance + solAmount,
          is_real_token: true,
        })
        .eq('id', tokenId);

      return {
        success: true,
        txSignature,
        solAmount,
      };
    } catch (error: any) {
      console.error('Escrow deposit error:', error);
      
      if (error.message?.includes('User rejected') || error.message?.includes('rejected')) {
        return { success: false, error: 'Transaction cancelled by user' };
      }
      
      return { success: false, error: error.message || 'Failed to deposit to escrow' };
    } finally {
      setLoading(false);
    }
  }, [selectedWallet, walletAddress, username, connection]);

  /**
   * Withdraw SOL from escrow when selling tokens
   * Calls the edge function to process real SOL payout
   */
  const requestWithdrawal = useCallback(async (
    tokenId: string,
    solAmount: number,
    tokenAmount: number
  ): Promise<EscrowWithdrawResult> => {
    if (!walletAddress) {
      return { success: false, error: 'Wallet not connected' };
    }

    setLoading(true);
    try {
      // Check if escrow has sufficient balance
      const { data: token } = await supabase
        .from('launchpad_tokens')
        .select('escrow_sol_balance, symbol')
        .eq('id', tokenId)
        .single();

      const escrowBalance = Number(token?.escrow_sol_balance || 0);
      
      if (escrowBalance < solAmount) {
        return { 
          success: false, 
          error: `Insufficient escrow liquidity. Available: ${escrowBalance.toFixed(6)} SOL` 
        };
      }

      // Create withdrawal record first
      const { data: withdrawalRecord, error: insertError } = await supabase
        .from('escrow_transactions')
        .insert({
          token_id: tokenId,
          wallet_address: walletAddress,
          username: username || walletAddress.slice(0, 8),
          transaction_type: 'withdrawal',
          sol_amount: solAmount,
          token_amount: tokenAmount,
          payout_status: 'pending',
        })
        .select()
        .single();

      if (insertError || !withdrawalRecord) {
        throw new Error('Failed to create withdrawal record');
      }

      // Update escrow balance immediately
      await supabase
        .from('launchpad_tokens')
        .update({ 
          escrow_sol_balance: escrowBalance - solAmount,
        })
        .eq('id', tokenId);

      // Call edge function for real SOL payout
      const { data: payoutResult, error: payoutError } = await supabase.functions.invoke(
        'process-escrow-payout',
        {
          body: {
            transaction_id: withdrawalRecord.id,
            wallet_address: walletAddress,
            sol_amount: solAmount,
            token_id: tokenId,
          },
        }
      );

      if (payoutError) {
        console.error('Payout edge function error:', payoutError);
        toast({
          title: 'Payout Processing',
          description: 'Your sell order is being processed. SOL will arrive shortly.',
          variant: 'default',
        });
        return {
          success: true,
          txSignature: withdrawalRecord.id,
          solAmount,
        };
      }

      if (payoutResult?.success) {
        toast({
          title: 'Sell Complete!',
          description: `${payoutResult.net_payout?.toFixed(6)} SOL sent to your wallet.`,
        });

        return {
          success: true,
          txSignature: payoutResult.tx_signature,
          solAmount: payoutResult.net_payout,
        };
      } else {
        console.error('Payout failed:', payoutResult?.error);
        toast({
          title: 'Payout Pending',
          description: payoutResult?.error || 'Payout will be processed shortly.',
          variant: 'default',
        });
        return {
          success: true,
          txSignature: withdrawalRecord.id,
          solAmount,
        };
      }
    } catch (error: any) {
      console.error('Escrow withdrawal error:', error);
      return { success: false, error: error.message || 'Failed to process withdrawal' };
    } finally {
      setLoading(false);
    }
  }, [walletAddress, username, toast]);
  /**
   * Get escrow balance for a token
   */
  const getEscrowBalance = useCallback(async (tokenId: string): Promise<number> => {
    try {
      const { data } = await supabase
        .from('launchpad_tokens')
        .select('escrow_sol_balance')
        .eq('id', tokenId)
        .single();
      
      return Number(data?.escrow_sol_balance || 0);
    } catch {
      return 0;
    }
  }, []);

  /**
   * Get escrow transaction history for a token
   */
  const getEscrowHistory = useCallback(async (tokenId: string) => {
    try {
      const { data } = await supabase
        .from('escrow_transactions')
        .select('*')
        .eq('token_id', tokenId)
        .order('created_at', { ascending: false });
      
      return data || [];
    } catch {
      return [];
    }
  }, []);

  return {
    depositToEscrow,
    requestWithdrawal,
    getEscrowBalance,
    getEscrowHistory,
    loading,
    escrowWallet: ESCROW_WALLET,
  };
}
