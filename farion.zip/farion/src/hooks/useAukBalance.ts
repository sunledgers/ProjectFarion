import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface AukClaim {
  id: string;
  wallet_address: string;
  username: string;
  claim_amount: number;
  claimed_at: string;
  next_claim_available_at: string;
}

export const useAukBalance = (walletAddress: string | null, username: string | null) => {
  const [aukBalance, setAukBalance] = useState<number>(0);
  const [canClaim, setCanClaim] = useState<boolean>(false);
  const [nextClaimAt, setNextClaimAt] = useState<Date | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchAukBalance = useCallback(async () => {
    if (!walletAddress) return;

    try {
      // Get AUK balance from token_balances table
      const { data: balanceData } = await supabase
        .from('token_balances')
        .select('auk_balance')
        .eq('wallet_address', walletAddress)
        .is('token_id', null)
        .single();

      setAukBalance(balanceData?.auk_balance || 0);

      // Check claim status
      const { data: claimData } = await supabase
        .from('auk_claims')
        .select('next_claim_available_at')
        .eq('wallet_address', walletAddress)
        .order('claimed_at', { ascending: false })
        .limit(1)
        .single();

      if (claimData) {
        const nextClaim = new Date(claimData.next_claim_available_at);
        setNextClaimAt(nextClaim);
        setCanClaim(new Date() >= nextClaim);
      } else {
        setCanClaim(true);
        setNextClaimAt(null);
      }
    } catch (err) {
      console.error('Error fetching AUK balance:', err);
    }
  }, [walletAddress]);

  const claimAuk = async (): Promise<boolean> => {
    if (!walletAddress || !username || !canClaim) return false;

    setLoading(true);
    try {
      // Create claim record
      const { error: claimError } = await supabase
        .from('auk_claims')
        .insert({
          wallet_address: walletAddress,
          username: username,
          amount: 5,
          claim_amount: 5
        } as any);

      if (claimError) throw claimError;

      // Update AUK balance
      const { error: balanceError } = await supabase
        .from('token_balances')
        .upsert({
          wallet_address: walletAddress,
          username: username,
          auk_balance: aukBalance + 5,
          token_id: null,
          balance: 0
        } as any, { onConflict: 'wallet_address,token_id' });

      if (balanceError) throw balanceError;

      await fetchAukBalance();
      return true;
    } catch (err) {
      console.error('Error claiming AUK:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAukBalance();
  }, [fetchAukBalance]);

  return {
    aukBalance,
    canClaim,
    nextClaimAt,
    loading,
    claimAuk,
    refreshBalance: fetchAukBalance
  };
};