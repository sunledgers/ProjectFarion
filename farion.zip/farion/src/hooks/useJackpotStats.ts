import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface JackpotStats {
  totalRounds: number;
  totalPot: number;
  averagePot: number;
  participantsCount: number;
}

interface JackpotWinner {
  id: string;
  username: string;
  wallet_address: string;
  winnings_amount: number;
  created_at: string;
  round_number: number;
}

export const useJackpotStats = () => {
  const [stats, setStats] = useState<JackpotStats>({
    totalRounds: 0,
    totalPot: 0,
    averagePot: 0,
    participantsCount: 0
  });
  const [recentWinners, setRecentWinners] = useState<JackpotWinner[]>([]);
  const [loading, setLoading] = useState(true);

  const loadStats = async () => {
    try {
      setLoading(true);

      // Get completed rounds stats
      const { data: roundsData } = await supabase
        .from('jackpot_rounds')
        .select('total_pot, participant_count')
        .eq('status', 'completed');

      // Get recent winners with round information
      const { data: winnersData } = await supabase
        .from('jackpot_winners')
        .select(`
          *,
          jackpot_rounds!inner(round_number)
        `)
        .order('created_at', { ascending: false })
        .limit(10);

      if (roundsData) {
        const totalRounds = roundsData.length;
        const totalPot = roundsData.reduce((sum: number, round: any) => sum + Number(round.total_pot), 0);
        const totalParticipants = roundsData.reduce((sum: number, round: any) => sum + Number(round.participant_count), 0);
        const averagePot = totalRounds > 0 ? totalPot / totalRounds : 0;

        setStats({
          totalRounds,
          totalPot,
          averagePot,
          participantsCount: totalParticipants
        });
      }

      if (winnersData) {
        setRecentWinners(winnersData.map((winner: any) => ({
          id: winner.id,
          username: winner.username,
          wallet_address: winner.wallet_address,
          winnings_amount: Number(winner.winnings_amount),
          created_at: winner.created_at,
          round_number: winner.jackpot_rounds?.round_number || 1
        })));
      }
    } catch (error) {
      console.error('Error loading jackpot stats:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();

    // Subscribe to winner updates using raw channel
    const winnersChannel = supabase
      .channel('jackpot_winners_changes')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'jackpot_winners'
      }, () => {
        loadStats();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(winnersChannel);
    };
  }, []);

  return {
    stats,
    recentWinners,
    loading,
    refreshStats: loadStats
  };
};