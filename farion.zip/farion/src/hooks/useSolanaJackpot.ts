import { useState, useEffect, useCallback } from 'react';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { PROJECT_WALLET as PROJECT_WALLET_ADDRESS } from '@/config/wallets';

interface JackpotParticipant {
  id: string;
  wallet_address: string;
  username: string;
  bet_amount: number;
  odds_percentage: number;
  joined_at: string;
}

interface JackpotRound {
  id: string;
  round_number: number;
  status: string;
  total_pot: number;
  participant_count: number;
  min_participants: number;
  min_bet_amount: number;
  started_at?: string;
  ends_at?: string;
  winner_wallet_address?: string;
  winner_username?: string;
}

export const useSolanaJackpot = () => {
  const { selectedWallet, walletAddress, username } = useMultiWallet();
  const { toast } = useToast();
  
  // Real database state
  const [participants, setParticipants] = useState<JackpotParticipant[]>([]);
  const [currentRound, setCurrentRound] = useState<JackpotRound | null>(null);
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [winner, setWinner] = useState<{wallet: string; username: string; amount: number} | null>(null);
  const [showWinnerAnimation, setShowWinnerAnimation] = useState(false);
  
  // Mainnet Helius RPC endpoints for production
  const RPC_ENDPOINTS = [
    'https://mainnet.helius-rpc.com/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186',
    'https://rpc.helius.xyz/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186',
  ];
  
  const [currentRPCIndex, setCurrentRPCIndex] = useState(0);
  const connection = new Connection(RPC_ENDPOINTS[currentRPCIndex], 'confirmed');
  const PROJECT_WALLET = new PublicKey(PROJECT_WALLET_ADDRESS);
  
  const MIN_BET_SOL = 0.01;
  const MAX_BET_SOL = 10;
  const MIN_PARTICIPANTS = 5;
  const COUNTDOWN_SECONDS = 120;

  // Get or create active round
  const getActiveRound = useCallback(async () => {
    try {
      const { data, error } = await supabase.rpc('get_or_create_active_jackpot_round');
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting active round:', error);
      return null;
    }
  }, []);

  // Load current round and participants
  const loadJackpotData = useCallback(async () => {
    const roundId = await getActiveRound();
    if (!roundId) return;

    // Get round details
    const { data: roundData } = await supabase
      .from('jackpot_rounds')
      .select('*')
      .eq('id', roundId)
      .single();

    if (roundData) {
      setCurrentRound(roundData);
    }

    // Get participants
    const { data: participantsData } = await supabase
      .from('jackpot_participants')
      .select('*')
      .eq('round_id', roundId)
      .order('joined_at', { ascending: true });

    if (participantsData) {
      setParticipants(participantsData.map((p: any) => ({
        id: p.id,
        wallet_address: p.wallet_address,
        username: p.username,
        bet_amount: Number(p.bet_amount),
        odds_percentage: Number(p.odds_percentage),
        joined_at: p.joined_at
      })));
    }
  }, [getActiveRound]);

  // Helper function to try different RPC endpoints
  const getConnectionWithFallback = useCallback(() => {
    return new Connection(RPC_ENDPOINTS[currentRPCIndex], 'confirmed');
  }, [currentRPCIndex]);

  // Real jackpot system with database integration
  const joinJackpot = async (betAmountSOL: number) => {
    console.log('🎰 Starting joinJackpot function...');
    console.log('🔍 Debug Info:', {
      selectedWallet: !!selectedWallet,
      selectedWalletAdapter: !!selectedWallet?.adapter,
      walletAddress,
      username,
      betAmountSOL,
      currentRound,
      participants: participants.length,
      loading,
      walletConnected: !!selectedWallet?.adapter?.connected,
      walletPublicKey: selectedWallet?.adapter?.publicKey?.toString()
    });

    // Enhanced wallet connection checks
    if (!selectedWallet?.adapter) {
      console.log('❌ No wallet adapter found');
      toast({
        title: "Wallet Not Found",
        description: "Please select and connect a wallet first.",
        variant: "destructive"
      });
      return;
    }

    if (!selectedWallet.adapter.connected || !selectedWallet.adapter.publicKey) {
      console.log('❌ Wallet not connected or no public key');
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet first.",
        variant: "destructive"
      });
      return;
    }

    if (!walletAddress || !username) {
      console.log('❌ Missing wallet address or username');
      toast({
        title: "Profile Missing",
        description: "Please ensure your wallet is properly connected.",
        variant: "destructive"
      });
      return;
    }

    if (!currentRound) {
      console.log('❌ No current round available');
      toast({
        title: "No Active Round",
        description: "No jackpot round is currently available.",
        variant: "destructive"
      });
      return;
    }

    if (betAmountSOL < MIN_BET_SOL || betAmountSOL > MAX_BET_SOL) {
      console.log('❌ Invalid bet amount:', betAmountSOL);
      toast({
        title: "Invalid Bet Amount",
        description: `Bet must be between ${MIN_BET_SOL} and ${MAX_BET_SOL} SOL.`,
        variant: "destructive"
      });
      return;
    }

    console.log('✅ All validations passed, setting loading...');
    setLoading(true);
    
    try {
      // Check if user already participated
      if (participants.some(p => p.wallet_address === walletAddress)) {
        console.log('❌ User already joined this round');
        toast({
          title: "Already Joined",
          description: "You have already joined this jackpot round.",
          variant: "destructive"
        });
        setLoading(false);
        return;
      }

      console.log('🔍 Starting transaction process...');
      
      // Try multiple RPC endpoints for reliability
      let currentConnection = getConnectionWithFallback();
      let attempts = 0;
      const maxAttempts = RPC_ENDPOINTS.length;

      while (attempts < maxAttempts) {
        try {
          console.log(`🔄 Transaction attempt ${attempts + 1}/${maxAttempts}`);
          console.log(`Using RPC endpoint: ${RPC_ENDPOINTS[currentRPCIndex]}`);
          
          // Check wallet balance first
          const fromPubkey = new PublicKey(walletAddress);
          console.log('📊 Checking wallet balance...');
          
          const balance = await currentConnection.getBalance(fromPubkey);
          const requiredLamports = Math.floor(betAmountSOL * LAMPORTS_PER_SOL);
          const estimatedFee = 5000; // ~0.000005 SOL for transaction fee
          
          console.log('💰 Balance info:', {
            balanceSOL: balance / LAMPORTS_PER_SOL,
            requiredSOL: betAmountSOL,
            estimatedFeeSOL: estimatedFee / LAMPORTS_PER_SOL,
            totalNeededSOL: (requiredLamports + estimatedFee) / LAMPORTS_PER_SOL
          });
          
          if (balance < requiredLamports + estimatedFee) {
            const errorMsg = `You need at least ${((requiredLamports + estimatedFee) / LAMPORTS_PER_SOL).toFixed(6)} SOL (including transaction fee).`;
            console.log('❌ Insufficient balance:', errorMsg);
            toast({
              title: "Insufficient Balance",
              description: errorMsg,
              variant: "destructive"
            });
            setLoading(false);
            return;
          }

          console.log('📝 Creating transaction...');
          // Create transaction
          const transaction = new Transaction().add(
            SystemProgram.transfer({
              fromPubkey,
              toPubkey: PROJECT_WALLET,
              lamports: requiredLamports,
            })
          );

          console.log('📡 Getting latest blockhash...');
          // Get recent blockhash
          const { blockhash, lastValidBlockHeight } = await currentConnection.getLatestBlockhash('finalized');
          transaction.recentBlockhash = blockhash;
          transaction.feePayer = fromPubkey;
          
          console.log('✅ Blockhash obtained:', blockhash.slice(0, 8) + '...');

          console.log('✍️ Requesting wallet signature...');
          console.log('🔍 Wallet adapter capabilities:', {
            hasSignTransaction: 'signTransaction' in selectedWallet.adapter,
            hasSendTransaction: 'sendTransaction' in selectedWallet.adapter,
            hasSignAndSendTransaction: 'signAndSendTransaction' in selectedWallet.adapter,
            connected: selectedWallet.adapter.connected,
            publicKey: selectedWallet.adapter.publicKey?.toString()
          });
          
          // Enhanced transaction signing with multiple wallet method support
          let signature;
          
          if ('sendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.sendTransaction === 'function') {
            console.log('📤 Using sendTransaction method...');
            signature = await selectedWallet.adapter.sendTransaction(transaction, currentConnection);
            console.log('✅ Transaction sent via sendTransaction, signature:', signature);
          } else if ('signAndSendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signAndSendTransaction === 'function') {
            console.log('📤 Using signAndSendTransaction method...');
            signature = await selectedWallet.adapter.signAndSendTransaction(transaction);
            console.log('✅ Transaction sent via signAndSendTransaction, signature:', signature);
          } else if ('signTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signTransaction === 'function') {
            console.log('📤 Using signTransaction method...');
            const signedTransaction = await selectedWallet.adapter.signTransaction(transaction);
            signature = await currentConnection.sendRawTransaction(signedTransaction.serialize());
            console.log('✅ Transaction sent via signTransaction + sendRawTransaction, signature:', signature);
          } else {
            throw new Error(`Wallet ${selectedWallet.adapter.name || 'Unknown'} does not support any known transaction signing methods`);
          }
          
          console.log('⏳ Confirming transaction...');
          // Confirm transaction
          const confirmation = await currentConnection.confirmTransaction({
            signature,
            blockhash,
            lastValidBlockHeight,
          }, 'confirmed');
          
          if (confirmation.value.err) {
            console.log('❌ Transaction confirmation error:', confirmation.value.err);
            throw new Error(`Transaction failed: ${confirmation.value.err}`);
          }
          
          console.log('✅ Transaction confirmed!');

          console.log('🔍 Getting active round...');
          // Get active round
          const roundId = await getActiveRound();
          if (!roundId) throw new Error('No active round available');
          
          console.log('✅ Active round ID:', roundId);

          console.log('💾 Adding participant to database...');
          // Add participant to database
          const { error: insertError } = await supabase
            .from('jackpot_participants')
            .insert({
              round_id: roundId,
              wallet_address: walletAddress,
              username: username,
              amount: betAmountSOL,
              bet_amount: betAmountSOL,
              transaction_verified: true
            } as any);

          if (insertError) {
            console.error('❌ Database insertion error:', insertError);
            throw insertError;
          }
          
          console.log('✅ Participant added to database');

          toast({
            title: "Successfully Joined Jackpot! 🎯",
            description: `Bet placed: ${betAmountSOL} SOL`,
          });

          console.log('🔄 Refreshing jackpot data...');
          // Refresh data
          await loadJackpotData();
          console.log('✅ Data refreshed successfully');

          setLoading(false);
          return; // Success, exit function

        } catch (error) {
          console.error(`❌ Attempt ${attempts + 1} failed:`, error);
          attempts++;
          
          if (attempts < maxAttempts) {
            console.log(`⏳ Trying next RPC endpoint in 1 second...`);
            // Try next RPC endpoint
            setCurrentRPCIndex((prev) => (prev + 1) % RPC_ENDPOINTS.length);
            currentConnection = new Connection(RPC_ENDPOINTS[(currentRPCIndex + 1) % RPC_ENDPOINTS.length], 'confirmed');
            
            // Add a small delay before retrying
            await new Promise(resolve => setTimeout(resolve, 1000));
          } else {
            // All RPC endpoints failed
            console.log('❌ All RPC endpoints failed');
            const errorMsg = error instanceof Error ? error.message : 'Network connection failed';
            toast({
              title: "Transaction Failed",
              description: `Failed to process transaction: ${errorMsg}. Please try again.`,
              variant: "destructive"
            });
            setLoading(false);
            return;
          }
        }
      }
      
    } catch (error) {
      console.error('❌ Final error in joinJackpot:', error);
      const errorMsg = error instanceof Error ? error.message : 'Unknown error occurred';
      
      if (errorMsg.includes('User rejected') || errorMsg.includes('rejected')) {
        toast({
          title: "Transaction Cancelled",
          description: "Transaction was cancelled by user.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Transaction Failed", 
          description: `Failed to join jackpot: ${errorMsg}`,
          variant: "destructive"
        });
      }
    } finally {
      console.log('🏁 Setting loading to false');
      setLoading(false);
    }
  };

  // Real-time subscriptions
  useEffect(() => {
    loadJackpotData();

    // Subscribe to round changes
    const roundsChannel = supabase
      .channel('jackpot_rounds_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'jackpot_rounds'
      }, () => {
        loadJackpotData();
      })
      .subscribe();

    // Subscribe to participant changes
    const participantsChannel = supabase
      .channel('jackpot_participants_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'jackpot_participants'
      }, () => {
        loadJackpotData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(roundsChannel);
      supabase.removeChannel(participantsChannel);
    };
  }, [loadJackpotData]);

  // Countdown timer based on round status
  useEffect(() => {
    if (!currentRound) return;

    if (currentRound.status === 'active' && currentRound.ends_at) {
      const endTime = new Date(currentRound.ends_at).getTime();
      const now = Date.now();
      const remaining = Math.max(0, Math.floor((endTime - now) / 1000));
      
      setCountdown(remaining);
      
      if (remaining > 0) {
        const timer = setInterval(() => {
          const newNow = Date.now();
          const newRemaining = Math.max(0, Math.floor((endTime - newNow) / 1000));
          setCountdown(newRemaining);
          
          if (newRemaining === 0) {
            clearInterval(timer);
            // Trigger winner draw by calling edge function
            triggerWinnerDraw();
          }
        }, 1000);
        
        return () => clearInterval(timer);
      } else {
        // Timer already at 0, trigger draw
        triggerWinnerDraw();
      }
    } else {
      setCountdown(0);
    }
  }, [currentRound]);

  // Function to trigger winner draw via edge function
  const triggerWinnerDraw = async () => {
    try {
      console.log('🎯 Triggering winner draw...');
      const response = await supabase.functions.invoke('jackpot-draw-winner');
      console.log('🎰 Winner draw response:', response);
      
      if (response.data?.results?.length > 0) {
        const winnerData = response.data.results[0]?.result;
        if (winnerData?.success) {
          setWinner({
            wallet: winnerData.winner_wallet,
            username: winnerData.winner_username,
            amount: winnerData.winner_share
          });
          setShowWinnerAnimation(true);
          
          toast({
            title: "🎉 Winner Selected!",
            description: `${winnerData.winner_username} won ${winnerData.winner_share.toFixed(3)} SOL!`,
          });
          
          // Hide animation after 10 seconds
          setTimeout(() => {
            setShowWinnerAnimation(false);
            setWinner(null);
          }, 10000);
        }
      }
      
      // Refresh data after draw
      await loadJackpotData();
    } catch (error) {
      console.error('Error triggering winner draw:', error);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const totalPotSOL = participants.reduce((sum, p) => sum + p.bet_amount, 0);
  const projectFeeSOL = totalPotSOL * 0.1;
  const winnerPotSOL = totalPotSOL - projectFeeSOL;
  const isRoundActive = currentRound?.status === 'active';
  
  // Enhanced canJoin logic - can join when round is 'waiting' or 'active' (before timer ends)
  const hasWallet = !!(selectedWallet?.adapter?.connected && walletAddress);
  const hasValidRound = !!(currentRound && (currentRound.status === 'waiting' || currentRound.status === 'active'));
  const notAlreadyJoined = !participants.some(p => p.wallet_address === walletAddress);
  const canJoin = hasWallet && hasValidRound && notAlreadyJoined && !loading;
  
  console.log('🔍 canJoin calculation:', {
    hasWallet,
    hasValidRound,
    notAlreadyJoined,
    loading,
    canJoin,
    currentRoundStatus: currentRound?.status,
    participantCount: participants.length
  });
  
  const needsMorePlayers = participants.length < MIN_PARTICIPANTS;

  return {
    // Data
    currentRound: currentRound || {
      id: '',
      round_number: 0,
      status: 'waiting',
      total_pot: 0,
      participant_count: 0,
      min_participants: MIN_PARTICIPANTS,
      min_bet_amount: MIN_BET_SOL
    },
    participants,
    totalPotSOL,
    projectFeeSOL,
    winnerPotSOL,
    
    // State
    loading,
    countdown: formatTime(countdown),
    isRoundActive,
    canJoin,
    needsMorePlayers,
    winner,
    showWinnerAnimation,
    
    // Constants
    MIN_BET_SOL,
    MAX_BET_SOL,
    MIN_PARTICIPANTS,
    
    // Actions
    joinJackpot,
    refreshData: loadJackpotData,
  };
};