import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { BALANCE_REFRESH_INTERVAL } from '@/config/contract';

export interface TokenBalanceData {
  tokenBalance: number;
  supplyPercentage: number;
  verificationStatus: 'verified' | 'no_tokens' | 'pending' | 'error';
  lastUpdated: Date;
}

export const useTokenBalance = (walletAddress: string | null) => {
  const [balanceData, setBalanceData] = useState<TokenBalanceData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTokenBalance = useCallback(async () => {
    if (!walletAddress) {
      setBalanceData(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: functionError } = await supabase.functions.invoke('verify-token-holdings', {
        body: { walletAddress }
      });

      if (functionError) {
        throw new Error(functionError.message);
      }

      setBalanceData({
        tokenBalance: data.tokenBalance,
        supplyPercentage: data.supplyPercentage,
        verificationStatus: data.verificationStatus,
        lastUpdated: new Date()
      });
    } catch (err) {
      console.error('Error fetching token balance:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch token balance');
      setBalanceData(prev => prev ? { ...prev, verificationStatus: 'error' } : null);
    } finally {
      setLoading(false);
    }
  }, [walletAddress]);

  // Initial fetch and periodic updates
  useEffect(() => {
    if (walletAddress) {
      fetchTokenBalance();
      
      const interval = setInterval(fetchTokenBalance, BALANCE_REFRESH_INTERVAL);
      return () => clearInterval(interval);
    }
  }, [walletAddress, fetchTokenBalance]);

  return {
    balanceData,
    loading,
    error,
    refreshBalance: fetchTokenBalance
  };
};