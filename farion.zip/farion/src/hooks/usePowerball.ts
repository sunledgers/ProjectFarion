import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface PowerballRound {
  id: string;
  round_number: number;
  status: 'waiting' | 'active' | 'completed' | 'cancelled';
  volume_threshold: number;
  current_volume: number;
  prize_pool: number;
  creator_fee: number;
  winner_wallet_address?: string;
  winner_username?: string;
  started_at: string;
  ends_at: string;
  completed_at?: string;
  participant_count: number;
  created_at: string;
  updated_at: string;
}

export interface PowerballParticipant {
  id: string;
  round_id: string;
  wallet_address: string;
  username: string;
  token_balance: number;
  qualification_verified: boolean;
  qualification_checked_at?: string;
  joined_at: string;
}

export interface PowerballWinner {
  id: string;
  round_id: string;
  wallet_address: string;
  username: string;
  prize_amount: number;
  volume_at_win: number;
  token_balance_at_win: number;
  payout_completed: boolean;
  payout_completed_at?: string;
  created_at: string;
}

export const usePowerball = () => {
  const [currentRound, setCurrentRound] = useState<PowerballRound | null>(null);
  const [participants, setParticipants] = useState<PowerballParticipant[]>([]);
  const [recentWinners, setRecentWinners] = useState<PowerballWinner[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [isUserQualified, setIsUserQualified] = useState(false);

  // Load current round data
  const loadRoundData = useCallback(async () => {
    try {
      console.log('Loading Powerball round data...');
      
      // Get current round - use maybeSingle to handle no data gracefully
      const { data: roundData, error: roundError } = await supabase
        .from('powerball_rounds')
        .select('*')
        .eq('status', 'waiting')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (roundError) {
        console.error('Error fetching round data:', roundError);
        throw roundError;
      }

      console.log('Round data loaded:', roundData);

      if (roundData) {
        console.log('Setting current round:', roundData);
        setCurrentRound(roundData as PowerballRound);
        
        // Calculate time remaining
        const endTime = new Date(roundData.ends_at).getTime();
        const now = new Date().getTime();
        setTimeRemaining(Math.max(0, endTime - now));

        // Load participants for current round
        const { data: participantsData, error: participantsError } = await supabase
          .from('powerball_participants')
          .select('*')
          .eq('round_id', roundData.id)
          .eq('qualification_verified', true)
          .order('joined_at', { ascending: false });

        if (participantsError) {
          console.error('Error fetching participants:', participantsError);
        } else {
          console.log('Participants loaded:', participantsData?.length || 0);
          setParticipants(participantsData || []);
        }
      } else {
        console.log('No active round found');
        setCurrentRound(null);
        setParticipants([]);
      }

      // Load recent winners
      const { data: winnersData, error: winnersError } = await supabase
        .from('powerball_winners')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (winnersError) {
        console.error('Error fetching winners:', winnersError);
      } else {
        console.log('Winners loaded:', winnersData?.length || 0);
        setRecentWinners(winnersData || []);
      }

    } catch (error) {
      console.error('Error loading powerball data:', error);
      // Set fallback state to prevent crashes
      setCurrentRound(null);
      setParticipants([]);
      setRecentWinners([]);
    } finally {
      console.log('Loading complete');
      setLoading(false);
    }
  }, []);

  // Verify user qualification
  const verifyQualification = useCallback(async (walletAddress: string, username: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('powerball-verify-holder', {
        body: { walletAddress, username }
      });

      if (error) throw error;

      setIsUserQualified(data.isQualified);
      return data;
    } catch (error) {
      console.error('Error verifying qualification:', error);
      return { success: false, error: error.message };
    }
  }, []);

  // Update volume data
  const updateVolumeData = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('powerball-volume-tracker');
      
      if (error) throw error;
      
      // Refresh round data after volume update
      await loadRoundData();
      
      return data;
    } catch (error) {
      console.error('Error updating volume:', error);
      return { success: false, error: error.message };
    }
  }, [loadRoundData]);

  // Calculate progress percentage
  const getVolumeProgress = useCallback(() => {
    if (!currentRound) return 0;
    return Math.min((currentRound.current_volume / currentRound.volume_threshold) * 100, 100);
  }, [currentRound]);

  // Format time remaining
  const formatTimeRemaining = useCallback(() => {
    if (timeRemaining <= 0) return '00:00:00';
    
    const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
    const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }, [timeRemaining]);

  // Timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      if (currentRound) {
        const endTime = new Date(currentRound.ends_at).getTime();
        const now = new Date().getTime();
        const remaining = Math.max(0, endTime - now);
        setTimeRemaining(remaining);
        
        // If time is up, refresh data
        if (remaining === 0) {
          loadRoundData();
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [currentRound, loadRoundData]);

  // Initial load and periodic updates
  useEffect(() => {
    loadRoundData();
    
    // Update volume data every 30 seconds
    const volumeTimer = setInterval(updateVolumeData, 30000);
    
    return () => clearInterval(volumeTimer);
  }, [loadRoundData, updateVolumeData]);

  // Real-time subscriptions
  useEffect(() => {
    const roundChannel = supabase
      .channel('powerball-rounds')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'powerball_rounds'
      }, () => {
        loadRoundData();
      })
      .subscribe();

    const participantsChannel = supabase
      .channel('powerball-participants')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'powerball_participants'
      }, () => {
        loadRoundData();
      })
      .subscribe();

    const winnersChannel = supabase
      .channel('powerball-winners')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'powerball_winners'
      }, () => {
        loadRoundData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(roundChannel);
      supabase.removeChannel(participantsChannel);
      supabase.removeChannel(winnersChannel);
    };
  }, [loadRoundData]);

  return {
    currentRound,
    participants,
    recentWinners,
    loading,
    timeRemaining,
    isUserQualified,
    verifyQualification,
    updateVolumeData,
    getVolumeProgress,
    formatTimeRemaining,
    refreshData: loadRoundData
  };
};