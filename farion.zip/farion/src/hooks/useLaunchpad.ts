import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { PROJECT_WALLET } from '@/config/wallets';
import { v4 as uuidv4 } from 'uuid';

export interface LaunchpadToken {
  id: string;
  contract_address: string;
  name: string;
  symbol: string;
  description: string | null;
  logo_url: string | null;
  creator_wallet: string;
  creator_username: string | null;
  bonding_curve_progress: number;
  total_supply: number;
  current_supply: number;
  current_price: number;
  market_cap: number;
  volume_24h: number;
  holder_count: number;
  is_graduated: boolean;
  graduation_threshold: number;
  created_at: string;
  price_change_24h?: number; // Percentage change
}

export interface LaunchpadTrade {
  id: string;
  token_id: string;
  wallet_address: string;
  username: string | null;
  trade_type: 'buy' | 'sell';
  sol_amount: number;
  token_amount: number;
  price_at_trade: number;
  created_at: string;
}

export interface TraderStats {
  wallet_address: string;
  username: string | null;
  total_volume: number;
  total_trades: number;
  buy_volume: number;
  sell_volume: number;
  estimated_profit: number;
  last_trade_at: string;
}

// Generate a "far" suffix contract address
const generateFarAddress = (): string => {
  const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let address = '';
  for (let i = 0; i < 40; i++) {
    address += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return address + 'far';
};

// Calculate bonding curve price
const calculatePrice = (supply: number, totalSupply: number): number => {
  const ratio = 1 - (supply / totalSupply);
  const basePrice = 0.000001;
  const maxPrice = 0.001;
  return basePrice + (ratio * ratio * (maxPrice - basePrice));
};

export const useLaunchpad = () => {
  const { walletAddress, username, selectedWallet } = useMultiWallet();
  const { toast } = useToast();
  const [tokens, setTokens] = useState<LaunchpadToken[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [trading, setTrading] = useState(false);

  const RPC_ENDPOINT = 'https://mainnet.helius-rpc.com/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186';

  // Upload logo to Supabase storage
  const uploadLogo = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${uuidv4()}.${fileExt}`;
      const filePath = `token-logos/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('memes')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('memes')
        .getPublicUrl(filePath);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload token logo. Please try again.",
        variant: "destructive"
      });
      return null;
    }
  };

  // Load all tokens with 24h price change
  const loadTokens = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('launchpad_tokens')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Get 24h ago timestamp
      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      
      // Fetch earliest trade within last 24h for each token to calculate price change
      const tokensWithPriceChange = await Promise.all(
        ((data as LaunchpadToken[]) || []).map(async (token) => {
          const { data: oldestTrade } = await supabase
            .from('launchpad_trades')
            .select('price_at_trade')
            .eq('token_id', token.id)
            .gte('created_at', twentyFourHoursAgo)
            .order('created_at', { ascending: true })
            .limit(1)
            .maybeSingle();
          
          let priceChange24h = 0;
          if (oldestTrade && (oldestTrade as any).price_at_trade > 0) {
            const oldPrice = (oldestTrade as any).price_at_trade;
            priceChange24h = ((token.current_price - oldPrice) / oldPrice) * 100;
          }
          
          return {
            ...token,
            price_change_24h: priceChange24h
          };
        })
      );
      
      setTokens(tokensWithPriceChange);
    } catch (error) {
      console.error('Error loading tokens:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Create a new token
  const createToken = async (
    name: string,
    symbol: string,
    description: string,
    logoUrl: string | null
  ) => {
    if (!walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to create a token.",
        variant: "destructive"
      });
      return null;
    }

    // Validate symbol ends with "far"
    const finalSymbol = symbol.toUpperCase().endsWith('FAR') 
      ? symbol.toUpperCase() 
      : `${symbol.toUpperCase()}FAR`;

    setCreating(true);
    try {
      const contractAddress = generateFarAddress();
      const initialPrice = 0.000001;
      const totalSupply = 1000000000;

      const { data, error } = await supabase
        .from('launchpad_tokens')
        .insert({
          contract_address: contractAddress,
          name,
          symbol: finalSymbol,
          description,
          logo_url: logoUrl,
          creator_wallet: walletAddress,
          creator_username: username,
          total_supply: totalSupply,
          current_supply: totalSupply,
          current_price: initialPrice,
          market_cap: totalSupply * initialPrice,
          bonding_curve_progress: 0,
          holder_count: 1
        } as any)
        .select()
        .single();

      if (error) throw error;

      // Add creator as first holder
      await supabase
        .from('launchpad_holders')
        .insert({
          token_id: data.id,
          wallet_address: walletAddress,
          username: username,
          balance: 0
        } as any);

      toast({
        title: "Token Created! 🚀",
        description: `${name} (${finalSymbol}) is now live!`,
      });

      await loadTokens();
      return data as LaunchpadToken;
    } catch (error) {
      console.error('Error creating token:', error);
      toast({
        title: "Creation Failed",
        description: "Failed to create token. Please try again.",
        variant: "destructive"
      });
      return null;
    } finally {
      setCreating(false);
    }
  };

  // Buy tokens
  const buyTokens = async (tokenId: string, solAmount: number) => {
    if (!walletAddress || !username || !selectedWallet?.adapter) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to buy tokens.",
        variant: "destructive"
      });
      return false;
    }

    const token = tokens.find(t => t.id === tokenId);
    if (!token) {
      toast({
        title: "Token Not Found",
        description: "The token you're trying to buy doesn't exist.",
        variant: "destructive"
      });
      return false;
    }

    setTrading(true);
    try {
      // Process SOL payment
      const connection = new Connection(RPC_ENDPOINT, 'confirmed');
      const fromPubkey = new PublicKey(walletAddress);
      const toPubkey = new PublicKey(PROJECT_WALLET);
      const lamports = Math.floor(solAmount * LAMPORTS_PER_SOL);

      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey,
          toPubkey,
          lamports,
        })
      );

      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
      transaction.recentBlockhash = blockhash;
      transaction.feePayer = fromPubkey;

      let signature: string;
      if ('sendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.sendTransaction === 'function') {
        signature = await selectedWallet.adapter.sendTransaction(transaction, connection);
      } else if ('signTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signTransaction === 'function') {
        const signedTx = await selectedWallet.adapter.signTransaction(transaction);
        signature = await connection.sendRawTransaction(signedTx.serialize());
      } else {
        throw new Error('Wallet does not support transaction signing');
      }

      await connection.confirmTransaction({ signature, blockhash, lastValidBlockHeight }, 'confirmed');

      // Calculate tokens to receive based on bonding curve
      const tokenAmount = solAmount / token.current_price;
      const newSupply = token.current_supply - tokenAmount;
      const newPrice = calculatePrice(newSupply, token.total_supply);
      const newProgress = ((token.total_supply - newSupply) / token.total_supply) * 100;

      // Record trade
      await supabase.from('launchpad_trades').insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        username: username,
        trade_type: 'buy',
        sol_amount: solAmount,
        token_amount: tokenAmount,
        price_at_trade: token.current_price,
        tx_signature: signature
      } as any);

      // Update token state
      await supabase
        .from('launchpad_tokens')
        .update({
          current_supply: newSupply,
          current_price: newPrice,
          bonding_curve_progress: newProgress,
          market_cap: newSupply * newPrice,
          volume_24h: token.volume_24h + solAmount,
          is_graduated: newProgress >= token.graduation_threshold
        } as any)
        .eq('id', tokenId);

      // Update or create holder record
      const { data: existingHolder } = await supabase
        .from('launchpad_holders')
        .select('*')
        .eq('token_id', tokenId)
        .eq('wallet_address', walletAddress)
        .maybeSingle();

      if (existingHolder) {
        await supabase
          .from('launchpad_holders')
          .update({ balance: (existingHolder as any).balance + tokenAmount } as any)
          .eq('id', (existingHolder as any).id);
      } else {
        await supabase.from('launchpad_holders').insert({
          token_id: tokenId,
          wallet_address: walletAddress,
          username: username,
          balance: tokenAmount
        } as any);

        // Increment holder count
        await supabase
          .from('launchpad_tokens')
          .update({ holder_count: token.holder_count + 1 } as any)
          .eq('id', tokenId);
      }

      toast({
        title: "Purchase Successful! 🎉",
        description: `Bought ${tokenAmount.toLocaleString()} ${token.symbol} for ${solAmount} SOL`,
      });

      await loadTokens();
      return true;
    } catch (error) {
      console.error('Error buying tokens:', error);
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      if (errorMsg.includes('rejected')) {
        toast({
          title: "Transaction Cancelled",
          description: "You cancelled the transaction.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Purchase Failed",
          description: `Failed to buy tokens: ${errorMsg}`,
          variant: "destructive"
        });
      }
      return false;
    } finally {
      setTrading(false);
    }
  };

  // Sell tokens
  const sellTokens = async (tokenId: string, tokenAmount: number) => {
    if (!walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to sell tokens.",
        variant: "destructive"
      });
      return false;
    }

    const token = tokens.find(t => t.id === tokenId);
    if (!token) return false;

    setTrading(true);
    try {
      // Check holder balance
      const { data: holder } = await supabase
        .from('launchpad_holders')
        .select('*')
        .eq('token_id', tokenId)
        .eq('wallet_address', walletAddress)
        .maybeSingle();

      if (!holder || (holder as any).balance < tokenAmount) {
        toast({
          title: "Insufficient Balance",
          description: "You don't have enough tokens to sell.",
          variant: "destructive"
        });
        setTrading(false);
        return false;
      }

      const solAmount = tokenAmount * token.current_price * 0.95; // 5% fee
      const newSupply = token.current_supply + tokenAmount;
      const newPrice = calculatePrice(newSupply, token.total_supply);
      const newProgress = ((token.total_supply - newSupply) / token.total_supply) * 100;

      // Record trade
      await supabase.from('launchpad_trades').insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        username: username,
        trade_type: 'sell',
        sol_amount: solAmount,
        token_amount: tokenAmount,
        price_at_trade: token.current_price
      } as any);

      // Update token state
      await supabase
        .from('launchpad_tokens')
        .update({
          current_supply: newSupply,
          current_price: newPrice,
          bonding_curve_progress: newProgress,
          market_cap: newSupply * newPrice,
          volume_24h: token.volume_24h + solAmount
        } as any)
        .eq('id', tokenId);

      // Update holder balance
      const newBalance = (holder as any).balance - tokenAmount;
      if (newBalance <= 0) {
        await supabase
          .from('launchpad_holders')
          .delete()
          .eq('id', (holder as any).id);
        await supabase
          .from('launchpad_tokens')
          .update({ holder_count: token.holder_count - 1 } as any)
          .eq('id', tokenId);
      } else {
        await supabase
          .from('launchpad_holders')
          .update({ balance: newBalance } as any)
          .eq('id', (holder as any).id);
      }

      toast({
        title: "Sale Successful! 💰",
        description: `Sold ${tokenAmount.toLocaleString()} ${token.symbol} for ~${solAmount.toFixed(6)} SOL`,
      });

      await loadTokens();
      return true;
    } catch (error) {
      console.error('Error selling tokens:', error);
      toast({
        title: "Sale Failed",
        description: "Failed to sell tokens. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setTrading(false);
    }
  };

  // Get user's holdings for a token
  const getUserHoldings = async (tokenId: string): Promise<number> => {
    if (!walletAddress) return 0;

    const { data } = await supabase
      .from('launchpad_holders')
      .select('balance')
      .eq('token_id', tokenId)
      .eq('wallet_address', walletAddress)
      .maybeSingle();

    return data ? (data as any).balance : 0;
  };

  // Get recent trades for a token
  const getTokenTrades = async (tokenId: string): Promise<LaunchpadTrade[]> => {
    const { data } = await supabase
      .from('launchpad_trades')
      .select('*')
      .eq('token_id', tokenId)
      .order('created_at', { ascending: false })
      .limit(50);

    return (data as LaunchpadTrade[]) || [];
  };

  // Get all tokens user holds
  const getUserTokens = async (): Promise<{ tokenId: string; balance: number }[]> => {
    if (!walletAddress) return [];

    const { data } = await supabase
      .from('launchpad_holders')
      .select('token_id, balance')
      .eq('wallet_address', walletAddress)
      .gt('balance', 0);

    return (data || []).map((h: any) => ({
      tokenId: h.token_id,
      balance: h.balance
    }));
  };

  // Get tokens created by user
  const getCreatedTokens = (): LaunchpadToken[] => {
    if (!walletAddress) return [];
    return tokens.filter(t => t.creator_wallet === walletAddress);
  };

  // Get user's watchlist token IDs
  const getWatchlist = async (): Promise<string[]> => {
    if (!walletAddress) return [];

    const { data } = await supabase
      .from('token_watchlist')
      .select('token_id')
      .eq('wallet_address', walletAddress);

    return (data || []).map((w: any) => w.token_id);
  };

  // Add token to watchlist
  const addToWatchlist = async (tokenId: string): Promise<boolean> => {
    if (!walletAddress) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to add to watchlist.",
        variant: "destructive"
      });
      return false;
    }

    try {
      const { error } = await supabase
        .from('token_watchlist')
        .insert({
          wallet_address: walletAddress,
          token_id: tokenId
        } as any);

      if (error) {
        if (error.code === '23505') {
          toast({
            title: "Already in Watchlist",
            description: "This token is already in your watchlist.",
          });
          return false;
        }
        throw error;
      }

      toast({
        title: "Added to Watchlist ⭐",
        description: "Token added to your watchlist.",
      });
      return true;
    } catch (error) {
      console.error('Error adding to watchlist:', error);
      toast({
        title: "Error",
        description: "Failed to add to watchlist.",
        variant: "destructive"
      });
      return false;
    }
  };

  // Remove token from watchlist
  const removeFromWatchlist = async (tokenId: string): Promise<boolean> => {
    if (!walletAddress) return false;

    try {
      const { error } = await supabase
        .from('token_watchlist')
        .delete()
        .eq('wallet_address', walletAddress)
        .eq('token_id', tokenId);

      if (error) throw error;

      toast({
        title: "Removed from Watchlist",
        description: "Token removed from your watchlist.",
      });
      return true;
    } catch (error) {
      console.error('Error removing from watchlist:', error);
      toast({
        title: "Error",
        description: "Failed to remove from watchlist.",
        variant: "destructive"
      });
      return false;
    }
  };

  // Price alert interface
  interface PriceAlert {
    id: string;
    wallet_address: string;
    token_id: string;
    target_price: number;
    alert_type: 'above' | 'below';
    is_triggered: boolean;
    triggered_at: string | null;
    created_at: string;
  }

  // Get user's price alerts
  const getPriceAlerts = async (): Promise<PriceAlert[]> => {
    if (!walletAddress) return [];

    const { data } = await supabase
      .from('price_alerts')
      .select('*')
      .eq('wallet_address', walletAddress)
      .order('created_at', { ascending: false });

    return (data as PriceAlert[]) || [];
  };

  // Create a price alert
  const createPriceAlert = async (
    tokenId: string,
    targetPrice: number,
    alertType: 'above' | 'below'
  ): Promise<boolean> => {
    if (!walletAddress) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to create alerts.",
        variant: "destructive"
      });
      return false;
    }

    try {
      const { error } = await supabase
        .from('price_alerts')
        .insert({
          wallet_address: walletAddress,
          token_id: tokenId,
          target_price: targetPrice,
          alert_type: alertType
        } as any);

      if (error) {
        if (error.code === '23505') {
          toast({
            title: "Alert Exists",
            description: "You already have this alert set.",
          });
          return false;
        }
        throw error;
      }

      toast({
        title: "Alert Created 🔔",
        description: `You'll be notified when price goes ${alertType} ${targetPrice.toFixed(8)} SOL`,
      });
      return true;
    } catch (error) {
      console.error('Error creating price alert:', error);
      toast({
        title: "Error",
        description: "Failed to create price alert.",
        variant: "destructive"
      });
      return false;
    }
  };

  // Delete a price alert
  const deletePriceAlert = async (alertId: string): Promise<boolean> => {
    try {
      const { error } = await supabase
        .from('price_alerts')
        .delete()
        .eq('id', alertId);

      if (error) throw error;

      toast({
        title: "Alert Deleted",
        description: "Price alert has been removed.",
      });
      return true;
    } catch (error) {
      console.error('Error deleting price alert:', error);
      toast({
        title: "Error",
        description: "Failed to delete alert.",
        variant: "destructive"
      });
      return false;
    }
  };

  // Check and trigger price alerts
  const checkPriceAlerts = async (): Promise<void> => {
    if (!walletAddress) return;

    const alerts = await getPriceAlerts();
    const activeAlerts = alerts.filter(a => !a.is_triggered);

    for (const alert of activeAlerts) {
      const token = tokens.find(t => t.id === alert.token_id);
      if (!token) continue;

      const shouldTrigger = 
        (alert.alert_type === 'above' && token.current_price >= alert.target_price) ||
        (alert.alert_type === 'below' && token.current_price <= alert.target_price);

      if (shouldTrigger) {
        // Mark as triggered
        await supabase
          .from('price_alerts')
          .update({ is_triggered: true, triggered_at: new Date().toISOString() } as any)
          .eq('id', alert.id);

        // Show notification
        toast({
          title: `🔔 Price Alert: ${token.symbol}`,
          description: `${token.name} is now ${alert.alert_type === 'above' ? 'above' : 'below'} ${alert.target_price.toFixed(8)} SOL (Current: ${token.current_price.toFixed(8)} SOL)`,
        });
      }
    }
  };

  // Real-time subscription
  useEffect(() => {
    loadTokens();

    const channel = supabase
      .channel('launchpad_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'launchpad_tokens'
      }, () => {
        loadTokens();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [loadTokens]);

  // Check price alerts when tokens update
  useEffect(() => {
    if (tokens.length > 0 && walletAddress) {
      checkPriceAlerts();
    }
  }, [tokens, walletAddress]);

  // Get top traders leaderboard
  const getTopTraders = async (limit: number = 20): Promise<TraderStats[]> => {
    try {
      const { data, error } = await supabase
        .from('launchpad_trades')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      if (!data) return [];

      // Aggregate by wallet
      const traderMap = new Map<string, {
        wallet_address: string;
        username: string | null;
        buy_volume: number;
        sell_volume: number;
        total_trades: number;
        last_trade_at: string;
        buy_cost: number;
        sell_revenue: number;
      }>();

      data.forEach((trade: any) => {
        const existing = traderMap.get(trade.wallet_address) || {
          wallet_address: trade.wallet_address,
          username: trade.username,
          buy_volume: 0,
          sell_volume: 0,
          total_trades: 0,
          last_trade_at: trade.created_at,
          buy_cost: 0,
          sell_revenue: 0
        };

        existing.total_trades += 1;
        if (trade.trade_type === 'buy') {
          existing.buy_volume += trade.sol_amount;
          existing.buy_cost += trade.sol_amount;
        } else {
          existing.sell_volume += trade.sol_amount;
          existing.sell_revenue += trade.sol_amount;
        }

        if (new Date(trade.created_at) > new Date(existing.last_trade_at)) {
          existing.last_trade_at = trade.created_at;
          existing.username = trade.username || existing.username;
        }

        traderMap.set(trade.wallet_address, existing);
      });

      // Calculate stats and sort by volume
      const traders: TraderStats[] = Array.from(traderMap.values()).map(t => ({
        wallet_address: t.wallet_address,
        username: t.username,
        total_volume: t.buy_volume + t.sell_volume,
        total_trades: t.total_trades,
        buy_volume: t.buy_volume,
        sell_volume: t.sell_volume,
        estimated_profit: t.sell_revenue - t.buy_cost,
        last_trade_at: t.last_trade_at
      }));

      // Sort by total volume
      traders.sort((a, b) => b.total_volume - a.total_volume);

      return traders.slice(0, limit);
    } catch (error) {
      console.error('Error fetching top traders:', error);
      return [];
    }
  };

  return {
    tokens,
    loading,
    creating,
    trading,
    loadTokens,
    createToken,
    buyTokens,
    sellTokens,
    getUserHoldings,
    getTokenTrades,
    uploadLogo,
    getUserTokens,
    getCreatedTokens,
    getWatchlist,
    addToWatchlist,
    removeFromWatchlist,
    getPriceAlerts,
    createPriceAlert,
    deletePriceAlert,
    getTopTraders
  };
};