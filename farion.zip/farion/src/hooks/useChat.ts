import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

interface ChatRoom {
  id: string;
  name: string;
  description: string;
}

interface ChatMessage {
  id: string;
  room_id: string;
  wallet_address: string;
  username: string;
  message: string;
  created_at: string;
}

interface UserSession {
  id: string;
  wallet_address: string;
  username: string;
  is_online: boolean;
  last_seen: string;
}

export const DEV_WALLET_ADDRESS = "HuTQzoz9Zh4vM1MtcESj9PDs95hbPhoG2eJFh8fjNK96";

export const useChat = (roomId?: string) => {
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<UserSession[]>([]);
  const [offlineUsers, setOfflineUsers] = useState<UserSession[]>([]);
  const [loading, setLoading] = useState(false);
  const { walletAddress, username, connected } = useMultiWallet();
  const { toast } = useToast();

  // Load chat rooms
  const loadRooms = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('chat_rooms')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setRooms(data || []);
    } catch (error) {
      console.error('Error loading rooms:', error);
    }
  }, []);

  // Load messages for a room
  const loadMessages = useCallback(async (currentRoomId: string) => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('room_id', currentRoomId)
        .order('created_at', { ascending: true })
        .limit(50);
      
      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Load online users
  const loadOnlineUsers = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('user_sessions')
        .select('*')
        .eq('is_online', true)
        .order('username');
      
      if (error) throw error;
      setOnlineUsers(data || []);
    } catch (error) {
      console.error('Error loading online users:', error);
    }
  }, []);

  const loadOfflineUsers = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('user_sessions')
        .select('*')
        .eq('is_online', false)
        .order('last_seen', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      setOfflineUsers(data || []);
    } catch (error) {
      console.error('Error loading offline users:', error);
    }
  }, []);

  // Create or update user session
  const updateUserSession = useCallback(async () => {
    if (!walletAddress || !username) return;
    
    try {
      const { error } = await supabase
        .from('user_sessions')
        .upsert({
          wallet_address: walletAddress,
          username: username,
          is_online: true,
          last_seen: new Date().toISOString(),
        }, {
          onConflict: 'wallet_address'
        });
      
      if (error) throw error;
    } catch (error) {
      console.error('Error updating user session:', error);
    }
  }, [walletAddress, username]);

  // Send a message
  const sendMessage = useCallback(async (roomId: string, messageText: string) => {
    if (!connected || !walletAddress || !username) {
      toast({
        title: "Not connected",
        description: "Please connect your wallet to send messages",
        variant: "destructive",
      });
      return false;
    }

    if (!messageText.trim()) return false;

    try {
      // First ensure user session exists
      await updateUserSession();

      const { error } = await supabase
        .from('chat_messages')
        .insert({
          room_id: roomId,
          wallet_address: walletAddress,
          username: username,
          message: messageText.trim(),
        });

      if (error) throw error;
      
      return true;
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
      return false;
    }
  }, [connected, walletAddress, username, updateUserSession, toast]);

  // Set up real-time subscriptions
  useEffect(() => {
    if (!roomId) return;

    // Subscribe to new messages with unique channel name per room
    const messageChannel = supabase
      .channel(`room-${roomId}-messages-${Date.now()}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `room_id=eq.${roomId}`,
        },
        (payload) => {
          const newMessage = payload.new as ChatMessage;
          setMessages(prev => {
            // Check if message already exists to avoid duplicates
            const exists = prev.some(msg => msg.id === newMessage.id);
            if (exists) return prev;
            return [...prev, newMessage];
          });
        }
      )
      .subscribe((status) => {
        console.log('Chat messages subscription status:', status);
      });

    // Subscribe to user presence changes with unique channel name
    const presenceChannel = supabase
      .channel(`user-presence-${Date.now()}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_sessions',
        },
        () => {
          loadOnlineUsers();
          loadOfflineUsers();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(messageChannel);
      supabase.removeChannel(presenceChannel);
    };
  }, [roomId, loadOnlineUsers, loadOfflineUsers]);

  // Update user session when connected and set up heartbeat
  useEffect(() => {
    if (connected) {
      updateUserSession();
      loadOnlineUsers();
      loadOfflineUsers();

      // Set up heartbeat to keep session alive
      const heartbeat = setInterval(() => {
        updateUserSession();
      }, 30000); // Update every 30 seconds

      // Cleanup when user disconnects or leaves
      const handleBeforeUnload = async () => {
        if (walletAddress) {
          await supabase
            .from('user_sessions')
            .update({ is_online: false, last_seen: new Date().toISOString() })
            .eq('wallet_address', walletAddress);
        }
      };

      window.addEventListener('beforeunload', handleBeforeUnload);

      return () => {
        clearInterval(heartbeat);
        window.removeEventListener('beforeunload', handleBeforeUnload);
        // Set user offline when component unmounts
        if (walletAddress) {
          supabase
            .from('user_sessions')
            .update({ is_online: false, last_seen: new Date().toISOString() })
            .eq('wallet_address', walletAddress);
        }
      };
    }
  }, [connected, updateUserSession, loadOnlineUsers, loadOfflineUsers, walletAddress]);

  // Load initial data
  useEffect(() => {
    loadRooms();
  }, [loadRooms]);

  // Load messages when room changes
  useEffect(() => {
    if (roomId) {
      loadMessages(roomId);
    }
  }, [roomId, loadMessages]);

  return {
    rooms,
    messages,
    onlineUsers,
    offlineUsers,
    loading,
    sendMessage,
    loadMessages,
    updateUserSession,
  };
};