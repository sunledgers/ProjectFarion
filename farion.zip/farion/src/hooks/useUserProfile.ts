import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface UserProfile {
  wallet_address: string;
  username: string;
  custom_username?: string;
  username_set_at?: string;
}

export const useUserProfile = (walletAddress: string | null) => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = async () => {
    if (!walletAddress) {
      setProfile(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('wallet_address', walletAddress)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        throw fetchError;
      }

      setProfile(data);
    } catch (err) {
      console.error('Error fetching user profile:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch profile');
    } finally {
      setLoading(false);
    }
  };

  const checkUsernameAvailability = async (username: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.rpc('check_username_availability', {
        desired_username: username
      });

      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Error checking username availability:', err);
      return false;
    }
  };

  const setCustomUsername = async (username: string): Promise<{ success: boolean; error?: string }> => {
    if (!walletAddress) {
      return { success: false, error: 'No wallet connected' };
    }

    try {
      const { data, error } = await supabase.rpc('set_custom_username', {
        wallet_addr: walletAddress,
        desired_username: username
      });

      if (error) throw error;

      // Type guard for the response data
      const result = data as { success: boolean; error?: string; username?: string };

      if (result.success) {
        await fetchProfile(); // Refresh profile data
      }

      return result;
    } catch (err) {
      console.error('Error setting username:', err);
      return { success: false, error: err instanceof Error ? err.message : 'Failed to set username' };
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [walletAddress]);

  return {
    profile,
    loading,
    error,
    checkUsernameAvailability,
    setCustomUsername,
    refreshProfile: fetchProfile
  };
};