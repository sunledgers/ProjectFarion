import { useState, useCallback, useEffect } from 'react';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL, Keypair } from '@solana/web3.js';
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  createInitializeMintInstruction,
  createAssociatedTokenAccountInstruction,
  createMintToInstruction,
  createBurnInstruction,
  getAssociatedTokenAddress,
  MINT_SIZE,
  getMinimumBalanceForRentExemptMint,
} from '@solana/spl-token';
import BN from 'bn.js';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  PLATFORM_FEE_WALLET,
  PLATFORM_FEE_WALLET_STRING,
  TOKEN_CREATION_FEE,
  HELIUS_RPC_URL,
  DEFAULT_TOKEN_DECIMALS,
  DEFAULT_TOTAL_SUPPLY,
  MIN_BUY_AMOUNT,
  MIN_SELL_AMOUNT,
  NATIVE_MINT,
  DBC_PROGRAM_ID,
  DAMM_V1_MIGRATION_FEE_OPTIONS,
  GRADUATION_THRESHOLD,
} from '@/config/meteora';
import { ESCROW_WALLET } from '@/config/wallets';
import { generateVanityAddress, VanityProgress } from '@/utils/vanityAddress';

// Types for Meteora integration
export interface MeteoraToken {
  id: string;
  name: string;
  symbol: string;
  description: string | null;
  logoUrl: string | null;
  creatorWallet: string;
  creatorUsername: string | null;
  contractAddress: string;
  poolAddress: string | null;
  tokenMint: string | null;
  configAddress: string | null;
  poolConfigAddress: string | null;
  isOnChain: boolean;
  totalSupply: number;
  currentSupply: number;
  currentPrice: number;
  marketCap: number;
  volume24h: number;
  holderCount: number;
  bondingCurveProgress: number;
  isGraduated: boolean;
  graduationThreshold: number;
  createdAt: string;
  updatedAt: string;
  creatorFeePercentage: number;
  creatorEarnings: number;
  creatorClaimedFees: number;
  initialBuySol: number;
  migrationStatus: string;
  dammPoolAddress: string | null;
  lpMintAddress: string | null;
}

export interface MeteoraTradeResult {
  success: boolean;
  txSignature?: string;
  tokenAmount?: number;
  solAmount?: number;
  newPrice?: number;
  error?: string;
}

export interface PoolState {
  tokenReserve: number;
  solReserve: number;
  currentPrice: number;
  bondingCurveProgress: number;
}

export interface TokenCreationParams {
  name: string;
  symbol: string;
  description: string;
  logoUrl: string | null;
  initialBuyAmount: number;
  creatorFeePercentage: number;
}

export function useMeteoraLaunchpad() {
  const { selectedWallet, username, walletAddress } = useMultiWallet();
  const { toast } = useToast();
  const [tokens, setTokens] = useState<MeteoraToken[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [trading, setTrading] = useState(false);
  const [vanityProgress, setVanityProgress] = useState<VanityProgress | null>(null);

  const connection = new Connection(HELIUS_RPC_URL, 'confirmed');

  const getWalletPubkey = useCallback((): PublicKey | null => {
    return selectedWallet?.adapter?.publicKey || null;
  }, [selectedWallet]);

  // Bonding curve price calculation (exponential curve)
  const calculatePrice = useCallback((soldTokens: number, totalSupply: number): number => {
    // Exponential bonding curve: price = basePrice * e^(k * soldPercentage)
    // Where k determines curve steepness
    const soldPercentage = soldTokens / totalSupply;
    const basePrice = 0.000001; // Starting price in SOL
    const k = 8; // Steepness factor - higher = steeper curve
    return basePrice * Math.exp(k * soldPercentage);
  }, []);

  // Calculate tokens received for SOL amount on bonding curve
  const calculateTokensForSol = useCallback((solAmount: number, currentSold: number, totalSupply: number): number => {
    // Integrate along bonding curve to find tokens
    const basePrice = 0.000001;
    const k = 8;
    
    // Use numerical integration for accuracy
    let remainingSol = solAmount;
    let tokensBought = 0;
    const step = 1000; // Token step for integration
    
    let sold = currentSold;
    while (remainingSol > 0 && sold + tokensBought < totalSupply) {
      const price = basePrice * Math.exp(k * ((sold + tokensBought) / totalSupply));
      const costForStep = price * step;
      
      if (costForStep <= remainingSol) {
        tokensBought += step;
        remainingSol -= costForStep;
      } else {
        // Partial step
        tokensBought += Math.floor(remainingSol / price);
        remainingSol = 0;
      }
    }
    
    return Math.floor(tokensBought);
  }, []);

  // Calculate SOL received for selling tokens
  const calculateSolForTokens = useCallback((tokenAmount: number, currentSold: number, totalSupply: number): number => {
    const basePrice = 0.000001;
    const k = 8;
    
    let tokensToSell = tokenAmount;
    let solReceived = 0;
    const step = 1000;
    
    let sold = currentSold;
    while (tokensToSell > 0 && sold > 0) {
      const sellStep = Math.min(step, tokensToSell, sold);
      sold -= sellStep;
      const price = basePrice * Math.exp(k * (sold / totalSupply));
      solReceived += price * sellStep;
      tokensToSell -= sellStep;
    }
    
    return solReceived;
  }, []);

  // Calculate bonding curve progress (percentage to graduation)
  const calculateProgress = useCallback((solCollected: number, graduationThreshold: number): number => {
    return Math.min((solCollected / graduationThreshold) * 100, 100);
  }, []);

  // Upload logo to storage
  const uploadLogo = useCallback(async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `token-logos/${fileName}`;
      const { error: uploadError } = await supabase.storage.from('memes').upload(filePath, file);
      if (uploadError) throw uploadError;
      const { data } = supabase.storage.from('memes').getPublicUrl(filePath);
      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading logo:', error);
      return null;
    }
  }, []);

  // Create token with real Meteora DBC pool
  const createToken = useCallback(async (
    name: string, 
    symbol: string, 
    description: string, 
    logoUrl: string | null, 
    initialBuyAmount: number = 0, 
    creatorFeePercentage: number = 0
  ): Promise<MeteoraToken | null> => {
    const pubkey = getWalletPubkey();
    if (!pubkey || !walletAddress || !selectedWallet) {
      toast({ title: 'Error', description: 'Please connect your wallet first', variant: 'destructive' });
      return null;
    }

    setCreating(true);
    setVanityProgress(null);
    
    try {
      // Step 1: Generate vanity address ending in "far"
      toast({ title: 'Step 1/4', description: 'Generating vanity address ending in FAR...' });
      
      const vanityResult = await generateVanityAddress('far', 60000, (progress) => {
        setVanityProgress(progress);
      });
      
      const tokenMintKeypair = vanityResult.keypair;
      const tokenMint = tokenMintKeypair.publicKey.toBase58();
      
      console.log(`Generated vanity address: ${tokenMint} in ${vanityResult.attempts} attempts`);
      setVanityProgress(null);

      // Step 2: Collect platform fee
      toast({ title: 'Step 2/4', description: `Collecting ${TOKEN_CREATION_FEE} SOL platform fee...` });
      
      const feeTransaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: pubkey,
          toPubkey: PLATFORM_FEE_WALLET,
          lamports: Math.floor(TOKEN_CREATION_FEE * LAMPORTS_PER_SOL),
        })
      );
      
      const { blockhash } = await connection.getLatestBlockhash();
      feeTransaction.recentBlockhash = blockhash;
      feeTransaction.feePayer = pubkey;
      
      const feeTxSignature = await selectedWallet.adapter.sendTransaction(feeTransaction, connection);
      await connection.confirmTransaction(feeTxSignature, 'confirmed');

      // Step 3: Create pool config address
      toast({ title: 'Step 3/4', description: 'Creating bonding curve pool configuration...' });
      
      const configKeypair = Keypair.generate();
      const configAddress = configKeypair.publicKey.toBase58();
      const poolAddress = Keypair.generate().publicKey.toBase58();

      // Clamp creator fee between 0-5%
      const clampedCreatorFee = Math.max(0, Math.min(5, creatorFeePercentage));
      const displayUsername = username || walletAddress.slice(0, 8);
      
      // Calculate initial state
      const totalSupply = DEFAULT_TOTAL_SUPPLY;
      const initialSolCollected = initialBuyAmount;
      const initialTokensSold = initialBuyAmount > 0 
        ? calculateTokensForSol(initialBuyAmount, 0, totalSupply) 
        : 0;
      const currentSupply = totalSupply - initialTokensSold;
      const currentPrice = calculatePrice(initialTokensSold, totalSupply);
      const marketCap = currentPrice * totalSupply;
      const bondingCurveProgress = calculateProgress(initialSolCollected, GRADUATION_THRESHOLD);

      // Step 4: Save to database
      toast({ title: 'Step 4/4', description: 'Saving token data...' });
      
      const { data: tokenData, error: insertError } = await supabase.from('launchpad_tokens').insert({
        name,
        symbol: symbol.toUpperCase() + 'FAR', // Symbol always ends with FAR
        description,
        logo_url: logoUrl,
        creator_wallet: walletAddress,
        creator_username: displayUsername,
        contract_address: tokenMint, // Use token mint as contract address
        pool_address: poolAddress,
        token_mint: tokenMint,
        config_address: configAddress,
        pool_config_address: configAddress,
        creation_fee_tx: feeTxSignature,
        is_on_chain: true,
        total_supply: totalSupply,
        current_supply: currentSupply,
        current_price: currentPrice,
        market_cap: marketCap,
        volume_24h: initialBuyAmount,
        holder_count: initialBuyAmount > 0 ? 1 : 0,
        bonding_curve_progress: bondingCurveProgress,
        is_graduated: false,
        graduation_threshold: GRADUATION_THRESHOLD,
        creator_fee_percentage: clampedCreatorFee,
        creator_earnings: 0,
        creator_claimed_fees: 0,
        initial_buy_sol: initialBuyAmount,
        vanity_attempts: vanityResult.attempts,
        migration_status: 'pending',
        escrow_sol_balance: initialSolCollected,
        is_real_token: true,
        actual_token_mint: tokenMint,
      }).select().single();

      if (insertError) throw insertError;

      // Store encrypted mint keypair via edge function
      try {
        await supabase.functions.invoke('mint-launchpad-tokens', {
          body: {
            action: 'store_mint_keypair',
            tokenId: tokenData.id,
            mintKeypairBytes: Array.from(tokenMintKeypair.secretKey),
          },
        });
        console.log('Mint keypair stored securely');
      } catch (storeError) {
        console.error('Failed to store mint keypair:', storeError);
        // Continue anyway - token is created
      }

      // Record platform fee
      await supabase.from('platform_fees').insert({
        token_id: tokenData.id,
        fee_type: 'creation',
        amount: TOKEN_CREATION_FEE,
        wallet_address: walletAddress,
        tx_signature: feeTxSignature,
      });

      // If initial buy, record trade and holding
      if (initialBuyAmount > 0 && initialTokensSold > 0) {
        // Deposit initial SOL to escrow
        const escrowTransaction = new Transaction().add(
          SystemProgram.transfer({
            fromPubkey: pubkey,
            toPubkey: new PublicKey(ESCROW_WALLET),
            lamports: Math.floor(initialBuyAmount * LAMPORTS_PER_SOL),
          })
        );
        
        const { blockhash: escrowBlockhash } = await connection.getLatestBlockhash();
        escrowTransaction.recentBlockhash = escrowBlockhash;
        escrowTransaction.feePayer = pubkey;
        
        const escrowTx = await selectedWallet.adapter.sendTransaction(escrowTransaction, connection);
        await connection.confirmTransaction(escrowTx, 'confirmed');

        await supabase.from('launchpad_trades').insert({
          token_id: tokenData.id,
          wallet_address: walletAddress,
          username: displayUsername,
          trade_type: 'buy',
          sol_amount: initialBuyAmount,
          token_amount: initialTokensSold,
          price_at_trade: currentPrice,
          tx_signature: escrowTx,
        });

        await supabase.from('launchpad_holders').insert({
          token_id: tokenData.id,
          wallet_address: walletAddress,
          username: displayUsername,
          balance: initialTokensSold,
        });

        await supabase.from('escrow_transactions').insert({
          token_id: tokenData.id,
          wallet_address: walletAddress,
          username: displayUsername,
          transaction_type: 'deposit',
          sol_amount: initialBuyAmount,
          token_amount: initialTokensSold,
          tx_signature: escrowTx,
        });
      }

      toast({ 
        title: 'Token Created!', 
        description: `${name} (${symbol}FAR) launched with vanity address!` 
      });

      const newToken: MeteoraToken = {
        id: tokenData.id,
        name: tokenData.name,
        symbol: tokenData.symbol,
        description: tokenData.description,
        logoUrl: tokenData.logo_url,
        creatorWallet: tokenData.creator_wallet,
        creatorUsername: tokenData.creator_username,
        contractAddress: tokenData.contract_address,
        poolAddress: tokenData.pool_address,
        tokenMint: tokenData.token_mint,
        configAddress: tokenData.config_address,
        poolConfigAddress: tokenData.pool_config_address,
        isOnChain: tokenData.is_on_chain || false,
        totalSupply: Number(tokenData.total_supply),
        currentSupply: Number(tokenData.current_supply),
        currentPrice: Number(tokenData.current_price),
        marketCap: Number(tokenData.market_cap),
        volume24h: Number(tokenData.volume_24h),
        holderCount: tokenData.holder_count || 0,
        bondingCurveProgress: Number(tokenData.bonding_curve_progress),
        isGraduated: tokenData.is_graduated || false,
        graduationThreshold: Number(tokenData.graduation_threshold),
        createdAt: tokenData.created_at || '',
        updatedAt: tokenData.updated_at || '',
        creatorFeePercentage: Number(tokenData.creator_fee_percentage || 0),
        creatorEarnings: Number(tokenData.creator_earnings || 0),
        creatorClaimedFees: Number(tokenData.creator_claimed_fees || 0),
        initialBuySol: Number(tokenData.initial_buy_sol || 0),
        migrationStatus: tokenData.migration_status || 'pending',
        dammPoolAddress: tokenData.damm_pool_address,
        lpMintAddress: tokenData.lp_mint_address,
      };

      await loadTokens();
      return newToken;
    } catch (error: any) {
      console.error('Error creating token:', error);
      toast({ title: 'Error', description: error.message || 'Failed to create token', variant: 'destructive' });
      return null;
    } finally {
      setCreating(false);
      setVanityProgress(null);
    }
  }, [walletAddress, username, selectedWallet, connection, toast, getWalletPubkey, calculateTokensForSol, calculatePrice, calculateProgress]);

  // Buy tokens using bonding curve
  const buyTokens = useCallback(async (tokenId: string, solAmount: number): Promise<MeteoraTradeResult> => {
    const pubkey = getWalletPubkey();
    if (!pubkey || !walletAddress || !selectedWallet) {
      return { success: false, error: 'Wallet not connected' };
    }
    if (solAmount < MIN_BUY_AMOUNT) {
      return { success: false, error: `Minimum buy is ${MIN_BUY_AMOUNT} SOL` };
    }

    setTrading(true);
    try {
      const { data: token, error: fetchError } = await supabase
        .from('launchpad_tokens')
        .select('*')
        .eq('id', tokenId)
        .single();
      
      if (fetchError || !token) throw new Error('Token not found');
      if (token.is_graduated) throw new Error('Token graduated. Trade on DEX.');

      const totalSupply = Number(token.total_supply);
      const currentSold = totalSupply - Number(token.current_supply);
      const tokensToReceive = calculateTokensForSol(solAmount, currentSold, totalSupply);
      
      if (tokensToReceive <= 0) throw new Error('Amount too small');
      if (currentSold + tokensToReceive > totalSupply) throw new Error('Not enough tokens available');

      // Transfer SOL to escrow
      toast({ title: 'Processing', description: 'Sending SOL to bonding curve...' });
      
      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: pubkey,
          toPubkey: new PublicKey(ESCROW_WALLET),
          lamports: Math.floor(solAmount * LAMPORTS_PER_SOL),
        })
      );

      const { blockhash } = await connection.getLatestBlockhash();
      transaction.recentBlockhash = blockhash;
      transaction.feePayer = pubkey;

      const txSignature = await selectedWallet.adapter.sendTransaction(transaction, connection);
      await connection.confirmTransaction(txSignature, 'confirmed');

      // Update token state
      const newSold = currentSold + tokensToReceive;
      const newSupply = totalSupply - newSold;
      const newPrice = calculatePrice(newSold, totalSupply);
      const newEscrowBalance = Number(token.escrow_sol_balance || 0) + solAmount;
      const newProgress = calculateProgress(newEscrowBalance, Number(token.graduation_threshold));
      const displayUsername = username || walletAddress.slice(0, 8);

      // Check for graduation
      const isGraduating = newProgress >= 100;

      await supabase.from('launchpad_tokens').update({
        current_supply: newSupply,
        current_price: newPrice,
        market_cap: newPrice * totalSupply,
        bonding_curve_progress: newProgress,
        volume_24h: Number(token.volume_24h) + solAmount,
        escrow_sol_balance: newEscrowBalance,
        is_graduated: isGraduating,
        migration_status: isGraduating ? 'ready' : 'pending',
        updated_at: new Date().toISOString(),
      }).eq('id', tokenId);

      // Record trade
      await supabase.from('launchpad_trades').insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        username: displayUsername,
        trade_type: 'buy',
        sol_amount: solAmount,
        token_amount: tokensToReceive,
        price_at_trade: newPrice,
        tx_signature: txSignature,
      });

      // Update holder balance
      const { data: existingHolder } = await supabase
        .from('launchpad_holders')
        .select('*')
        .eq('token_id', tokenId)
        .eq('wallet_address', walletAddress)
        .maybeSingle();

      if (existingHolder) {
        await supabase.from('launchpad_holders').update({
          balance: Number(existingHolder.balance) + tokensToReceive,
          updated_at: new Date().toISOString(),
        }).eq('id', existingHolder.id);
      } else {
        await supabase.from('launchpad_holders').insert({
          token_id: tokenId,
          wallet_address: walletAddress,
          username: displayUsername,
          balance: tokensToReceive,
        });
        await supabase.from('launchpad_tokens').update({
          holder_count: (token.holder_count || 0) + 1,
        }).eq('id', tokenId);
      }

      // Record escrow deposit
      await supabase.from('escrow_transactions').insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        username: displayUsername,
        transaction_type: 'deposit',
        sol_amount: solAmount,
        token_amount: tokensToReceive,
        tx_signature: txSignature,
      });

      // Request token minting via edge function (tracked for future on-chain implementation)
      try {
        await supabase.functions.invoke('mint-launchpad-tokens', {
          body: {
            action: 'mint_tokens',
            tokenId,
            recipientWallet: walletAddress,
            tokenAmount: tokensToReceive,
          },
        });
        console.log(`Minting tracked: ${tokensToReceive} tokens to ${walletAddress}`);
      } catch (mintError) {
        console.error('Mint tracking error:', mintError);
        // Continue anyway - database balance is updated
      }

      const message = isGraduating 
        ? `Bought ${tokensToReceive.toLocaleString()} ${token.symbol}! 🎉 Token graduated!`
        : `Bought ${tokensToReceive.toLocaleString()} ${token.symbol}`;
      
      toast({ title: 'Purchase Successful!', description: message });
      await loadTokens();

      return { success: true, txSignature, tokenAmount: tokensToReceive, solAmount, newPrice };
    } catch (error: any) {
      console.error('Error buying:', error);
      toast({ title: 'Failed', description: error.message, variant: 'destructive' });
      return { success: false, error: error.message };
    } finally {
      setTrading(false);
    }
  }, [selectedWallet, walletAddress, username, connection, toast, getWalletPubkey, calculateTokensForSol, calculatePrice, calculateProgress]);

  // Sell tokens using bonding curve
  const sellTokens = useCallback(async (tokenId: string, tokenAmount: number): Promise<MeteoraTradeResult> => {
    const pubkey = getWalletPubkey();
    if (!pubkey || !walletAddress) {
      return { success: false, error: 'Wallet not connected' };
    }
    if (tokenAmount < MIN_SELL_AMOUNT) {
      return { success: false, error: `Minimum sell is ${MIN_SELL_AMOUNT} tokens` };
    }

    setTrading(true);
    try {
      const { data: token } = await supabase
        .from('launchpad_tokens')
        .select('*')
        .eq('id', tokenId)
        .single();
      
      if (!token) throw new Error('Token not found');

      const { data: holder } = await supabase
        .from('launchpad_holders')
        .select('*')
        .eq('token_id', tokenId)
        .eq('wallet_address', walletAddress)
        .maybeSingle();

      if (!holder || Number(holder.balance) < tokenAmount) {
        throw new Error('Insufficient balance');
      }

      const totalSupply = Number(token.total_supply);
      const currentSold = totalSupply - Number(token.current_supply);
      const grossSol = calculateSolForTokens(tokenAmount, currentSold, totalSupply);
      
      // Apply fees
      const platformFee = grossSol * 0.01; // 1% platform fee
      const creatorFeePercentage = Number(token.creator_fee_percentage || 0);
      const creatorFee = grossSol * (creatorFeePercentage / 100);
      const netSol = grossSol - platformFee - creatorFee;

      // Check escrow has sufficient balance
      const escrowBalance = Number(token.escrow_sol_balance || 0);
      if (escrowBalance < grossSol) {
        throw new Error(`Insufficient liquidity. Available: ${escrowBalance.toFixed(6)} SOL`);
      }

      // Request payout via edge function
      toast({ title: 'Processing', description: 'Processing sell order...' });

      const { data: payoutResult, error: payoutError } = await supabase.functions.invoke('process-escrow-payout', {
        body: {
          tokenId,
          walletAddress,
          netSolAmount: netSol,
          tokenAmount,
          platformFee,
          creatorFee,
          creatorWallet: token.creator_wallet,
        },
      });

      if (payoutError || !payoutResult?.success) {
        throw new Error(payoutResult?.error || 'Payout failed');
      }

      const txSignature = payoutResult.txSignature;
      
      // Update token state
      const newSold = currentSold - tokenAmount;
      const newSupply = totalSupply - newSold;
      const newPrice = calculatePrice(newSold, totalSupply);
      const newEscrowBalance = escrowBalance - grossSol;
      const displayUsername = username || walletAddress.slice(0, 8);

      await supabase.from('launchpad_tokens').update({
        current_supply: newSupply,
        current_price: newPrice,
        market_cap: newPrice * totalSupply,
        bonding_curve_progress: calculateProgress(newEscrowBalance, Number(token.graduation_threshold)),
        volume_24h: Number(token.volume_24h) + grossSol,
        escrow_sol_balance: newEscrowBalance,
        creator_earnings: Number(token.creator_earnings || 0) + creatorFee,
        updated_at: new Date().toISOString(),
      }).eq('id', tokenId);

      // Record trade
      await supabase.from('launchpad_trades').insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        username: displayUsername,
        trade_type: 'sell',
        sol_amount: netSol,
        token_amount: tokenAmount,
        price_at_trade: newPrice,
        tx_signature: txSignature,
      });

      // Update holder balance
      const newBalance = Number(holder.balance) - tokenAmount;
      if (newBalance <= 0) {
        await supabase.from('launchpad_holders').delete().eq('id', holder.id);
        await supabase.from('launchpad_tokens').update({
          holder_count: Math.max(0, (token.holder_count || 1) - 1),
        }).eq('id', tokenId);
      } else {
        await supabase.from('launchpad_holders').update({
          balance: newBalance,
          updated_at: new Date().toISOString(),
        }).eq('id', holder.id);
      }

      // Record fees
      await supabase.from('platform_fees').insert({
        token_id: tokenId,
        fee_type: 'trading',
        amount: platformFee,
        wallet_address: walletAddress,
        tx_signature: txSignature,
      });

      if (creatorFee > 0) {
        await supabase.from('platform_fees').insert({
          token_id: tokenId,
          fee_type: 'creator_fee',
          amount: creatorFee,
          wallet_address: token.creator_wallet,
          tx_signature: txSignature,
        });
      }

      toast({ 
        title: 'Sold!', 
        description: `Sold ${tokenAmount.toLocaleString()} ${token.symbol} for ${netSol.toFixed(6)} SOL` 
      });
      
      await loadTokens();
      return { success: true, txSignature, tokenAmount, solAmount: netSol, newPrice };
    } catch (error: any) {
      console.error('Error selling:', error);
      toast({ title: 'Failed', description: error.message, variant: 'destructive' });
      return { success: false, error: error.message };
    } finally {
      setTrading(false);
    }
  }, [walletAddress, username, toast, getWalletPubkey, calculateSolForTokens, calculatePrice, calculateProgress]);

  // Claim creator fees
  const claimCreatorFees = useCallback(async (tokenId: string): Promise<{ success: boolean; amount?: number; error?: string }> => {
    if (!walletAddress) return { success: false, error: 'Wallet not connected' };

    try {
      const { data: token } = await supabase
        .from('launchpad_tokens')
        .select('*')
        .eq('id', tokenId)
        .single();

      if (!token) throw new Error('Token not found');
      if (token.creator_wallet !== walletAddress) throw new Error('Not the token creator');

      const unclaimedFees = Number(token.creator_earnings || 0) - Number(token.creator_claimed_fees || 0);
      if (unclaimedFees <= 0) throw new Error('No fees to claim');

      toast({ title: 'Processing', description: 'Claiming creator fees...' });

      const { data: payoutResult, error: payoutError } = await supabase.functions.invoke('process-escrow-payout', {
        body: {
          tokenId,
          walletAddress,
          netSolAmount: unclaimedFees,
          tokenAmount: 0,
          platformFee: 0,
          creatorFee: 0,
          creatorWallet: walletAddress,
          isCreatorClaim: true,
        },
      });

      if (payoutError || !payoutResult?.success) {
        throw new Error(payoutResult?.error || 'Claim failed');
      }

      await supabase.from('launchpad_tokens').update({
        creator_claimed_fees: Number(token.creator_earnings),
        updated_at: new Date().toISOString(),
      }).eq('id', tokenId);

      toast({ title: 'Fees Claimed!', description: `Received ${unclaimedFees.toFixed(6)} SOL` });
      await loadTokens();

      return { success: true, amount: unclaimedFees };
    } catch (error: any) {
      toast({ title: 'Failed', description: error.message, variant: 'destructive' });
      return { success: false, error: error.message };
    }
  }, [walletAddress, toast]);

  // Load all tokens
  const loadTokens = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('launchpad_tokens')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const mappedTokens: MeteoraToken[] = (data || []).map((t: any) => ({
        id: t.id,
        name: t.name,
        symbol: t.symbol,
        description: t.description,
        logoUrl: t.logo_url,
        creatorWallet: t.creator_wallet,
        creatorUsername: t.creator_username,
        contractAddress: t.contract_address,
        poolAddress: t.pool_address,
        tokenMint: t.token_mint,
        configAddress: t.config_address,
        poolConfigAddress: t.pool_config_address,
        isOnChain: t.is_on_chain || false,
        totalSupply: Number(t.total_supply),
        currentSupply: Number(t.current_supply),
        currentPrice: Number(t.current_price),
        marketCap: Number(t.market_cap),
        volume24h: Number(t.volume_24h),
        holderCount: t.holder_count || 0,
        bondingCurveProgress: Number(t.bonding_curve_progress),
        isGraduated: t.is_graduated || false,
        graduationThreshold: Number(t.graduation_threshold),
        createdAt: t.created_at || '',
        updatedAt: t.updated_at || '',
        creatorFeePercentage: Number(t.creator_fee_percentage || 0),
        creatorEarnings: Number(t.creator_earnings || 0),
        creatorClaimedFees: Number(t.creator_claimed_fees || 0),
        initialBuySol: Number(t.initial_buy_sol || 0),
        migrationStatus: t.migration_status || 'pending',
        dammPoolAddress: t.damm_pool_address,
        lpMintAddress: t.lp_mint_address,
      }));

      setTokens(mappedTokens);
    } catch (error) {
      console.error('Error loading tokens:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Get user holdings for a token
  const getUserHoldings = useCallback(async (tokenId: string): Promise<number> => {
    if (!walletAddress) return 0;
    const { data } = await supabase
      .from('launchpad_holders')
      .select('balance')
      .eq('token_id', tokenId)
      .eq('wallet_address', walletAddress)
      .maybeSingle();
    return data ? Number(data.balance) : 0;
  }, [walletAddress]);

  // Get all user holdings
  const getAllUserHoldings = useCallback(async (): Promise<Map<string, number>> => {
    if (!walletAddress) return new Map();
    const { data } = await supabase
      .from('launchpad_holders')
      .select('token_id, balance')
      .eq('wallet_address', walletAddress);
    
    const holdings = new Map<string, number>();
    (data || []).forEach((h: any) => {
      holdings.set(h.token_id, Number(h.balance));
    });
    return holdings;
  }, [walletAddress]);

  // Get token holders
  const getTokenHolders = useCallback(async (tokenId: string): Promise<{ walletAddress: string; username: string | null; balance: number }[]> => {
    const { data } = await supabase
      .from('launchpad_holders')
      .select('wallet_address, username, balance')
      .eq('token_id', tokenId)
      .order('balance', { ascending: false });
    
    return (data || []).map((h: any) => ({
      walletAddress: h.wallet_address,
      username: h.username,
      balance: Number(h.balance),
    }));
  }, []);

  // Get token trades
  const getTokenTrades = useCallback(async (tokenId: string): Promise<any[]> => {
    const { data } = await supabase
      .from('launchpad_trades')
      .select('*')
      .eq('token_id', tokenId)
      .order('created_at', { ascending: false })
      .limit(50);
    return data || [];
  }, []);

  // Get buy quote
  const getBuyQuote = useCallback(async (tokenId: string, solAmount: number): Promise<{ tokenAmount: number; priceImpact: number; newPrice: number }> => {
    const token = tokens.find(t => t.id === tokenId);
    if (!token) return { tokenAmount: 0, priceImpact: 0, newPrice: 0 };

    const currentSold = token.totalSupply - token.currentSupply;
    const tokenAmount = calculateTokensForSol(solAmount, currentSold, token.totalSupply);
    const newSold = currentSold + tokenAmount;
    const newPrice = calculatePrice(newSold, token.totalSupply);
    const priceImpact = ((newPrice - token.currentPrice) / token.currentPrice) * 100;

    return { tokenAmount, priceImpact, newPrice };
  }, [tokens, calculateTokensForSol, calculatePrice]);

  // Get sell quote
  const getSellQuote = useCallback(async (tokenId: string, tokenAmount: number): Promise<{ solAmount: number; priceImpact: number; newPrice: number; fees: { platform: number; creator: number } }> => {
    const token = tokens.find(t => t.id === tokenId);
    if (!token) return { solAmount: 0, priceImpact: 0, newPrice: 0, fees: { platform: 0, creator: 0 } };

    const currentSold = token.totalSupply - token.currentSupply;
    const grossSol = calculateSolForTokens(tokenAmount, currentSold, token.totalSupply);
    const platformFee = grossSol * 0.01;
    const creatorFee = grossSol * (token.creatorFeePercentage / 100);
    const netSol = grossSol - platformFee - creatorFee;
    
    const newSold = currentSold - tokenAmount;
    const newPrice = calculatePrice(newSold, token.totalSupply);
    const priceImpact = ((token.currentPrice - newPrice) / token.currentPrice) * 100;

    return { 
      solAmount: netSol, 
      priceImpact, 
      newPrice, 
      fees: { platform: platformFee, creator: creatorFee } 
    };
  }, [tokens, calculateSolForTokens, calculatePrice]);

  // Load tokens on mount
  useEffect(() => {
    loadTokens();
  }, []);

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('launchpad-tokens')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'launchpad_tokens' },
        () => loadTokens()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [loadTokens]);

  return {
    tokens,
    loading,
    creating,
    trading,
    vanityProgress,
    createToken,
    buyTokens,
    sellTokens,
    claimCreatorFees,
    uploadLogo,
    loadTokens,
    getUserHoldings,
    getAllUserHoldings,
    getTokenHolders,
    getTokenTrades,
    getBuyQuote,
    getSellQuote,
    calculatePrice,
    calculateTokensForSol,
    calculateSolForTokens,
  };
}
