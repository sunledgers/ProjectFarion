// Contract configuration for FARION token
export const FARION_CONTRACT_ADDRESS = 'CMXuYtw7JUyoJdGVMvYfjp89GX5eA4o83477HJZypump';

// Solana network configuration
export const SOLANA_NETWORK = 'mainnet-beta';
export const SOLANA_RPC_URL = 'https://api.mainnet-beta.solana.com';

// Token balance refresh intervals (in milliseconds)
export const BALANCE_REFRESH_INTERVAL = 30000; // 30 seconds
export const BALANCE_CACHE_DURATION = 10000; // 10 seconds
