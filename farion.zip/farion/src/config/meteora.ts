import { PublicKey } from '@solana/web3.js';
import BN from 'bn.js';

// Platform configuration for Meteora DBC integration
export const PLATFORM_FEE_WALLET = new PublicKey('2atsUPU5RVmMk7v8fuBxjuTNw5LwNE1ohz5QTAd7mt7P');
export const PLATFORM_FEE_WALLET_STRING = '2atsUPU5RVmMk7v8fuBxjuTNw5LwNE1ohz5QTAd7mt7P';

// Token creation fee in SOL
export const TOKEN_CREATION_FEE = 0.01;

// Graduation threshold - when bonding curve is X% filled, migrate to DAMM
export const GRADUATION_THRESHOLD = 85;

// Default token settings
export const DEFAULT_TOKEN_DECIMALS = 6; // Meteora uses 6 decimals by default
export const DEFAULT_TOTAL_SUPPLY = 1_000_000_000; // 1 billion tokens

// Helius RPC endpoint
export const HELIUS_RPC_URL = 'https://mainnet.helius-rpc.com/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186';

// Minimum SOL amounts
export const MIN_BUY_AMOUNT = 0.001; // Minimum 0.001 SOL to buy
export const MIN_SELL_AMOUNT = 1; // Minimum 1 token to sell

// Meteora DBC Program ID (mainnet and devnet)
export const DBC_PROGRAM_ID = new PublicKey('dbcij3LWUppWqq96dh6gJWwBifmcGfLSB5D4DuSMaqN');

// Native SOL mint for quote token
export const NATIVE_MINT = new PublicKey('So11111111111111111111111111111111111111112');

// Migration fee options - graduated pool config keys
export const DAMM_V1_MIGRATION_FEE_OPTIONS = {
  FixedBps25: new PublicKey('8f848CEy8eY6PhJ3VcemtBDzPPSD4Vq7aJczLZ3o8MmX'),
  FixedBps30: new PublicKey('HBxB8Lf14Yj8pqeJ8C4qDb5ryHL7xwpuykz31BLNYr7S'),
  FixedBps100: new PublicKey('7v5vBdUQHTNeqk1HnduiXcgbvCyVEZ612HLmYkQoAkik'),
  FixedBps200: new PublicKey('EkvP7d5yKxovj884d2DwmBQbrHUWRLGK6bympzrkXGja'),
  FixedBps400: new PublicKey('9EZYAJrcqNWNQzP2trzZesP7XKMHA1jEomHzbRsdX8R2'),
  FixedBps600: new PublicKey('8cdKo87jZU2R12KY1BUjjRPwyjgdNjLGqSGQyrDshhud'),
};

// Default bonding curve configuration preset (pump.fun style)
export const DEFAULT_POOL_CONFIG = {
  // Pool fees configuration
  poolFees: {
    baseFee: {
      cliffFeeNumerator: new BN(10000000), // 1% base fee
      firstFactor: 0,
      secondFactor: new BN(0),
      thirdFactor: new BN(0),
      baseFeeMode: 0, // FeeSchedulerLinear
    },
    dynamicFee: {
      binStep: 1,
      binStepU128: new BN('1844674407370955'),
      filterPeriod: 10,
      decayPeriod: 120,
      reductionFactor: 5000,
      maxVolatilityAccumulator: 14460000,
      variableFeeControl: 956,
    },
  },
  // Activation type: 0 = Slot, 1 = Timestamp
  activationType: 1,
  // Collect fee mode: 0 = QuoteToken
  collectFeeMode: 0,
  // Migration option: 0 = MET, 1 = DAMM V1, 2 = DAMM V2
  migrationOption: 1,
  // Token type: 0 = SPL, 1 = Token2022
  tokenType: 0,
  // Token decimals
  tokenDecimal: DEFAULT_TOKEN_DECIMALS,
  // Migration quote threshold in lamports (85 SOL)
  migrationQuoteThreshold: new BN(85_000_000_000),
  // LP percentages for migration
  partnerLpPercentage: 0,
  creatorLpPercentage: 0,
  partnerLockedLpPercentage: 50,
  creatorLockedLpPercentage: 50,
  // Starting price (sqrt) - approximately $0.000001 per token
  sqrtStartPrice: new BN('95072344172433750'),
  // Locked vesting config (disabled)
  lockedVesting: {
    amountPerPeriod: new BN(0),
    cliffDurationFromMigrationTime: new BN(0),
    frequency: new BN(0),
    numberOfPeriod: new BN(0),
    cliffUnlockAmount: new BN(0),
  },
  // Migration fee option index (2 = FixedBps100 = 1%)
  migrationFeeOption: 2,
  // Token supply config
  tokenSupply: {
    preMigrationTokenSupply: new BN(DEFAULT_TOTAL_SUPPLY).mul(new BN(10 ** DEFAULT_TOKEN_DECIMALS)),
    postMigrationTokenSupply: new BN(DEFAULT_TOTAL_SUPPLY).mul(new BN(10 ** DEFAULT_TOKEN_DECIMALS)),
  },
  // Creator trading fee percentage (0 = no creator fee)
  creatorTradingFeePercentage: 0,
  // Token update authority: 0 = None, 1 = Creator, 2 = Partner
  tokenUpdateAuthority: 1,
  // Migration fee config
  migrationFee: {
    feePercentage: 0,
    creatorFeePercentage: 0,
  },
  // Migrated pool fee config
  migratedPoolFee: {
    collectFeeMode: 0,
    dynamicFee: 0,
    poolFeeBps: 0,
  },
  // Padding
  padding: [],
};

// Build default bonding curve with pump.fun style pricing
export const DEFAULT_CURVE = [
  {
    sqrtPrice: new BN('380289371323205464'),
    liquidity: new BN('101410499496546307411360885487802'),
  },
  {
    sqrtPrice: new BN('79226673521066979257578248091'),
    liquidity: new BN('3434578513360188981331421'),
  },
];

// Helper to calculate price from sqrt price (Q64.64 format)
export function priceFromSqrtPrice(sqrtPrice: BN, baseDecimals: number, quoteDecimals: number): number {
  const sqrtPriceNum = Number(sqrtPrice.toString()) / (2 ** 64);
  const price = sqrtPriceNum * sqrtPriceNum;
  return price * Math.pow(10, quoteDecimals - baseDecimals);
}

// Helper to calculate sqrt price from price
export function sqrtPriceFromPrice(price: number, baseDecimals: number, quoteDecimals: number): BN {
  const adjustedPrice = price / Math.pow(10, quoteDecimals - baseDecimals);
  const sqrtPrice = Math.sqrt(adjustedPrice) * (2 ** 64);
  return new BN(Math.floor(sqrtPrice).toString());
}

// Calculate bonding curve progress percentage
export function calculateBondingCurveProgress(quoteReserve: BN, migrationThreshold: BN): number {
  if (migrationThreshold.isZero()) return 0;
  const progress = quoteReserve.mul(new BN(100)).div(migrationThreshold);
  return Math.min(Number(progress.toString()), 100);
}
