// Central wallet configuration for the Farion platform
export const ESCROW_WALLET = 'FkY1JL7vQbgm3R7E7pWQakRKGeJw36iCh2enJgRoutui';
export const PROJECT_WALLET = 'FkY1JL7vQbgm3R7E7pWQakRKGeJw36iCh2enJgRoutui';
export const ADMIN_WALLET = 'FkY1JL7vQbgm3R7E7pWQakRKGeJw36iCh2enJgRoutui';
export const PLATFORM_FEE_WALLET = '2atsUPU5RVmMk7v8fuBxjuTNw5LwNE1ohz5QTAd7mt7P';
