import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

interface ChatInputProps {
  onSendMessage: (message: string) => Promise<boolean>;
  disabled?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, disabled }) => {
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const { connected } = useMultiWallet();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || sending || !connected) return;

    setSending(true);
    const success = await onSendMessage(message);
    if (success) {
      setMessage('');
    }
    setSending(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  if (!connected) {
    return (
      <div className="p-4 border-t bg-muted/50">
        <div className="text-center text-muted-foreground text-sm">
          Connect your Phantom wallet to participate in chat
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 border-t">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message..."
          disabled={disabled || sending}
          className="flex-1"
          maxLength={500}
        />
        <Button
          type="submit"
          disabled={!message.trim() || sending || disabled}
          size="sm"
          className="px-3"
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
      <div className="text-xs text-muted-foreground mt-1">
        {message.length}/500 characters
      </div>
    </div>
  );
};

export default ChatInput;