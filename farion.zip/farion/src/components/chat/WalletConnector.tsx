import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Wallet, MessageCircle, Users } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

const WalletConnector: React.FC = () => {
  const { connectWallet, connecting, availableWallets } = useMultiWallet();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
            <MessageCircle className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">Farion Chat</CardTitle>
          <CardDescription>
            Connect your wallet to join the community chat
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Wallet className="h-4 w-4 text-primary" />
              <span>Secure wallet authentication</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Users className="h-4 w-4 text-primary" />
              <span>Real-time community chat</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <MessageCircle className="h-4 w-4 text-primary" />
              <span>Multiple chat rooms</span>
            </div>
          </div>
          
          <div className="space-y-2">
            {availableWallets.map((wallet) => (
              <Button 
                key={wallet.name}
                onClick={() => connectWallet(wallet)} 
                disabled={connecting || !wallet.installed}
                className="w-full justify-start"
                variant={wallet.installed ? "default" : "ghost"}
              >
                <span className="text-lg mr-3">{wallet.icon}</span>
                <div className="text-left">
                  <div className="font-medium">{wallet.name}</div>
                  {!wallet.installed && (
                    <div className="text-xs opacity-60">Not installed</div>
                  )}
                </div>
                {connecting && <span className="ml-auto text-xs">Connecting...</span>}
              </Button>
            ))}
          </div>
          
          <p className="text-xs text-muted-foreground text-center">
            Your wallet address will be used to generate a unique username for chat
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default WalletConnector;
