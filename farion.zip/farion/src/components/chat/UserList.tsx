import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Users, Circle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface UserSession {
  id: string;
  wallet_address: string;
  username: string;
  is_online: boolean;
  last_seen: string;
}

interface UserListProps {
  users: UserSession[];
  offlineUsers?: UserSession[];
}

const DEV_WALLET_ADDRESS = "HuTQzoz9Zh4vM1MtcESj9PDs95hbPhoG2eJFh8fjNK96";

const UserList: React.FC<UserListProps> = ({ users, offlineUsers = [] }) => {
  const onlineUsers = users.filter(user => user.is_online);

  const renderUser = (user: UserSession, isOnline: boolean) => {
    const isDev = user.wallet_address === DEV_WALLET_ADDRESS;
    
    return (
      <div
        key={user.id}
        className="flex items-center gap-2 p-2 rounded-md hover:bg-accent/50 transition-colors min-h-12 md:min-h-10"
      >
        <Circle className={`h-2 w-2 ${isOnline ? 'fill-green-500 text-green-500' : 'fill-gray-400 text-gray-400'}`} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <div className="text-xs font-medium truncate">
              {user.username}
            </div>
            {isDev && (
              <Badge variant="outline" className="text-xs px-1 py-0 h-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
                DEV
              </Badge>
            )}
          </div>
          <div className="text-xs text-muted-foreground truncate">
            {isOnline 
              ? `${user.wallet_address.slice(0, 8)}...`
              : `Last seen ${formatDistanceToNow(new Date(user.last_seen), { addSuffix: true })}`
            }
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full md:w-48 md:border-l bg-card p-4">
      <div className="space-y-4">
        {/* Online Users Section */}
        <div>
          <div className="mb-3 flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="font-semibold text-sm">Online</span>
            <Badge variant="secondary" className="text-xs">
              {onlineUsers.length}
            </Badge>
          </div>
          
          <ScrollArea className="h-[200px] md:h-[250px]">
            <div className="space-y-2">
              {onlineUsers.length === 0 ? (
                <div className="text-xs text-muted-foreground text-center py-4">
                  No users online
                </div>
              ) : (
                onlineUsers.map((user) => renderUser(user, true))
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Offline Users Section */}
        {offlineUsers.length > 0 && (
          <div className="mt-6">
            <div className="mb-3 flex items-center gap-2">
              <Circle className="h-4 w-4 text-gray-400" />
              <span className="font-semibold text-sm">Recently Offline</span>
              <Badge variant="outline" className="text-xs">
                {offlineUsers.length}
              </Badge>
            </div>
            
            <ScrollArea className="h-[150px] md:h-[200px]">
              <div className="space-y-2">
                {offlineUsers.map((user) => renderUser(user, false))}
              </div>
            </ScrollArea>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserList;