import React, { useEffect, useRef } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

const DEV_WALLET_ADDRESS = "HuTQzoz9Zh4vM1MtcESj9PDs95hbPhoG2eJFh8fjNK96";

interface ChatMessage {
  id: string;
  wallet_address: string;
  username: string;
  message: string;
  created_at: string;
}

interface ChatMessagesProps {
  messages: ChatMessage[];
  loading: boolean;
}

const ChatMessages: React.FC<ChatMessagesProps> = ({ messages, loading }) => {
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { walletAddress } = useMultiWallet();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const isOwnMessage = (messageWalletAddress: string) => {
    return walletAddress === messageWalletAddress;
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-muted-foreground">Loading messages...</div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      <ScrollArea ref={scrollAreaRef} className="flex-1 p-3 md:p-4">
        <div className="space-y-3 md:space-y-4">
          {messages.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No messages yet. Start the conversation!
            </div>
          ) : (
            messages.map((message) => {
              const isDev = message.wallet_address === DEV_WALLET_ADDRESS;
              const isOwnMsg = isOwnMessage(message.wallet_address);
              
              return (
                <div
                  key={message.id}
                  className={`flex ${isOwnMsg ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] sm:max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${
                      isOwnMsg
                        ? isDev
                          ? 'bg-red-500 text-white'
                          : 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {!isOwnMsg && (
                      <div className="flex items-center gap-1 text-xs font-medium mb-1 opacity-80">
                        <span>{message.username}</span>
                        {isDev && (
                          <Badge variant="outline" className="text-xs px-1 py-0 h-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
                            DEV
                          </Badge>
                        )}
                      </div>
                    )}
                    <div className="text-sm break-words">{message.message}</div>
                    <div className="text-xs opacity-60 mt-1">
                      {formatTime(message.created_at)}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ChatMessages;