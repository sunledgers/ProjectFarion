import React from 'react';
import { Button } from '@/components/ui/button';
import { Hash, Users, MessageCircle } from 'lucide-react';

interface ChatRoom {
  id: string;
  name: string;
  description: string;
}

interface ChatRoomsProps {
  rooms: ChatRoom[];
  activeRoom: string | null;
  onRoomSelect: (roomId: string) => void;
}

const ChatRooms: React.FC<ChatRoomsProps> = ({ rooms, activeRoom, onRoomSelect }) => {
  const getRoomIcon = (roomName: string) => {
    switch (roomName.toLowerCase()) {
      case 'general':
        return <Hash className="h-4 w-4" />;
      case 'random':
        return <MessageCircle className="h-4 w-4" />;
      default:
        return <Users className="h-4 w-4" />;
    }
  };

  return (
    <div className="w-full md:w-64 md:border-r bg-card p-4">
      <div className="mb-4">
        <h3 className="font-semibold text-foreground mb-2">Chat Rooms</h3>
        <div className="space-y-2">
          {rooms.map((room) => (
            <Button
              key={room.id}
              variant={activeRoom === room.id ? "default" : "ghost"}
              className="w-full justify-start gap-2 text-left min-h-12 md:min-h-10"
              onClick={() => onRoomSelect(room.id)}
            >
              {getRoomIcon(room.name)}
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm md:text-base">{room.name}</div>
                <div className="text-xs opacity-70 truncate">
                  {room.description}
                </div>
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChatRooms;