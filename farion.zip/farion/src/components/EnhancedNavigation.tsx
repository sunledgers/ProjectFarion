import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Home, 
  MessageCircle, 
  Plus, 
  Globe, 
  ImageIcon, 
  Users, 
  Lock, 
  Trophy, 
  Gift,
  ShoppingBag,
  Menu,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import TokenBalanceDisplay from '@/components/TokenBalanceDisplay';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

const EnhancedNavigation = () => {
  const location = useLocation();
  const { connected } = useMultiWallet();
  const [isExpanded, setIsExpanded] = useState(false);

  const navigationItems = [
    { to: "/", icon: Home, label: "Home" },
    { to: "/chat", icon: MessageCircle, label: "Chat" },
    { to: "/launchpad", icon: Plus, label: "Launchpad" },
    { to: "/memes", icon: ImageIcon, label: "Memes" },
    { to: "/staking", icon: Lock, label: "Staking" },
    { to: "/jackpot", icon: Trophy, label: "Jackpot" },
    { to: "/powerball", icon: Gift, label: "Powerball" },
    { to: "/referral", icon: Gift, label: "Tasks" },
    { to: "/nft-marketplace", icon: ShoppingBag, label: "NFT Marketplace" },
    { to: "/forum", icon: Users, label: "ACHAN" },
  ];

  const externalItems = [
    { href: "https://play.farion.io", icon: Globe, label: "Virtual World" },
  ];

  return (
    <>
      {/* Mobile Navigation */}
      <div className="sm:hidden">
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="fixed top-2 left-2 right-2 z-[100] bg-card/95 backdrop-blur-md border border-border rounded-2xl shadow-lg"
        >
          <div className="flex items-center justify-between p-3">
            <div className="flex items-center gap-2">
              {/* Core navigation items for mobile */}
              <Link to="/">
                <Button
                  variant={location.pathname === "/" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <Home className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/chat">
                <Button
                  variant={location.pathname === "/chat" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <MessageCircle className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/referral">
                <Button
                  variant={location.pathname === "/referral" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <Gift className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            <div className="flex items-center gap-2">
              {connected && <TokenBalanceDisplay />}
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full p-2"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden border-t border-border"
              >
                <div className="grid grid-cols-2 gap-2 p-3">
                  {navigationItems.slice(3).map((item) => (
                    <Link key={item.to} to={item.to}>
                      <Button
                        variant={location.pathname === item.to || location.pathname.startsWith(item.to) ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start rounded-xl"
                        onClick={() => setIsExpanded(false)}
                      >
                        <item.icon className="h-4 w-4 mr-2" />
                        {item.label}
                      </Button>
                    </Link>
                  ))}
                  {externalItems.map((item) => (
                    <a key={item.href} href={item.href} target="_blank" rel="noopener noreferrer">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start rounded-xl"
                        onClick={() => setIsExpanded(false)}
                      >
                        <item.icon className="h-4 w-4 mr-2" />
                        {item.label}
                      </Button>
                    </a>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Desktop Navigation */}
      <div className="hidden sm:block">
        <motion.nav
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="fixed top-4 left-4 z-[100] bg-card/95 backdrop-blur-md border border-border rounded-2xl shadow-lg"
        >
          <div className="flex items-center gap-2 p-3">
            {navigationItems.map((item) => (
              <Link key={item.to} to={item.to}>
                <Button
                  variant={location.pathname === item.to || location.pathname.startsWith(item.to) ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full px-3"
                >
                  <item.icon className="h-4 w-4 mr-2" />
                  <span className="hidden lg:inline">{item.label}</span>
                </Button>
              </Link>
            ))}
            
            {externalItems.map((item) => (
              <a key={item.href} href={item.href} target="_blank" rel="noopener noreferrer">
                <Button
                  variant="ghost"
                  size="sm"
                  className="rounded-full px-3"
                >
                  <item.icon className="h-4 w-4 mr-2" />
                  <span className="hidden lg:inline">{item.label}</span>
                </Button>
              </a>
            ))}
          </div>
          
          {connected && (
            <div className="px-3 pb-3">
              <TokenBalanceDisplay />
            </div>
          )}
        </motion.nav>
      </div>
    </>
  );
};

export default EnhancedNavigation;