import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const Footer = () => {
  const socialLinks = [
    { 
      name: 'X', 
      icon: '/farion-uploads/x-icon.png', 
      url: 'https://x.com/ProjectFarion' 
    },
    { 
      name: 'Telegram', 
      icon: '/farion-uploads/telegram-icon.png', 
      url: 'https://t.me/FarionPortal' 
    }
  ];

  const navLinks = [
    { name: 'Home', url: '/', isInternal: true },
    { name: 'Support', url: 'https://t.me/FarionPortal', isInternal: false },
    { name: 'Whitepaper', url: '/whitepaper', isInternal: true }
  ];

  return (
    <footer className="bg-gradient-to-b from-emerald-900 to-emerald-950 dark:from-background dark:to-card text-white dark:text-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="col-span-2"
          >
            <img 
              src="/farion-logo.png" 
              alt="Farion Logo"
              className="w-20 h-20 mb-4"
            />
            <h3 className="text-2xl font-bold mb-4 text-emerald-300 dark:text-primary">Farion</h3>
            <p className="text-emerald-200 leading-relaxed max-w-md">
              A premium Solana token with staking, jackpots, and community features.
              Join our ecosystem and start earning today.
            </p>
          </motion.div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            <h4 className="text-lg font-bold mb-4 text-emerald-300 dark:text-primary">Navigation</h4>
            <ul className="space-y-2">
              {navLinks.map((link, index) => (
                <li key={index}>
                  {link.isInternal ? (
                    <Link 
                      to={link.url}
                      className="text-emerald-200 hover:text-white transition-colors duration-200 hover:underline"
                    >
                      {link.name}
                    </Link>
                  ) : (
                    <a 
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-200 hover:text-white transition-colors duration-200 hover:underline"
                    >
                      {link.name}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <h4 className="text-lg font-bold mb-4 text-emerald-300 dark:text-primary">Follow Us</h4>
            <div className="flex flex-col space-y-3">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.url}
                  whileHover={{ scale: 1.05, x: 5 }}
                  className="flex items-center gap-3 text-emerald-200 hover:text-white transition-all duration-200"
                >
                  <img 
                    src={social.icon} 
                    alt={social.name}
                    className={`opacity-80 hover:opacity-100 transition-opacity ${
                      social.name === 'X' ? 'w-7 h-7' : 'w-6 h-6'
                    }`}
                  />
                  <span>{social.name}</span>
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-12 pt-8 text-center"
        >
          <p className="text-emerald-300">
            © 2025 Farion. All rights reserved.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
