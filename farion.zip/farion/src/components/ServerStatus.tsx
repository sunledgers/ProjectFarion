import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

const ServerStatus = () => {
  const [isOnline, setIsOnline] = useState(true);
  const [playerCount, setPlayerCount] = useState(15);
  const [responseTime, setResponseTime] = useState(35);

  // Random function for 0-10 players
  const getPlayerCount = () => {
    return Math.floor(Math.random() * 11); // 0-10 players
  };

  useEffect(() => {
    const interval = setInterval(() => {
      // Use random for player count
      setPlayerCount(getPlayerCount());
      // Simulate response time changes between 30-40ms
      setResponseTime(Math.floor(Math.random() * 11) + 30);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-16 bg-gradient-to-r from-secondary/20 to-background dark:from-background dark:to-card/20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-blue-900 mb-4">Server Status</h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            <Card className="p-6 text-center bg-card/80 backdrop-blur-sm h-full flex flex-col justify-center">
              <div className="mb-4">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className={`w-4 h-4 rounded-full mx-auto ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}
                />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Status</h3>
              <p className={`text-lg font-semibold ${isOnline ? 'text-green-600' : 'text-red-600'}`}>
                {isOnline ? '🟢 Online' : '🔴 Offline'}
              </p>
            </Card>
          </motion.div>

          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <Card className="p-6 text-center bg-card/80 backdrop-blur-sm h-full flex flex-col justify-center">
              <div className="text-3xl mb-4">👥</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Players Online</h3>
              <motion.p
                key={playerCount}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="text-2xl font-bold text-blue-600"
              >
                {playerCount}
              </motion.p>
            </Card>
          </motion.div>

          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <Card className="p-6 text-center bg-card/80 backdrop-blur-sm h-full flex flex-col justify-center">
              <div className="text-3xl mb-4">⚡</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Response Time</h3>
              <motion.p
                key={responseTime}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="text-2xl font-bold text-green-600"
              >
                {responseTime}ms
              </motion.p>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ServerStatus;
