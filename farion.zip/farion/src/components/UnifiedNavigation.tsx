import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useTheme } from '@/components/ThemeProvider';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { ADMIN_WALLET } from '@/config/wallets';
import WalletConnectionModal from '@/components/WalletConnectionModal';
import { 
  Home, 
  MessageCircle, 
  Rocket, 
  ImageIcon, 
  Users, 
  Lock, 
  Trophy, 
  Gift,
  ShoppingBag,
  Menu,
  X,
  Moon,
  Sun,
  Wallet,
  LogOut,
  Shield,
  History,
  Download,
  LayoutDashboard,
  Handshake,
  PieChart
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const UnifiedNavigation = () => {
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { connected, username, selectedWallet, tokenBalance, disconnect, walletAddress } = useMultiWallet();
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDesktopNavOpen, setIsDesktopNavOpen] = useState(true);
  const [showWalletModal, setShowWalletModal] = useState(false);

  const isAdmin = walletAddress === ADMIN_WALLET;

  const navigationItems = [
    { to: "/", icon: Home, label: "Home" },
    { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { to: "/portfolio", icon: PieChart, label: "Portfolio" },
    { to: "/chat", icon: MessageCircle, label: "Chat" },
    { to: "/launchpad", icon: Rocket, label: "Launchpad" },
    { to: "/p2p-loan", icon: Handshake, label: "P2P / Loan" },
    { to: "/memes", icon: ImageIcon, label: "Memes" },
    { to: "/staking", icon: Lock, label: "Staking" },
    { to: "/jackpot", icon: Trophy, label: "Jackpot" },
    { to: "/powerball", icon: Gift, label: "Powerball" },
    { to: "/referral", icon: Gift, label: "Tasks" },
    { to: "/nft-marketplace", icon: ShoppingBag, label: "NFT Boost" },
    { to: "/forum", icon: Users, label: "FCHAN" },
    { to: "/transactions", icon: History, label: "History" },
    { to: "/install", icon: Download, label: "Install App" },
  ];

  const formatBalance = (balance: number) => {
    if (balance >= 1000000) return `${(balance / 1000000).toFixed(1)}M`;
    if (balance >= 1000) return `${(balance / 1000).toFixed(1)}K`;
    return balance.toFixed(2);
  };

  return (
    <>
      {/* Mobile Navigation */}
      <div className="sm:hidden">
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="fixed top-2 left-2 right-2 z-[100] bg-card/95 backdrop-blur-md border border-border rounded-2xl shadow-lg"
        >
          <div className="flex items-center justify-between p-3">
            <div className="flex items-center gap-2">
              {/* Core navigation items for mobile */}
              <Link to="/">
                <Button
                  variant={location.pathname === "/" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <Home className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/dashboard">
                <Button
                  variant={location.pathname === "/dashboard" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <LayoutDashboard className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/launchpad">
                <Button
                  variant={location.pathname === "/launchpad" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <Rocket className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/jackpot">
                <Button
                  variant={location.pathname === "/jackpot" ? "default" : "ghost"}
                  size="sm"
                  className="rounded-full p-2"
                >
                  <Trophy className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full p-2"
                onClick={toggleTheme}
              >
                {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full p-2"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden border-t border-border"
              >
                <div className="p-3 space-y-3">
                  {/* Wallet Info */}
                  {connected ? (
                    <Card className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-xs font-medium">Wallet</div>
                        <Button variant="ghost" size="sm" onClick={disconnect} className="h-6 px-2">
                          <LogOut className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{selectedWallet?.icon}</span>
                          <div>
                            <div className="text-xs font-medium">{username}</div>
                            <div className="text-xs text-muted-foreground">{selectedWallet?.name}</div>
                          </div>
                        </div>
                        {tokenBalance && (
                          <div className="text-xs">
                            <span className="font-medium">{formatBalance(tokenBalance.tokenBalance)} FARION</span>
                            <span className="text-muted-foreground ml-1">
                              ({tokenBalance.supplyPercentage.toFixed(3)}%)
                            </span>
                          </div>
                        )}
                      </div>
                    </Card>
                  ) : (
                    <Button 
                      onClick={() => {
                        setIsExpanded(false);
                        setShowWalletModal(true);
                      }}
                      className="w-full"
                    >
                      <Wallet className="h-4 w-4 mr-2" />
                      Connect Wallet
                    </Button>
                  )}

                  {/* Navigation Links */}
                  <div className="grid grid-cols-2 gap-2">
                    <Link to="/chat">
                      <Button
                        variant={location.pathname === "/chat" ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start rounded-xl"
                        onClick={() => setIsExpanded(false)}
                      >
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Chat
                      </Button>
                    </Link>
                    <Link to="/referral">
                      <Button
                        variant={location.pathname === "/referral" ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start rounded-xl"
                        onClick={() => setIsExpanded(false)}
                      >
                        <Gift className="h-4 w-4 mr-2" />
                        Tasks
                      </Button>
                    </Link>
                    <Link to="/launchpad">
                      <Button
                        variant={location.pathname === "/launchpad" ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start rounded-xl"
                        onClick={() => setIsExpanded(false)}
                      >
                        <Rocket className="h-4 w-4 mr-2" />
                        Launchpad
                      </Button>
                    </Link>
                    <Link to="/p2p-loan">
                      <Button
                        variant={location.pathname === "/p2p-loan" ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start rounded-xl"
                        onClick={() => setIsExpanded(false)}
                      >
                        <Handshake className="h-4 w-4 mr-2" />
                        P2P / Loan
                      </Button>
                    </Link>
                    {navigationItems.filter(item => !['/', '/dashboard', '/chat', '/launchpad', '/p2p-loan', '/memes', '/staking', '/jackpot', '/referral'].includes(item.to)).map((item) => (
                      <Link key={item.to} to={item.to}>
                        <Button
                          variant={location.pathname === item.to || location.pathname.startsWith(item.to) ? "default" : "ghost"}
                          size="sm"
                          className="w-full justify-start rounded-xl"
                          onClick={() => setIsExpanded(false)}
                        >
                          <item.icon className="h-4 w-4 mr-2" />
                          {item.label}
                        </Button>
                      </Link>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Desktop Navigation - Collapsible */}
      <div className="hidden sm:block">
        {/* Navigation Trigger */}
        {!isDesktopNavOpen && (
          <motion.button
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            onClick={() => setIsDesktopNavOpen(true)}
            className="fixed top-4 left-4 z-[110] bg-card/95 backdrop-blur-md border border-border rounded-lg p-3 shadow-lg hover:bg-accent/50 transition-colors"
          >
            <Menu className="h-5 w-5" />
          </motion.button>
        )}

        {/* Navigation Sidebar */}
        <AnimatePresence>
          {isDesktopNavOpen && (
            <motion.div
              initial={{ x: -320, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -320, opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="fixed top-0 left-0 h-full w-80 z-[100] bg-card/95 backdrop-blur-xl border-r border-border shadow-2xl flex flex-col"
            >
              {/* Header */}
              <div className="p-6 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src="/farion-logo.png" alt="Farion" className="w-10 h-10" />
                  <div>
                    <h2 className="text-lg font-bold text-foreground">Farion</h2>
                    <p className="text-sm text-muted-foreground">Platform</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsDesktopNavOpen(false)}
                  className="p-2"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Main Navigation */}
              <div className="flex-1 p-4 space-y-2 overflow-y-auto">
                <div className="text-xs font-medium text-muted-foreground px-3 py-2 uppercase tracking-wider">
                  Navigation
                </div>
                {navigationItems.map((item) => (
                  <Link key={item.to} to={item.to}>
                    <Button
                      variant={location.pathname === item.to || location.pathname.startsWith(item.to) ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start rounded-xl px-4 py-3 h-auto"
                    >
                      <item.icon className="h-5 w-5 mr-3" />
                      <span className="font-medium">{item.label}</span>
                    </Button>
                  </Link>
                ))}
              </div>

              {/* Bottom Utility Panel */}
              <div className="p-4 border-t border-border space-y-4">
                {/* Admin Panel Link - Only for admin wallet */}
                {isAdmin && (
                  <Link to="/admin">
                    <Button
                      variant={location.pathname === "/admin" ? "default" : "outline"}
                      size="sm"
                      className="w-full justify-start rounded-xl px-4 py-3 h-auto bg-destructive/10 hover:bg-destructive/20 border-destructive/30"
                    >
                      <Shield className="h-5 w-5 mr-3 text-destructive" />
                      <span className="font-medium">Admin Panel</span>
                    </Button>
                  </Link>
                )}

                {/* Theme Toggle */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={toggleTheme}
                  className="w-full justify-start rounded-xl px-4 py-3 h-auto"
                >
                  {theme === 'light' ? <Moon className="h-5 w-5 mr-3" /> : <Sun className="h-5 w-5 mr-3" />}
                  <span className="font-medium">{theme === 'light' ? 'Dark Mode' : 'Light Mode'}</span>
                </Button>

              {/* Wallet Status */}
                {connected ? (
                  <div className="space-y-2">
                    <div className="text-xs font-medium text-muted-foreground px-1">Connected Wallet</div>
                    <Card className="p-3 bg-accent/20">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-2xl">{selectedWallet?.icon}</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">{username}</div>
                          <div className="text-xs text-muted-foreground">{selectedWallet?.name}</div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={disconnect} className="h-8 w-8 p-0">
                          <LogOut className="h-4 w-4" />
                        </Button>
                      </div>
                      {tokenBalance && (
                        <div className="text-sm">
                          <span className="font-medium text-primary">{formatBalance(tokenBalance.tokenBalance)} FARION</span>
                          <span className="text-muted-foreground ml-2">
                            ({tokenBalance.supplyPercentage.toFixed(3)}% of supply)
                          </span>
                        </div>
                      )}
                    </Card>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Button 
                      onClick={() => setShowWalletModal(true)}
                      className="w-full justify-start rounded-xl px-4 py-3 h-auto"
                    >
                      <Wallet className="h-5 w-5 mr-3" />
                      <span className="font-medium">Connect Wallet</span>
                    </Button>
                    <div className="text-xs text-center text-muted-foreground">
                      Connect to access all features
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main content offset when nav is open */}
        <div className={isDesktopNavOpen ? "ml-80 transition-all duration-300" : "transition-all duration-300"}></div>
      </div>

      {/* Wallet Connection Modal */}
      <WalletConnectionModal 
        open={showWalletModal} 
        onOpenChange={setShowWalletModal} 
      />
    </>
  );
};

export default UnifiedNavigation;
