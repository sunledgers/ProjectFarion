import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useSolanaJackpot } from '@/hooks/useSolanaJackpot';
import { Trophy, Users, Timer, Coins, Zap, Flame, Target, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const JackpotSystem = () => {
  const {
    currentRound,
    participants,
    totalPotSOL,
    projectFeeSOL,
    winnerPotSOL,
    loading,
    countdown,
    isRoundActive,
    canJoin,
    needsMorePlayers,
    winner,
    showWinnerAnimation,
    MIN_BET_SOL,
    MAX_BET_SOL,
    MIN_PARTICIPANTS,
    joinJackpot
  } = useSolanaJackpot();

  const [betAmount, setBetAmount] = useState(MIN_BET_SOL.toString());

  const handleJoinPot = async () => {
    const amount = parseFloat(betAmount);
    await joinJackpot(amount);
    // Reset bet amount after attempt (success/failure is handled in the hook)
    setBetAmount(MIN_BET_SOL.toString());
  };

  const participantCount = currentRound?.participant_count || 0;
  const progressPercent = Math.min((participantCount / MIN_PARTICIPANTS) * 100, 100);

  // Pot growth animation
  const potVariants = {
    idle: { scale: 1 },
    growing: { 
      scale: [1, 1.05, 1],
      transition: { duration: 0.6, repeat: Infinity, repeatDelay: 2 }
    }
  };

  return (
    <div className="space-y-6">
      {/* Winner Announcement Overlay */}
      <AnimatePresence>
        {showWinnerAnimation && winner && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ y: 50 }}
              animate={{ y: 0 }}
              className="bg-gradient-to-br from-yellow-500 via-orange-500 to-red-500 p-1 rounded-2xl"
            >
              <div className="bg-background rounded-2xl p-8 text-center space-y-4">
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.2, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Trophy className="h-20 w-20 mx-auto text-yellow-500" />
                </motion.div>
                <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
                  🎉 WINNER! 🎉
                </h2>
                <div className="space-y-2">
                  <p className="text-2xl font-bold">{winner.username}</p>
                  <p className="text-sm text-muted-foreground">
                    {winner.wallet.slice(0, 6)}...{winner.wallet.slice(-4)}
                  </p>
                </div>
                <div className="text-4xl font-bold text-green-500">
                  +{winner.amount.toFixed(3)} SOL
                </div>
                <p className="text-sm text-muted-foreground">
                  Congratulations! Prize will be sent to winner's wallet.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Jackpot Display */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-orange-500/5 via-background to-red-500/5 border-orange-500/20">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-red-500/5 opacity-50" />
        
        <CardHeader className="relative text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <motion.div
              animate={{ rotate: totalPotSOL > 0.5 ? [0, 10, -10, 0] : 0 }}
              transition={{ duration: 2, repeat: totalPotSOL > 0.5 ? Infinity : 0 }}
            >
              <Trophy className="h-8 w-8 text-orange-500" />
            </motion.div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
              SOL Jackpot 🚀
            </CardTitle>
          </div>
          
          <div className="flex justify-center gap-2">
            <Badge variant="outline" className="border-orange-500/30 text-orange-600">
              Live Game
            </Badge>
            <Badge variant="outline" className="border-green-500/30 text-green-600">
              Real SOL
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="relative space-y-6">
          {/* Pot Display */}
          <div className="text-center space-y-4">
            <motion.div
              variants={potVariants}
              animate={totalPotSOL > 0 ? "growing" : "idle"}
              className="relative"
            >
              <div className="text-5xl font-bold text-orange-500 mb-2 flex items-center justify-center gap-2">
                <Flame className="h-8 w-8 text-orange-500" />
                {totalPotSOL.toFixed(3)} SOL
              </div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div>Winner receives: <span className="font-bold text-green-600">{winnerPotSOL.toFixed(3)} SOL</span></div>
                <div>Project development (10%): <span className="font-bold">{projectFeeSOL.toFixed(3)} SOL</span></div>
              </div>
            </motion.div>

            {/* USD Estimate */}
            <div className="text-lg text-muted-foreground">
              ≈ ${(totalPotSOL * 220).toLocaleString()} USD*
            </div>
          </div>

          <Separator />

          {/* Round Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Participants Progress */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-500" />
                  <span className="font-semibold">Players</span>
                </div>
                <Badge variant={needsMorePlayers ? "destructive" : "default"}>
                  {participantCount}/{MIN_PARTICIPANTS}
                </Badge>
              </div>
              
              <Progress 
                value={progressPercent} 
                className="h-3 bg-muted"
              />
              
              <div className="text-xs text-muted-foreground text-center">
                {needsMorePlayers ? `Need ${MIN_PARTICIPANTS - participantCount} more players` : 'Ready to start!'}
              </div>
            </div>

            {/* Timer */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-purple-500" />
                  <span className="font-semibold">Timer</span>
                </div>
                <Badge variant={isRoundActive ? "default" : "secondary"}>
                  {isRoundActive ? countdown : 'Waiting'}
                </Badge>
              </div>
              
              {isRoundActive && (
                <div className="text-center">
                  <motion.div
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    className="text-2xl font-bold text-purple-500"
                  >
                    {countdown}
                  </motion.div>
                  <div className="text-xs text-muted-foreground">Time remaining</div>
                </div>
              )}
              
              {!isRoundActive && (
                <div className="text-center text-muted-foreground">
                  <Clock className="h-6 w-6 mx-auto mb-1 opacity-50" />
                  <div className="text-xs">Waiting for players</div>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Join Section */}
          <AnimatePresence>
            {canJoin && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4 p-4 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-lg border border-orange-500/20"
              >
                <div className="text-center">
                  <Target className="h-6 w-6 mx-auto text-orange-500 mb-2" />
                  <h3 className="font-bold text-lg">Join the Jackpot!</h3>
                  <p className="text-sm text-muted-foreground">
                    Bet between {MIN_BET_SOL}-{MAX_BET_SOL} SOL • Higher bets = better odds
                  </p>
                </div>
                
                <div className="flex gap-3">
                  <div className="flex-1">
                    <Input
                      type="number"
                      placeholder={`${MIN_BET_SOL} - ${MAX_BET_SOL} SOL`}
                      value={betAmount}
                      onChange={(e) => setBetAmount(e.target.value)}
                      min={MIN_BET_SOL}
                      max={MAX_BET_SOL}
                      step={0.01}
                      className="text-center font-mono"
                    />
                  </div>
                  <Button 
                    onClick={handleJoinPot}
                    disabled={loading || !canJoin}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold px-6"
                  >
                    {loading ? (
                      <>
                        <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Joining...
                      </>
                    ) : (
                      <>
                        <Coins className="h-4 w-4 mr-2" />
                        Join Pot
                      </>
                    )}
                  </Button>
                </div>
                
                <div className="text-xs text-center text-muted-foreground">
                  ≈ ${((parseFloat(betAmount) || 0) * 220).toFixed(2)} USD
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Round Active Message */}
          {isRoundActive && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg"
            >
              <Zap className="h-6 w-6 mx-auto text-purple-500 mb-2" />
              <div className="font-bold text-purple-600">Round In Progress!</div>
              <div className="text-sm text-muted-foreground">
                Winner will be selected when timer reaches zero
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Current Participants */}
      {participants.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              Current Round Players ({participants.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {participants.slice(-8).reverse().map((participant, index) => (
                <motion.div
                  key={participant.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="flex justify-between items-center p-3 bg-muted/50 rounded-lg border"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                      {participant.username.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-medium text-sm">{participant.username}</div>
                      <div className="text-xs text-muted-foreground">
                        {participant.wallet_address.slice(0, 4)}...{participant.wallet_address.slice(-4)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <Badge variant="outline" className="font-mono">
                      {participant.bet_amount} SOL
                    </Badge>
                    <div className="text-xs text-muted-foreground mt-1">
                      {participant.odds_percentage.toFixed(1)}% odds
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Game Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <p>• <span className="font-semibold">Minimum:</span> {MIN_BET_SOL} SOL per bet</p>
              <p>• <span className="font-semibold">Maximum:</span> {MAX_BET_SOL} SOL per bet</p>
              <p>• <span className="font-semibold">Players needed:</span> {MIN_PARTICIPANTS} minimum</p>
            </div>
            <div className="space-y-2">
              <p>• <span className="font-semibold">Timer:</span> 120 seconds when ready</p>
              <p>• <span className="font-semibold">Winner odds:</span> Based on bet size</p>
              <p>• <span className="font-semibold">Project fee:</span> 10% for development</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="h-4 w-4 text-orange-500" />
              <span className="font-semibold text-orange-600">Real SOL Betting</span>
            </div>
            <p className="text-xs">
              This is a live game using real Solana. All transactions are on-chain and verifiable. 
              Only bet what you can afford to lose. Winner is selected fairly based on bet proportions.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default JackpotSystem;