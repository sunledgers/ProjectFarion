import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Calculator, Coins } from 'lucide-react';

const AukCalculator = () => {
  const [ingameCoins, setIngameCoins] = useState<string>('');
  const [aukTokens, setAukTokens] = useState<number>(0);

  // Conversion rate: 100K ingame coins = 100 $AUK
  const CONVERSION_RATE = 100000; // 1 $AUK per 1000 ingame coins

  const calculateAUK = () => {
    const coins = parseFloat(ingameCoins);
    if (isNaN(coins) || coins < 0) {
      setAukTokens(0);
      return;
    }
    const result = coins / CONVERSION_RATE * 100;
    setAukTokens(result);
  };

  const handleInputChange = (value: string) => {
    setIngameCoins(value);
    if (value) {
      const coins = parseFloat(value);
      if (!isNaN(coins) && coins >= 0) {
        const result = coins / CONVERSION_RATE * 100;
        setAukTokens(result);
      } else {
        setAukTokens(0);
      }
    } else {
      setAukTokens(0);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="w-full max-w-md mx-auto"
    >
      <Card className="bg-gradient-to-br from-card/90 to-card/70 backdrop-blur-sm border-primary/20 shadow-xl">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Calculator className="h-6 w-6 text-primary" />
            <Coins className="h-6 w-6 text-yellow-500" />
          </div>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            $FARION Token Calculator
          </CardTitle>
          <CardDescription>
            Convert your in-game coins to $FARION tokens
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="ingame-coins" className="text-sm font-medium">
              In-Game Coins
            </Label>
            <Input
              id="ingame-coins"
              type="number"
              placeholder="Enter amount of coins..."
              value={ingameCoins}
              onChange={(e) => handleInputChange(e.target.value)}
              min="0"
              className="text-center text-lg font-semibold"
            />
          </div>
          
          <div className="text-center">
            <div className="text-sm text-muted-foreground mb-2">Conversion Rate</div>
            <div className="text-lg font-semibold text-primary">
              100,000 coins = 100 $FARION
            </div>
          </div>

          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="bg-gradient-to-r from-primary/10 to-primary-glow/10 rounded-lg p-4 text-center border border-primary/20"
          >
            <div className="text-sm text-muted-foreground mb-1">You'll earn</div>
            <div className="text-3xl font-bold text-primary">
              {aukTokens.toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </div>
            <div className="text-lg font-semibold text-primary">$FARION Tokens</div>
          </motion.div>

          <div className="text-xs text-muted-foreground text-center">
            * Tokens are earned by collecting in-game coins during gameplay
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AukCalculator;