import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { Coins, Trophy, Clock, CheckCircle, AlertCircle } from 'lucide-react';

interface Reward {
  id: string;
  reward_amount: number;
  status: string;
  created_at: string;
  transaction_hash?: string;
  task_submission: {
    referral_tasks: {
      title: string;
    };
  };
}

const UserRewards = () => {
  const { walletAddress } = useMultiWallet();
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalRewards, setTotalRewards] = useState(0);
  const [pendingRewards, setPendingRewards] = useState(0);

  useEffect(() => {
    if (walletAddress) {
      fetchRewards();
    }
  }, [walletAddress]);

  const fetchRewards = async () => {
    if (!walletAddress) return;

    try {
      const { data, error } = await supabase
        .from('user_rewards')
        .select(`
          *,
          task_submission:user_task_submissions!inner(
            referral_tasks!inner(title)
          )
        `)
        .eq('wallet_address', walletAddress)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setRewards(data || []);
      
      // Calculate totals
      const total = data?.reduce((sum, reward) => {
        if (reward.status === 'distributed') {
          return sum + Number(reward.reward_amount);
        }
        return sum;
      }, 0) || 0;
      
      const pending = data?.reduce((sum, reward) => {
        if (reward.status === 'pending') {
          return sum + Number(reward.reward_amount);
        }
        return sum;
      }, 0) || 0;

      setTotalRewards(total);
      setPendingRewards(pending);
    } catch (error) {
      console.error('Error fetching rewards:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'distributed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-orange-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'distributed':
        return 'bg-green-500/10 text-green-500 border-green-500/20';
      case 'failed':
        return 'bg-red-500/10 text-red-500 border-red-500/20';
      default:
        return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
    }
  };

  if (!walletAddress) {
    return null;
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Card className="animate-pulse">
          <CardHeader>
            <div className="h-6 bg-muted rounded w-1/3"></div>
          </CardHeader>
          <CardContent>
            <div className="h-20 bg-muted rounded"></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Your Rewards</h2>
        <p className="text-muted-foreground">
          Track your earned $AUK rewards from completed tasks
        </p>
      </div>

      {/* Rewards Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Coins className="h-8 w-8 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Earned</p>
                <p className="text-2xl font-bold text-primary">{totalRewards} $AUK</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/10 to-orange-500/5 border-orange-500/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 text-orange-500" />
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-orange-500">{pendingRewards} $AUK</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rewards History */}
      {rewards.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Rewards History
            </CardTitle>
            <CardDescription>
              Your complete rewards transaction history
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {rewards.map((reward) => (
                <div
                  key={reward.id}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border"
                >
                  <div className="flex items-center gap-3">
                    {getStatusIcon(reward.status)}
                    <div>
                      <p className="font-medium">
                        {reward.task_submission.referral_tasks.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(reward.created_at).toLocaleDateString()}
                      </p>
                      {reward.transaction_hash && (
                        <p className="text-xs text-muted-foreground mt-1">
                          TX: {reward.transaction_hash.slice(0, 16)}...
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-primary">
                      +{reward.reward_amount} $AUK
                    </p>
                    <Badge 
                      variant="outline" 
                      className={getStatusColor(reward.status)}
                    >
                      {reward.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-8 text-center">
            <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Rewards Yet</h3>
            <p className="text-muted-foreground">
              Complete tasks above to start earning $AUK rewards!
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default UserRewards;