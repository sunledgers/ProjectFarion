import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const GameFeatures = () => {
  const [currentFeature, setCurrentFeature] = useState(0);

  const features = [
    {
      title: "💎 Staking Rewards",
      description: "Stake your FARION tokens and earn passive rewards. The longer you stake, the higher your returns!",
      icon: "💰"
    },
    {
      title: "🎰 Jackpot System",
      description: "Participate in our fair and transparent jackpot system. Win big with every round!",
      icon: "🎯"
    },
    {
      title: "🚀 Launchpad Access",
      description: "Get early access to new token launches in the Farion ecosystem. Be among the first investors!",
      icon: "🌟"
    },
    {
      title: "💬 Community Chat",
      description: "Connect with fellow holders in real-time. Share strategies, discuss market trends, and grow together.",
      icon: "🤝"
    },
    {
      title: "🏆 NFT Boosts",
      description: "Purchase unique NFT boosts to enhance your earning potential and unlock exclusive features.",
      icon: "✨"
    }
  ];

  const nextFeature = () => {
    setCurrentFeature((prev) => (prev + 1) % features.length);
  };

  const prevFeature = () => {
    setCurrentFeature((prev) => (prev - 1 + features.length) % features.length);
  };

  return (
    <section className="py-16 bg-gradient-to-b from-secondary/20 to-background dark:from-background dark:to-card/20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-foreground mb-4">Platform Features</h2>
          <p className="text-xl text-muted-foreground">Discover what makes Farion special</p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentFeature}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <Card className="p-8 text-center bg-card/80 backdrop-blur-sm shadow-xl">
                  <div className="text-6xl mb-6">{features[currentFeature].icon}</div>
                  <h3 className="text-2xl font-bold text-foreground mb-4">
                    {features[currentFeature].title}
                  </h3>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    {features[currentFeature].description}
                  </p>
                </Card>
              </motion.div>
            </AnimatePresence>

            <div className="flex justify-between items-center mt-8">
              <Button
                onClick={prevFeature}
                variant="outline"
                size="lg"
                className="rounded-full p-3 hover:scale-110 transition-transform"
              >
                <ChevronLeft className="w-6 h-6" />
              </Button>

              <div className="flex gap-2">
                {features.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentFeature(index)}
                    className={`w-3 h-3 rounded-full transition-all ${
                      index === currentFeature ? 'bg-primary scale-125' : 'bg-muted-foreground/30'
                    }`}
                  />
                ))}
              </div>

              <Button
                onClick={nextFeature}
                variant="outline"
                size="lg"
                className="rounded-full p-3 hover:scale-110 transition-transform"
              >
                <ChevronRight className="w-6 h-6" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GameFeatures;
