import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { 
  Twitter, 
  Users, 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  ExternalLink 
} from 'lucide-react';

interface Task {
  id: string;
  title: string;
  description: string;
  task_type: string;
  requirements: any;
  min_reward: number;
  max_reward: number;
}

interface Submission {
  id: string;
  task_id: string;
  status: string;
  submission_data: any;
  admin_notes?: string;
  submitted_at: string;
}

const ReferralTasks = () => {
  const { walletAddress, username } = useMultiWallet();
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [submissionData, setSubmissionData] = useState<Record<string, any>>({});

  useEffect(() => {
    fetchTasks();
    if (walletAddress) {
      fetchSubmissions();
    }
  }, [walletAddress]);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('referral_tasks')
        .select('*')
        .eq('is_active', true)
        .order('created_at');

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubmissions = async () => {
    if (!walletAddress) return;

    try {
      const { data, error } = await supabase
        .from('user_task_submissions')
        .select('*')
        .eq('wallet_address', walletAddress);

      if (error) throw error;
      setSubmissions(data || []);
    } catch (error) {
      console.error('Error fetching submissions:', error);
    }
  };

  const handleSubmit = async (taskId: string, taskType: string) => {
    if (!walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to submit tasks.",
        variant: "destructive",
      });
      return;
    }

    const data = submissionData[taskId] || {};
    
    // Validate submission data based on task type
    if (taskType === 'twitter_follow' && !data.twitter_username) {
      toast({
        title: "Missing Information",
        description: "Please enter your Twitter username.",
        variant: "destructive",
      });
      return;
    }

    if (taskType === 'twitter_posts' && (!data.post_urls || data.post_urls.length < 3)) {
      toast({
        title: "Missing Information",
        description: "Please provide at least 3 post URLs.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('user_task_submissions')
        .insert({
          user_id: walletAddress, // Using wallet address as user_id
          wallet_address: walletAddress,
          username: username,
          task_id: taskId,
          submission_data: data,
        });

      if (error) throw error;

      toast({
        title: "Task Submitted!",
        description: "Your task has been submitted for review. You'll be notified once it's verified.",
      });

      fetchSubmissions();
      setSubmissionData(prev => ({ ...prev, [taskId]: {} }));
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit task. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getTaskIcon = (taskType: string) => {
    switch (taskType) {
      case 'twitter_follow':
        return <Twitter className="h-5 w-5" />;
      case 'community_join':
        return <Users className="h-5 w-5" />;
      case 'twitter_posts':
        return <MessageSquare className="h-5 w-5" />;
      default:
        return <AlertCircle className="h-5 w-5" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-orange-500" />;
    }
  };

  const getTaskSubmission = (taskId: string) => {
    return submissions.find(sub => sub.task_id === taskId);
  };

  const renderTaskForm = (task: Task) => {
    const submission = getTaskSubmission(task.id);
    if (submission) return null;

    const data = submissionData[task.id] || {};

    switch (task.task_type) {
      case 'twitter_follow':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`username-${task.id}`}>Your Twitter Username</Label>
              <Input
                id={`username-${task.id}`}
                placeholder="@yourusername"
                value={data.twitter_username || ''}
                onChange={(e) => setSubmissionData(prev => ({
                  ...prev,
                  [task.id]: { ...data, twitter_username: e.target.value }
                }))}
              />
            </div>
            <Button 
              onClick={() => window.open(task.requirements.twitter_url, '_blank')}
              variant="outline"
              className="w-full"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Follow @farion
            </Button>
          </div>
        );

      case 'community_join':
        return (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">
                Join the community and wait 24 hours before submitting.
              </p>
              <Button 
                onClick={() => window.open(task.requirements.community_url, '_blank')}
                variant="outline"
                className="w-full"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Join Community
              </Button>
            </div>
            <div>
              <Label htmlFor={`username-${task.id}`}>Your Twitter Username</Label>
              <Input
                id={`username-${task.id}`}
                placeholder="@yourusername"
                value={data.twitter_username || ''}
                onChange={(e) => setSubmissionData(prev => ({
                  ...prev,
                  [task.id]: { ...data, twitter_username: e.target.value }
                }))}
              />
            </div>
          </div>
        );

      case 'twitter_posts':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`posts-${task.id}`}>Post URLs (one per line, minimum 3)</Label>
              <Textarea
                id={`posts-${task.id}`}
                placeholder="https://x.com/yourusername/status/123&#10;https://x.com/yourusername/status/456&#10;https://x.com/yourusername/status/789"
                value={data.post_urls?.join('\n') || ''}
                onChange={(e) => {
                  const urls = e.target.value.split('\n').filter(url => url.trim());
                  setSubmissionData(prev => ({
                    ...prev,
                    [task.id]: { ...data, post_urls: urls }
                  }));
                }}
                rows={5}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Each post must include #FARION, $FARION, or tag @farion
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-3/4"></div>
              <div className="h-4 bg-muted rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Available Tasks</h2>
        <p className="text-muted-foreground">
          Complete these social media tasks to earn $FARION rewards
        </p>
      </div>

      <div className="grid gap-6">
        {tasks.map((task) => {
          const submission = getTaskSubmission(task.id);
          
          return (
            <Card key={task.id} className="relative overflow-hidden">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getTaskIcon(task.task_type)}
                    <div>
                      <CardTitle className="text-lg">{task.title}</CardTitle>
                      <CardDescription className="mt-1">
                        {task.description}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="mb-2">
                      {task.min_reward}-{task.max_reward} $FARION
                    </Badge>
                    {submission && (
                      <div className="flex items-center gap-2">
                        {getStatusIcon(submission.status)}
                        <span className="text-sm capitalize">{submission.status}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                {submission ? (
                  <div className="space-y-3">
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm font-medium mb-2">Submission Status:</p>
                      <div className="flex items-center gap-2 mb-2">
                        {getStatusIcon(submission.status)}
                        <span className="capitalize font-medium">{submission.status}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Submitted: {new Date(submission.submitted_at).toLocaleDateString()}
                      </p>
                      {submission.admin_notes && (
                        <div className="mt-3 p-3 bg-background rounded border">
                          <p className="text-sm font-medium mb-1">Admin Notes:</p>
                          <p className="text-sm text-muted-foreground">{submission.admin_notes}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {renderTaskForm(task)}
                    <Button 
                      onClick={() => handleSubmit(task.id, task.task_type)}
                      className="w-full"
                      disabled={!walletAddress}
                    >
                      Submit Task
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default ReferralTasks;