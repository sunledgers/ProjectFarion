import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { DollarSign, BarChart3, Coins, RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface TokenData {
  price: number;
  priceChange24h: number;
  volume24h: number;
  marketCap: number;
  liquidity: number;
}

const TokenStats: React.FC = () => {
  const [data, setData] = useState<TokenData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTokenData = useCallback(async () => {
    try {
      const { data: tokenData, error: fetchError } = await supabase.functions.invoke('get-token-data');
      
      if (fetchError) throw fetchError;
      
      setData(tokenData);
      setError(null);
    } catch (err) {
      console.error('Error fetching token data:', err);
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTokenData();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchTokenData, 30000);
    return () => clearInterval(interval);
  }, [fetchTokenData]);

  const formatNumber = (num: number, decimals = 2) => {
    if (num >= 1000000) {
      return `$${(num / 1000000).toFixed(decimals)}M`;
    }
    if (num >= 1000) {
      return `$${(num / 1000).toFixed(decimals)}K`;
    }
    return `$${num.toFixed(decimals)}`;
  };

  const formatPrice = (price: number) => {
    if (price < 0.00001) {
      return `$${price.toExponential(2)}`;
    }
    if (price < 0.01) {
      return `$${price.toFixed(6)}`;
    }
    return `$${price.toFixed(4)}`;
  };

  if (loading) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex items-center justify-center gap-2 text-emerald-200 dark:text-muted-foreground"
      >
        <RefreshCw className="h-4 w-4 animate-spin" />
        <span className="text-sm">Loading stats...</span>
      </motion.div>
    );
  }

  if (error || !data) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-sm text-emerald-200/60 dark:text-muted-foreground"
      >
        Unable to load token stats
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.7, duration: 0.6 }}
      className="grid grid-cols-2 gap-3 md:gap-4 max-w-md mx-auto mt-6 px-4"
    >
      {/* Market Cap */}
      <div className="bg-white/10 dark:bg-card/50 backdrop-blur-sm rounded-lg p-3 md:p-4 border border-white/20 dark:border-border">
        <div className="flex items-center gap-2 text-emerald-200/80 dark:text-muted-foreground text-xs mb-1">
          <Coins className="h-3 w-3" />
          Market Cap
        </div>
        <div className="text-white dark:text-foreground font-bold text-sm md:text-base">
          {formatNumber(data.marketCap)}
        </div>
      </div>

      {/* 24h Volume */}
      <div className="bg-white/10 dark:bg-card/50 backdrop-blur-sm rounded-lg p-3 md:p-4 border border-white/20 dark:border-border">
        <div className="flex items-center gap-2 text-emerald-200/80 dark:text-muted-foreground text-xs mb-1">
          <BarChart3 className="h-3 w-3" />
          24h Volume
        </div>
        <div className="text-white dark:text-foreground font-bold text-sm md:text-base">
          {formatNumber(data.volume24h)}
        </div>
      </div>
    </motion.div>
  );
};

export default TokenStats;
