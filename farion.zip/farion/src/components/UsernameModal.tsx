import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useUserProfile } from '@/hooks/useUserProfile';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { User, Check, X, Loader2 } from 'lucide-react';

interface UsernameModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const UsernameModal: React.FC<UsernameModalProps> = ({ open, onOpenChange }) => {
  const { walletAddress, username } = useMultiWallet();
  const { profile, checkUsernameAvailability, setCustomUsername, refreshProfile } = useUserProfile(walletAddress);
  const { toast } = useToast();
  
  const [newUsername, setNewUsername] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Reset state when modal opens
  useEffect(() => {
    if (open) {
      setNewUsername('');
      setIsAvailable(null);
    }
  }, [open]);

  // Debounced username availability check
  useEffect(() => {
    if (!newUsername || newUsername.length < 3) {
      setIsAvailable(null);
      return;
    }

    const timer = setTimeout(async () => {
      setIsChecking(true);
      try {
        const available = await checkUsernameAvailability(newUsername);
        setIsAvailable(available);
      } catch (error) {
        console.error('Error checking username:', error);
        setIsAvailable(null);
      } finally {
        setIsChecking(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [newUsername, checkUsernameAvailability]);

  const handleSubmit = async () => {
    if (!newUsername || !isAvailable) return;

    setIsSaving(true);
    try {
      const result = await setCustomUsername(newUsername);
      
      if (result.success) {
        toast({
          title: "Username Set",
          description: `Your username is now "${newUsername}"`,
        });
        await refreshProfile();
        onOpenChange(false);
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to set username",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to set username",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSkip = () => {
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Choose Your Username
          </DialogTitle>
          <DialogDescription>
            Create a unique username that will be displayed across the Farion platform.
            {profile?.custom_username && (
              <span className="block mt-2 text-primary">
                Current username: {profile.custom_username}
              </span>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <div className="relative">
              <Input
                id="username"
                placeholder="Enter your username"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                className="pr-10"
                maxLength={20}
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                {isChecking && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                {!isChecking && isAvailable === true && <Check className="h-4 w-4 text-green-500" />}
                {!isChecking && isAvailable === false && <X className="h-4 w-4 text-red-500" />}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              3-20 characters. Only lowercase letters, numbers, and underscores.
            </p>
            {isAvailable === false && newUsername.length >= 3 && (
              <p className="text-xs text-red-500">This username is already taken</p>
            )}
            {isAvailable === true && (
              <p className="text-xs text-green-500">Username is available!</p>
            )}
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleSkip}
              className="flex-1"
            >
              Skip for Now
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!isAvailable || isSaving || newUsername.length < 3}
              className="flex-1"
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                'Set Username'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UsernameModal;