import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Coins, TrendingUp, Star, Sparkles, Zap, Clock, Shield } from 'lucide-react';

interface NFTItem {
  id: string;
  name: string;
  description: string;
  boost_type: string;
  boost_value: number;
  price_sol: number;
  rarity: string;
  is_available: boolean;
  purchased_by_wallet?: string;
  purchased_at?: string;
}

interface NFTCardProps {
  nft: NFTItem;
  index: number;
  onPurchase: (nftId: string) => void;
  isConnected: boolean;
  isPurchasing?: boolean;
}

const NFTCard: React.FC<NFTCardProps> = ({ nft, index, onPurchase, isConnected, isPurchasing = false }) => {
  const getBoostIcon = (boostType: string) => {
    const iconProps = { className: "h-5 w-5" };
    switch (boostType) {
      case 'coin_multiplier': return <Coins {...iconProps} />;
      case 'staking_apy': return <TrendingUp {...iconProps} />;
      case 'jackpot_luck': return <Star {...iconProps} />;
      case 'xp_multiplier': return <Star {...iconProps} />;
      case 'rare_drop': return <Sparkles {...iconProps} />;
      case 'energy_regen': return <Zap {...iconProps} />;
      case 'building_speed': return <Clock {...iconProps} />;
      case 'resource_gathering': return <Shield {...iconProps} />;
      case 'pvp_advantage': return <Shield {...iconProps} />;
      case 'exclusive_access': return <Star {...iconProps} />;
      case 'cosmetic': return <Sparkles {...iconProps} />;
      default: return <Star {...iconProps} />;
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-500';
      case 'rare': return 'bg-blue-500';
      case 'epic': return 'bg-purple-500';
      case 'legendary': return 'bg-amber-500';
      default: return 'bg-gray-500';
    }
  };

  const getRarityBorder = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-500/50';
      case 'rare': return 'border-blue-500/50';
      case 'epic': return 'border-purple-500/50';
      case 'legendary': return 'border-amber-500/50';
      default: return 'border-gray-500/50';
    }
  };

  const formatBoostValue = (boostType: string, boostValue: number) => {
    switch (boostType) {
      case 'coin_multiplier':
      case 'xp_multiplier':
        return `${boostValue}x`;
      case 'staking_apy':
      case 'jackpot_luck':
      case 'rare_drop':
      case 'energy_regen':
      case 'building_speed':
      case 'resource_gathering':
      case 'pvp_advantage':
        return `+${boostValue}%`;
      case 'exclusive_access':
      case 'cosmetic':
        return 'Unlocked';
      default:
        return `${boostValue}`;
    }
  };

  const getBoostTypeLabel = (boostType: string) => {
    switch (boostType) {
      case 'coin_multiplier': return 'Coin Boost';
      case 'staking_apy': return 'Staking APY';
      case 'jackpot_luck': return 'Jackpot Luck';
      case 'xp_multiplier': return 'XP Boost';
      case 'rare_drop': return 'Rare Drops';
      case 'energy_regen': return 'Energy Regen';
      case 'building_speed': return 'Building Speed';
      case 'resource_gathering': return 'Resource Gathering';
      case 'pvp_advantage': return 'PvP Advantage';
      case 'exclusive_access': return 'Exclusive Access';
      case 'cosmetic': return 'Cosmetic';
      default: return 'Boost';
    }
  };

  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      transition={{ delay: index * 0.05, duration: 0.6 }}
      whileHover={{ y: -5, scale: 1.02 }}
      className="group"
    >
      <Card className={`overflow-hidden hover:shadow-2xl transition-all duration-300 bg-card/80 backdrop-blur-sm border-2 ${getRarityBorder(nft.rarity)}`}>
        {/* Header with rarity and boost type */}
        <div className="p-4 border-b border-border/50">
          <div className="flex justify-between items-center mb-2">
            <Badge className={`${getRarityColor(nft.rarity)} text-white capitalize`}>
              {nft.rarity}
            </Badge>
            <div className="flex items-center gap-1 text-muted-foreground">
              {getBoostIcon(nft.boost_type)}
              <span className="text-xs">{getBoostTypeLabel(nft.boost_type)}</span>
            </div>
          </div>
          
          <h3 className="text-lg font-bold text-foreground mb-1">{nft.name}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2">{nft.description}</p>
        </div>

        {/* Boost details */}
        <div className="p-4 border-b border-border/50">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">Boost Effect:</span>
            <span className="text-lg font-bold text-primary">
              {formatBoostValue(nft.boost_type, nft.boost_value)}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Duration:</span>
            <Badge variant="outline" className="text-xs bg-green-500/20 text-green-400 border-green-500/30">
              Permanent
            </Badge>
          </div>
        </div>

        {/* Price and purchase */}
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-muted-foreground">Price:</span>
            <span className="text-xl font-bold text-foreground">
              {nft.price_sol} SOL
            </span>
          </div>
          
          <Button
            onClick={() => onPurchase(nft.id)}
            disabled={!isConnected || isPurchasing}
            className="w-full"
            size="sm"
          >
            {isPurchasing ? 'Processing...' : !isConnected ? 'Connect Wallet' : 'Buy Now'}
          </Button>
          
          {!isConnected && (
            <p className="text-xs text-muted-foreground text-center mt-2">
              Connect your wallet to purchase
            </p>
          )}
        </div>
      </Card>
    </motion.div>
  );
};

export default NFTCard;