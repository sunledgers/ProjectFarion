import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wallet } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

interface WalletConnectionPromptProps {
  title?: string;
  description?: string;
}

const WalletConnectionPrompt: React.FC<WalletConnectionPromptProps> = ({
  title = "Connect Your Wallet",
  description = "Connect your wallet to access all features"
}) => {
  const { connected, connecting, availableWallets, connectWallet } = useMultiWallet();

  if (connected) return null;

  return (
    <Card className="p-6 text-center max-w-md mx-auto">
      <Wallet className="h-12 w-12 text-primary mx-auto mb-4" />
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground mb-6">{description}</p>
      
      <div className="space-y-3">
        {availableWallets.map((wallet) => (
          <Button
            key={wallet.name}
            onClick={() => connectWallet(wallet)}
            disabled={connecting || !wallet.installed}
            className="w-full justify-start"
            variant={wallet.installed ? "default" : "outline"}
          >
            <span className="text-lg mr-3">{wallet.icon}</span>
            <span className="flex-1 text-left">
              {wallet.installed ? `Connect ${wallet.name}` : `Install ${wallet.name}`}
            </span>
            {connecting && (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white ml-2"></div>
            )}
          </Button>
        ))}
      </div>
      
      <p className="text-xs text-muted-foreground mt-4">
        Your wallet address will be used to generate a unique username
      </p>
    </Card>
  );
};

export default WalletConnectionPrompt;