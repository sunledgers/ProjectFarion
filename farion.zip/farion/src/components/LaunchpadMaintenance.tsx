import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Construction, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const LaunchpadMaintenance = () => {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full"
      >
        <Card className="text-center border-orange-500/20 bg-gradient-to-br from-orange-500/5 to-amber-500/5">
          <CardContent className="p-8 space-y-6">
            <motion.div
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <Construction className="h-16 w-16 text-orange-500 mx-auto" />
            </motion.div>
            
            <div className="space-y-3">
              <Badge variant="secondary" className="bg-orange-500/20 text-orange-700 border-orange-500/30">
                Under Construction
              </Badge>
              <h1 className="text-2xl font-bold text-foreground">
                Launchpad Coming Soon!
              </h1>
              <p className="text-muted-foreground">
                We're building something amazing. The token launchpad will be available soon with enhanced features and security.
              </p>
            </div>
            
            <div className="text-4xl font-bold text-orange-500">
              Building...
            </div>
            
            <Link to="/">
              <Button variant="outline" className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default LaunchpadMaintenance;