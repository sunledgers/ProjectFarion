import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Coins, TrendingUp, Star, Sparkles, Zap, Clock, Shield, Play, Pause } from 'lucide-react';

interface NFTItem {
  id: string;
  name: string;
  description: string;
  boost_type: string;
  boost_value: number;
  price_sol: number;
  rarity: string;
  is_available: boolean;
  purchased_by_wallet?: string;
  purchased_at?: string;
}

interface UserNFT {
  id: string;
  nft_id: string;
  nft: NFTItem;
  is_active: boolean;
  activated_at: string | null;
}

interface NFTOwnershipProps {
  userNFTs: UserNFT[];
  onActivateBoost: (purchaseId: string) => void;
  isConnected: boolean;
}

const NFTOwnership: React.FC<NFTOwnershipProps> = ({ userNFTs, onActivateBoost, isConnected }) => {
  const getBoostIcon = (boostType: string) => {
    const iconProps = { className: "h-5 w-5" };
    switch (boostType) {
      case 'coin_multiplier': return <Coins {...iconProps} />;
      case 'staking_apy': return <TrendingUp {...iconProps} />;
      case 'jackpot_luck': return <Star {...iconProps} />;
      case 'xp_multiplier': return <Star {...iconProps} />;
      case 'rare_drop': return <Sparkles {...iconProps} />;
      case 'energy_regen': return <Zap {...iconProps} />;
      case 'building_speed': return <Clock {...iconProps} />;
      case 'resource_gathering': return <Shield {...iconProps} />;
      case 'pvp_advantage': return <Shield {...iconProps} />;
      case 'exclusive_access': return <Star {...iconProps} />;
      case 'cosmetic': return <Sparkles {...iconProps} />;
      default: return <Star {...iconProps} />;
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-500';
      case 'rare': return 'bg-blue-500';
      case 'epic': return 'bg-purple-500';
      case 'legendary': return 'bg-amber-500';
      default: return 'bg-gray-500';
    }
  };

  const getRarityBorder = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-500/50';
      case 'rare': return 'border-blue-500/50';
      case 'epic': return 'border-purple-500/50';
      case 'legendary': return 'border-amber-500/50';
      default: return 'border-gray-500/50';
    }
  };

  const formatBoostValue = (boostType: string, boostValue: number) => {
    switch (boostType) {
      case 'coin_multiplier':
      case 'xp_multiplier':
        return `${boostValue}x`;
      case 'staking_apy':
      case 'jackpot_luck':
      case 'rare_drop':
      case 'energy_regen':
      case 'building_speed':
      case 'resource_gathering':
      case 'pvp_advantage':
        return `+${boostValue}%`;
      case 'exclusive_access':
      case 'cosmetic':
        return 'Unlocked';
      default:
        return `${boostValue}`;
    }
  };

  const getBoostTypeLabel = (boostType: string) => {
    switch (boostType) {
      case 'coin_multiplier': return 'Coin Boost';
      case 'staking_apy': return 'Staking APY';
      case 'jackpot_luck': return 'Jackpot Luck';
      case 'xp_multiplier': return 'XP Boost';
      case 'rare_drop': return 'Rare Drops';
      case 'energy_regen': return 'Energy Regen';
      case 'building_speed': return 'Building Speed';
      case 'resource_gathering': return 'Resource Gathering';
      case 'pvp_advantage': return 'PvP Advantage';
      case 'exclusive_access': return 'Exclusive Access';
      case 'cosmetic': return 'Cosmetic';
      default: return 'Boost';
    }
  };

  const formatTimeRemaining = () => {
    return 'Permanent';
  };

  if (!isConnected) {
    return (
      <div className="text-center py-12">
        <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">Connect Your Wallet</h3>
        <p className="text-muted-foreground">
          Connect your wallet to view your NFT collection and manage your boosts.
        </p>
      </div>
    );
  }

  if (userNFTs.length === 0) {
    return (
      <div className="text-center py-12">
        <Sparkles className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">No NFTs Owned</h3>
        <p className="text-muted-foreground">
          You don't own any NFT boosts yet. Visit the marketplace to purchase your first boost!
        </p>
      </div>
    );
  }

  const activeBoosts = userNFTs.filter(nft => nft.is_active);
  const inactiveBoosts = userNFTs.filter(nft => !nft.is_active);

  return (
    <div className="space-y-8">
      {/* Active Boosts */}
      {activeBoosts.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
            <Zap className="h-6 w-6 text-green-500" />
            Active Boosts ({activeBoosts.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {activeBoosts.map((userNFT, index) => (
              <motion.div
                key={userNFT.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.05, duration: 0.6 }}
                className="group"
              >
                <Card className={`overflow-hidden border-2 bg-card/80 backdrop-blur-sm ${getRarityBorder(userNFT.nft.rarity)} ring-2 ring-green-500/50`}>
                  {/* Header */}
                  <div className="p-4 border-b border-border/50">
                    <div className="flex justify-between items-center mb-2">
                      <Badge className={`${getRarityColor(userNFT.nft.rarity)} text-white capitalize`}>
                        {userNFT.nft.rarity}
                      </Badge>
                      <Badge className="bg-green-500 text-white">
                        Active
                      </Badge>
                    </div>
                    
                    <h3 className="text-lg font-bold text-foreground mb-1">{userNFT.nft.name}</h3>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      {getBoostIcon(userNFT.nft.boost_type)}
                      <span className="text-xs">{getBoostTypeLabel(userNFT.nft.boost_type)}</span>
                    </div>
                  </div>

                  {/* Boost details */}
                  <div className="p-4 border-b border-border/50">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground">Boost Effect:</span>
                      <span className="text-lg font-bold text-green-500">
                        {formatBoostValue(userNFT.nft.boost_type, userNFT.nft.boost_value)}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Duration:</span>
                      <Badge variant="outline" className="text-xs bg-green-500/20 text-green-400 border-green-500/30">
                        Permanent
                      </Badge>
                    </div>
                  </div>

                  {/* Status */}
                  <div className="p-4">
                    <div className="flex items-center gap-2 text-green-500">
                      <Play className="h-4 w-4" />
                      <span className="text-sm font-medium">Boost Active</span>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Inactive Boosts */}
      {inactiveBoosts.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
            <Pause className="h-6 w-6 text-muted-foreground" />
            Inactive Boosts ({inactiveBoosts.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {inactiveBoosts.map((userNFT, index) => (
              <motion.div
                key={userNFT.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.05, duration: 0.6 }}
                className="group"
              >
                <Card className={`overflow-hidden border-2 bg-card/80 backdrop-blur-sm ${getRarityBorder(userNFT.nft.rarity)}`}>
                  {/* Header */}
                  <div className="p-4 border-b border-border/50">
                    <div className="flex justify-between items-center mb-2">
                      <Badge className={`${getRarityColor(userNFT.nft.rarity)} text-white capitalize`}>
                        {userNFT.nft.rarity}
                      </Badge>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        {getBoostIcon(userNFT.nft.boost_type)}
                        <span className="text-xs">{getBoostTypeLabel(userNFT.nft.boost_type)}</span>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-bold text-foreground mb-1">{userNFT.nft.name}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">{userNFT.nft.description}</p>
                  </div>

                  {/* Boost details */}
                  <div className="p-4 border-b border-border/50">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground">Boost Effect:</span>
                      <span className="text-lg font-bold text-primary">
                        {formatBoostValue(userNFT.nft.boost_type, userNFT.nft.boost_value)}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Duration:</span>
                      <Badge variant="outline" className="text-xs bg-green-500/20 text-green-400 border-green-500/30">
                        Permanent
                      </Badge>
                    </div>
                  </div>

                  {/* Activation */}
                  <div className="p-4">
                    <Button
                      onClick={() => onActivateBoost(userNFT.id)}
                      className="w-full"
                      size="sm"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Activate Boost
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default NFTOwnership;