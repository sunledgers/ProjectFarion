import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

const PlatformLinks = () => {
  return (
    <section className="py-16 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5"></div>
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Track $FARION</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Contract address and tracking links will be available once the token launches
          </p>
        </motion.div>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-md mx-auto"
        >
          <Card className="p-8 text-center bg-card/80 backdrop-blur-sm">
            <div className="text-4xl mb-4">🚀</div>
            <h3 className="text-xl font-bold text-foreground mb-2">Coming Soon</h3>
            <p className="text-muted-foreground">
              Token tracking platforms will be linked here after launch. Stay tuned!
            </p>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default PlatformLinks;
