import React from 'react';
import { motion } from 'framer-motion';
import { Coins, RefreshCw, AlertCircle } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { Button } from '@/components/ui/button';

const TokenBalanceDisplay = () => {
  const { tokenBalance, balanceLoading, balanceError, refreshBalance } = useMultiWallet();

  if (!tokenBalance && !balanceLoading) {
    return null;
  }

  const formatBalance = (balance: number) => {
    if (balance >= 1000000) {
      return `${(balance / 1000000).toFixed(2)}M`;
    }
    if (balance >= 1000) {
      return `${(balance / 1000).toFixed(2)}K`;
    }
    return balance.toFixed(2);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'text-green-500';
      case 'no_tokens': return 'text-muted-foreground';
      case 'error': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-1 md:gap-2 bg-primary/10 rounded-lg px-2 md:px-3 py-1 md:py-2 border border-primary/20"
    >
      <Coins className="h-3 w-3 md:h-4 md:w-4 text-primary" />
      
      {balanceLoading ? (
        <div className="flex items-center gap-2">
          <RefreshCw className="h-3 w-3 animate-spin" />
          <span className="text-xs md:text-sm text-muted-foreground hidden md:inline">Loading...</span>
        </div>
      ) : balanceError ? (
        <div className="flex items-center gap-2">
          <AlertCircle className="h-3 w-3 text-destructive" />
          <span className="text-xs md:text-sm text-destructive hidden md:inline">Error</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshBalance}
            className="h-5 md:h-6 px-1 md:px-2"
          >
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>
      ) : tokenBalance ? (
        <div className="flex items-center gap-2">
          <span className={`text-xs md:text-sm font-medium ${getStatusColor(tokenBalance.verificationStatus)}`}>
            {formatBalance(tokenBalance.tokenBalance)} AUK
          </span>
          <span className="text-xs text-muted-foreground hidden md:inline">
            ({tokenBalance.supplyPercentage.toFixed(4)}%)
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshBalance}
            className="h-5 md:h-6 px-1 md:px-2"
          >
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>
      ) : null}
    </motion.div>
  );
};

export default TokenBalanceDisplay;