import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { usePowerball } from '@/hooks/usePowerball';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Trophy, Clock, Users, DollarSign, Sparkles, Target, Timer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const PowerballInterface = () => {
  const { 
    currentRound, 
    participants, 
    recentWinners, 
    loading, 
    timeRemaining,
    isUserQualified,
    verifyQualification,
    getVolumeProgress,
    formatTimeRemaining 
  } = usePowerball();
  
  const { walletAddress, username } = useMultiWallet();
  const { toast } = useToast();

  const handleVerifyQualification = async () => {
    if (!walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to participate",
        variant: "destructive"
      });
      return;
    }

    const result = await verifyQualification(walletAddress, username);
    
    if (result.success) {
      toast({
        title: result.isQualified ? "Qualified!" : "Not Qualified",
        description: result.isQualified 
          ? `You're qualified with ${result.tokenBalance} FARION tokens!`
          : "You need to hold FARION tokens to participate",
        variant: result.isQualified ? "default" : "destructive"
      });
    } else {
      toast({
        title: "Verification Failed",
        description: result.error || "Failed to verify qualification",
        variant: "destructive"
      });
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(2)}K`;
    return num.toFixed(2);
  };

  const volumeProgress = getVolumeProgress();
  const isRoundActive = currentRound?.status === 'waiting' && timeRemaining > 0;

  if (loading) {
    return (
      <div className="w-full max-w-6xl mx-auto p-6 space-y-6">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center space-y-4"
        >
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            FARION Powerball
          </h1>
          <p className="text-lg text-muted-foreground">Loading...</p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-6 bg-muted rounded"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded mb-4"></div>
                <div className="h-4 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Error fallback when no round is available
  if (!currentRound) {
    return (
      <div className="w-full max-w-6xl mx-auto p-6 space-y-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            FARION Powerball
          </h1>
          <p className="text-lg text-muted-foreground">
            Volume-based lottery • Every 6 hours • FARION holders only
          </p>
        </motion.div>

        <Card className="text-center p-8">
          <CardContent>
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="space-y-4"
            >
              <Clock className="h-16 w-16 mx-auto text-muted-foreground/50" />
              <h3 className="text-xl font-semibold">No Active Round</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                There's currently no active Powerball round. New rounds start automatically based on trading volume.
              </p>
              <Button onClick={() => window.location.reload()} variant="outline">
                Refresh Page
              </Button>
            </motion.div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="h-8 w-8 text-primary" />
          </motion.div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            FARION Powerball
          </h1>
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="h-8 w-8 text-primary" />
          </motion.div>
        </div>
        <p className="text-lg text-muted-foreground">
          Volume-based lottery • Every 6 hours • FARION holders only
        </p>
      </motion.div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="relative overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Trophy className="h-4 w-4 text-yellow-500" />
                Prize Pool
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-500">
                ${formatNumber(currentRound?.prize_pool || 0)}
              </div>
              <div className="text-xs text-muted-foreground">
                80% of volume
              </div>
            </CardContent>
            <motion.div 
              className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-transparent opacity-0"
              animate={{ opacity: [0, 0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="relative overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Timer className="h-4 w-4 text-blue-500" />
                Time Left
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-500 font-mono">
                {formatTimeRemaining()}
              </div>
              <div className="text-xs text-muted-foreground">
                Round #{currentRound?.round_number || 0}
              </div>
            </CardContent>
            <motion.div 
              className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-transparent opacity-0"
              animate={{ opacity: [0, 0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
            />
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="relative overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="h-4 w-4 text-green-500" />
                Participants
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">
                {currentRound?.participant_count || 0}
              </div>
              <div className="text-xs text-muted-foreground">
                Qualified holders
              </div>
            </CardContent>
            <motion.div 
              className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-transparent opacity-0"
              animate={{ opacity: [0, 0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: 1 }}
            />
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="relative overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="h-4 w-4 text-purple-500" />
                Volume Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-500">
                {volumeProgress.toFixed(1)}%
              </div>
              <div className="text-xs text-muted-foreground">
                ${formatNumber(currentRound?.current_volume || 0)} / ${formatNumber(currentRound?.volume_threshold || 0)}
              </div>
            </CardContent>
            <motion.div 
              className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-transparent opacity-0"
              animate={{ opacity: [0, 0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: 1.5 }}
            />
          </Card>
        </motion.div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Volume Progress & Participation */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Volume Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Current Volume</span>
                  <span className="font-medium">${formatNumber(currentRound?.current_volume || 0)}</span>
                </div>
                <Progress value={volumeProgress} className="h-3" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Target: ${formatNumber(currentRound?.volume_threshold || 0)}</span>
                  <span>{volumeProgress.toFixed(1)}% Complete</span>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Participation Status</h3>
                  <Badge variant={isUserQualified ? "default" : "secondary"}>
                    {isUserQualified ? "Qualified" : "Not Qualified"}
                  </Badge>
                </div>

                <AnimatePresence>
                  {walletAddress ? (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-3"
                    >
                      <Button 
                        onClick={handleVerifyQualification}
                        className="w-full"
                        disabled={!isRoundActive}
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        {isUserQualified ? "Refresh Qualification" : "Check Qualification"}
                      </Button>
                      
                      {!isRoundActive && (
                        <p className="text-sm text-muted-foreground text-center">
                          Round is not active or has ended
                        </p>
                      )}
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-center p-4 border border-dashed rounded-lg"
                    >
                      <p className="text-sm text-muted-foreground mb-2">
                        Connect your wallet to participate
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Must hold FARION tokens to qualify
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </CardContent>
          </Card>

          {/* Recent Participants */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Recent Participants
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                <AnimatePresence>
                  {participants.slice(0, 10).map((participant, index) => (
                    <motion.div
                      key={participant.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center justify-between p-2 rounded-lg bg-muted/50"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500"></div>
                        <span className="font-medium text-sm">{participant.username}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {formatNumber(participant.token_balance)} FARION
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {participants.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No participants yet</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Winners */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              Recent Winners
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              <AnimatePresence>
                {recentWinners.map((winner, index) => (
                  <motion.div
                    key={winner.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    className="p-3 rounded-lg bg-gradient-to-r from-yellow-500/10 to-transparent border border-yellow-500/20"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Trophy className="h-4 w-4 text-yellow-500" />
                      <span className="font-medium text-sm">{winner.username}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Won ${formatNumber(winner.prize_amount)}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(winner.created_at).toLocaleDateString()}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {recentWinners.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No winners yet</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PowerballInterface;