import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Wallet, Check, X, Loader2 } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useUserProfile } from '@/hooks/useUserProfile';
import { useToast } from '@/hooks/use-toast';

interface WalletConnectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const WalletConnectionModal: React.FC<WalletConnectionModalProps> = ({ open, onOpenChange }) => {
  const { connected, connecting, availableWallets, connectWallet, walletAddress } = useMultiWallet();
  const { profile, loading: profileLoading, checkUsernameAvailability, setCustomUsername, refreshProfile } = useUserProfile(walletAddress);
  const { toast } = useToast();
  
  const [showUsernameForm, setShowUsernameForm] = useState(false);
  const [username, setUsername] = useState('');
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [settingUsername, setSettingUsername] = useState(false);

  useEffect(() => {
    console.log('Checking username form visibility:', { 
      connected, 
      profileLoading, 
      walletAddress, 
      profile: profile?.custom_username 
    });
    
    if (connected && walletAddress && !profileLoading) {
      if (!profile?.custom_username) {
        console.log('Showing username form - no custom username found');
        setShowUsernameForm(true);
      } else {
        console.log('User already has custom username:', profile.custom_username);
        onOpenChange(false);
      }
    }
  }, [connected, walletAddress, profileLoading, profile?.custom_username, onOpenChange]);

  const handleWalletConnect = async (wallet: any) => {
    console.log('Attempting wallet connection for:', wallet.name);
    try {
      await connectWallet(wallet);
      console.log('Wallet connection successful');
    } catch (error) {
      console.error('Connection failed:', error);
      toast({
        title: "Connection failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    }
  };

  const checkUsername = async (value: string) => {
    if (value.length < 3) {
      setUsernameAvailable(null);
      return;
    }

    setCheckingUsername(true);
    const available = await checkUsernameAvailability(value);
    setUsernameAvailable(available);
    setCheckingUsername(false);
  };

  const handleUsernameSubmit = async () => {
    if (!username || !usernameAvailable) return;

    setSettingUsername(true);
    const result = await setCustomUsername(username);
    
    if (result.success) {
      await refreshProfile();
      setShowUsernameForm(false);
      onOpenChange(false);
      toast({
        title: "Username set successfully",
        description: `Your username is now ${username}`,
      });
    } else {
      setUsernameAvailable(null);
      toast({
        title: "Error",
        description: result.error || "Failed to set username",
        variant: "destructive",
      });
    }
    setSettingUsername(false);
  };

  const getUsernameIcon = () => {
    if (checkingUsername) return <Loader2 className="h-4 w-4 animate-spin" />;
    if (usernameAvailable === true) return <Check className="h-4 w-4 text-green-500" />;
    if (usernameAvailable === false) return <X className="h-4 w-4 text-red-500" />;
    return null;
  };

  const isIOS = () => {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
  };

  const getIOSVersion = () => {
    if (!isIOS()) return null;
    const match = navigator.userAgent.match(/OS (\d+)_/);
    return match ? parseInt(match[1], 10) : null;
  };

  const isIOS18Plus = () => {
    const version = getIOSVersion();
    return version && version >= 18;
  };

  const getInstallUrl = (walletName: string) => {
    const urls: Record<string, string> = {
      'Phantom': isIOS() ? 'https://apps.apple.com/app/phantom-solana-wallet/1598432977' : 'https://phantom.app/',
      'Backpack': isIOS() ? 'https://apps.apple.com/app/backpack-crypto-wallet/id1639175860' : 'https://backpack.app/',
      'Trust Wallet': isIOS() ? 'https://apps.apple.com/app/trust-crypto-bitcoin-wallet/id1288339409' : 'https://trustwallet.com/'
    };
    return urls[walletName];
  };

  const connectWalletIOS = async (wallet: any) => {
    if (!isIOS() || wallet.installed) {
      return handleWalletConnect(wallet);
    }

    const isIOS18 = isIOS18Plus();
    console.log(`iOS connection attempt for ${wallet.name}, iOS 18+: ${isIOS18}`);

    if (isIOS18) {
      toast({
        title: "iOS 18+ Connection",
        description: `For best results on iOS 18+, please install ${wallet.name} first if not already installed, then try connecting again.`,
        duration: 8000,
      });
    }

    const deepLinks: Record<string, string> = {
      'Phantom': `phantom://browse/${encodeURIComponent(window.location.href)}`,
      'Trust Wallet': `trust://browser_enable`,
      'Backpack': `backpack://`
    };

    const deepLink = deepLinks[wallet.name];
    if (deepLink) {
      try {
        window.location.href = deepLink;
      } catch (error) {
        console.log('Deep link failed, going straight to install');
      }
      
      const timeout = isIOS18 ? 3000 : 1500;
      
      setTimeout(() => {
        const installUrl = getInstallUrl(wallet.name);
        if (installUrl) {
          window.open(installUrl, '_blank');
          
          if (isIOS18) {
            toast({
              title: "Manual Setup Required",
              description: `After installing ${wallet.name}, please return to this page and try connecting again. iOS 18+ requires manual wallet app opening.`,
              duration: 10000,
            });
          }
        }
      }, timeout);
    }
  };

  if (connected && showUsernameForm) {
    return (
      <Dialog open={open} onOpenChange={(newOpen) => {
        if (!newOpen) {
          setShowUsernameForm(false);
          setUsername('');
          setUsernameAvailable(null);
        }
        onOpenChange(newOpen);
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Choose Your Username</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 p-4">
            <p className="text-sm text-muted-foreground text-center">
              Set a custom username for your account. This can only be set once!
            </p>
            
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <Input
                  id="username"
                  placeholder="Enter username"
                  value={username}
                  onChange={(e) => {
                    const value = e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
                    setUsername(value);
                    checkUsername(value);
                  }}
                  maxLength={20}
                  className="pr-10"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  {getUsernameIcon()}
                </div>
              </div>
              {username.length > 0 && username.length < 3 && (
                <p className="text-xs text-yellow-600">Username must be at least 3 characters</p>
              )}
              {usernameAvailable === false && (
                <p className="text-xs text-red-500">Username not available</p>
              )}
              {usernameAvailable === true && (
                <p className="text-xs text-green-500">Username available!</p>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowUsernameForm(false);
                  onOpenChange(false);
                }}
                className="flex-1"
              >
                Skip for now
              </Button>
              <Button
                onClick={handleUsernameSubmit}
                disabled={!username || !usernameAvailable || settingUsername}
                className="flex-1"
              >
                {settingUsername ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Set Username
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center flex items-center justify-center gap-2">
            <Wallet className="h-5 w-5" />
            Connect Your Wallet
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 p-4">
          <p className="text-sm text-muted-foreground text-center">
            Connect your wallet to access all Farion features
          </p>
          
          <div className="space-y-3">
            {availableWallets.map((wallet) => (
              <div key={wallet.name} className="relative">
                <Button
                  onClick={() => connectWalletIOS(wallet)}
                  disabled={connecting}
                  className="w-full justify-start h-14 text-left"
                  variant={wallet.installed ? "default" : "outline"}
                >
                  <span className="text-2xl mr-3">{wallet.icon}</span>
                  <div className="flex-1">
                    <div className="font-medium">{wallet.name}</div>
                    <div className="text-xs opacity-70">
                      {wallet.installed ? 'Ready to connect' : 'Install required'}
                    </div>
                  </div>
                  {connecting && (
                    <Loader2 className="h-4 w-4 animate-spin ml-2" />
                  )}
                </Button>
                
                {!wallet.installed && (
                  <div className="absolute inset-0 bg-background/80 backdrop-blur-sm rounded-lg flex items-center justify-center">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const installUrl = getInstallUrl(wallet.name);
                        if (installUrl) window.open(installUrl, '_blank');
                      }}
                    >
                      Install {wallet.name}
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          <div className="text-xs text-muted-foreground text-center mt-4 space-y-1">
            <p>By connecting, you agree to our Terms of Service</p>
            <p>Your wallet address will be used securely</p>
            {isIOS() && isIOS18Plus() && (
              <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3 mt-3">
                <p className="text-xs text-yellow-800 dark:text-yellow-200 font-medium">
                  iOS 18+ users: If automatic connection fails, manually open your wallet app, then return to this page and try again.
                </p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WalletConnectionModal;
