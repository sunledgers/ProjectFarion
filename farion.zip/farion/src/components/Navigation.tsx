import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, MessageCircle, Plus, Globe, ImageIcon, Users, Lock, Trophy, Gift } from 'lucide-react';
import { motion } from 'framer-motion';
import TokenBalanceDisplay from '@/components/TokenBalanceDisplay';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

const Navigation = () => {
  const location = useLocation();
  const { connected } = useMultiWallet();
  
  return (
    <motion.nav 
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="fixed top-2 sm:top-4 left-2 sm:left-4 z-[100] bg-card/80 backdrop-blur-md border border-border rounded-full px-2 sm:px-4 py-2 sm:py-3 shadow-lg max-w-[calc(100vw-1rem)] overflow-x-auto scrollbar-hide"
    >
      <div className="flex items-center gap-1 sm:gap-2 whitespace-nowrap">
        <Link to="/">
          <Button
            variant={location.pathname === "/" ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Home className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Home</span>
          </Button>
        </Link>
        <Link to="/chat">
          <Button
            variant={location.pathname === "/chat" ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <MessageCircle className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Chat</span>
          </Button>
        </Link>
        <Link to="/launchpad">
          <Button
            variant={location.pathname.startsWith("/launchpad") ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Plus className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Launchpad</span>
          </Button>
        </Link>
        
        <Link to="/memes">
          <Button
            variant={location.pathname === "/memes" ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <ImageIcon className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Memes</span>
          </Button>
        </Link>
        <Link to="/staking">
          <Button
            variant={location.pathname === "/staking" ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Lock className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Staking</span>
          </Button>
        </Link>
        <Link to="/jackpot">
          <Button
            variant={location.pathname === "/jackpot" ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Trophy className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Jackpot</span>
          </Button>
        </Link>
        <Link to="/powerball">
          <Button
            variant={location.pathname === "/powerball" ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Gift className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Powerball</span>
          </Button>
        </Link>
        <Link to="/forum">
          <Button
            variant={location.pathname.startsWith("/forum") ? "default" : "ghost"}
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Users className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">ACHAN</span>
          </Button>
        </Link>
        <a href="https://play.farion.io" target="_blank" rel="noopener noreferrer">
          <Button
            variant="ghost"
            size="sm"
            className="rounded-full text-xs sm:text-sm px-2 sm:px-3"
          >
            <Globe className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
            <span className="hidden sm:inline">Virtual World</span>
          </Button>
        </a>
      </div>
      
      {/* Token Balance Display */}
      {connected && (
        <div className="ml-2 sm:ml-4">
          <TokenBalanceDisplay />
        </div>
      )}
    </motion.nav>
  );
};

export default Navigation;