import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Lock, Clock, TrendingUp, Coins } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';

interface StakingPool {
  id: string;
  lockPeriod: number;
  apy: number;
  minStake: number;
  totalStaked: number;
  myStaked: number;
  pendingRewards: number;
  timeRemaining?: number;
}

const stakingPools: StakingPool[] = [
  {
    id: '30d',
    lockPeriod: 30,
    apy: 12,
    minStake: 100,
    totalStaked: 2500000,
    myStaked: 0,
    pendingRewards: 0,
  },
  {
    id: '60d',
    lockPeriod: 60,
    apy: 18,
    minStake: 500,
    totalStaked: 5200000,
    myStaked: 0,
    pendingRewards: 0,
  },
  {
    id: '90d',
    lockPeriod: 90,
    apy: 25,
    minStake: 1000,
    totalStaked: 8900000,
    myStaked: 0,
    pendingRewards: 0,
  },
  {
    id: '120d',
    lockPeriod: 120,
    apy: 35,
    minStake: 2000,
    totalStaked: 12300000,
    myStaked: 0,
    pendingRewards: 0,
  },
];

const StakingPreview = () => {
  const { connected, tokenBalance } = useMultiWallet();
  const { toast } = useToast();
  const [stakeAmounts, setStakeAmounts] = useState<{ [key: string]: string }>({});
  const [selectedPool, setSelectedPool] = useState<string | null>(null);

  const calculateRewards = (amount: number, apy: number, days: number) => {
    const dailyRate = apy / 365 / 100;
    return amount * dailyRate * days;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toFixed(2);
  };

  const handleStake = (poolId: string) => {
    if (!connected) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to stake tokens.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Coming Soon!",
      description: "Staking functionality is currently in development. Stay tuned!",
    });
  };

  const totalStakedValue = stakingPools.reduce((acc, pool) => acc + pool.totalStaked, 0);
  const availableBalance = typeof tokenBalance === 'number' ? tokenBalance : 0;

  return (
    <section className="py-16 bg-gradient-to-br from-background via-primary/5 to-secondary/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              $AUK Staking Pools
            </h2>
            <p className="text-muted-foreground text-lg mb-6 max-w-2xl mx-auto">
              Lock your $AUK tokens to earn rewards. Longer lock periods offer higher APY rates.
            </p>
            <div className="flex justify-center items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-primary" />
                <span>Total Staked: {formatNumber(totalStakedValue)} $AUK</span>
              </div>
              {connected && (
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  <span>Available: {formatNumber(availableBalance)} $AUK</span>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stakingPools.map((pool, index) => (
            <motion.div
              key={pool.id}
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
            >
              <Card className="h-full hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/50 bg-card/50 backdrop-blur-sm">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <Lock className="w-5 h-5 text-primary" />
                      {pool.lockPeriod} Days
                    </CardTitle>
                    <Badge variant="secondary" className="text-lg font-bold">
                      {pool.apy}% APY
                    </Badge>
                  </div>
                  <CardDescription>
                    Minimum stake: {formatNumber(pool.minStake)} $AUK
                  </CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Total Staked:</span>
                      <span className="font-medium">{formatNumber(pool.totalStaked)} $AUK</span>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Pool Capacity:</span>
                      <span className="font-medium">
                        {Math.round((pool.totalStaked / (pool.totalStaked * 1.5)) * 100)}%
                      </span>
                    </div>
                    
                    <Progress 
                      value={(pool.totalStaked / (pool.totalStaked * 1.5)) * 100} 
                      className="h-2"
                    />
                  </div>

                  <div className="space-y-3 pt-2 border-t border-border">
                    <Input
                      type="number"
                      placeholder={`Min: ${pool.minStake} $AUK`}
                      value={stakeAmounts[pool.id] || ''}
                      onChange={(e) => setStakeAmounts(prev => ({
                        ...prev,
                        [pool.id]: e.target.value
                      }))}
                      className="text-center"
                    />
                    
                    {stakeAmounts[pool.id] && (
                      <div className="text-xs text-center space-y-1 bg-secondary/20 rounded-lg p-2">
                        <div className="flex justify-between">
                          <span>Estimated rewards:</span>
                          <span className="font-medium text-green-600">
                            +{formatNumber(calculateRewards(
                              parseFloat(stakeAmounts[pool.id]) || 0, 
                              pool.apy, 
                              pool.lockPeriod
                            ))} $AUK
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Daily yield:</span>
                          <span className="font-medium">
                            +{formatNumber(calculateRewards(
                              parseFloat(stakeAmounts[pool.id]) || 0, 
                              pool.apy, 
                              1
                            ))} $AUK
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  <Button 
                    onClick={() => handleStake(pool.id)}
                    className="w-full"
                    disabled={!connected || !stakeAmounts[pool.id] || parseFloat(stakeAmounts[pool.id]) < pool.minStake}
                  >
                    <Clock className="w-4 h-4 mr-2" />
                    {connected ? 'Stake Now' : 'Connect Wallet'}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mt-12 text-center"
        >
          <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4 max-w-2xl mx-auto">
            <p className="text-amber-800 dark:text-amber-200 text-sm">
              ⚠️ <strong>Preview Mode:</strong> This staking interface is currently in development. 
              No actual staking will occur until the feature is fully implemented.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default StakingPreview;