import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

const BlogNews = () => {
  const posts = [
    {
      title: "🎉 Farion has launched!",
      excerpt: "Welcome to the beginning of something big! Farion is here! Join our ecosystem with staking, jackpots, and community features.",
      date: "December 2025",
      image: "/farion-logo.png"
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-secondary/20 to-background dark:from-background dark:to-card/20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-foreground mb-4">📰 Latest News</h2>
          <p className="text-xl text-muted-foreground">Stay updated with the latest from Farion</p>
        </motion.div>

        <div className="grid justify-center max-w-2xl mx-auto">
          {posts.map((post, index) => (
            <motion.div
              key={index}
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ y: -5 }}
            >
              <Card className="p-6 h-full hover:shadow-xl transition-all cursor-pointer bg-card/80 backdrop-blur-sm">
                <div className="mb-4 text-center">
                  <img 
                    src={post.image} 
                    alt="Farion Logo"
                    className="w-20 h-20 mx-auto object-contain"
                  />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">{post.title}</h3>
                <p className="text-muted-foreground mb-4 line-clamp-3">{post.excerpt}</p>
                <div className="text-sm text-primary font-semibold">
                  {post.date}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogNews;
