import React from 'react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, ExternalLink } from 'lucide-react';

const WalletSelector = () => {
  const { availableWallets, connecting, connectWallet } = useMultiWallet();

  const getInstallUrl = (walletName: string) => {
    const urls = {
      'Phantom': 'https://phantom.app/',
      'Solflare': 'https://solflare.com/',
      'Backpack': 'https://www.backpack.app/',
      'Trust Wallet': 'https://trustwallet.com/'
    };
    return urls[walletName as keyof typeof urls];
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Connect Wallet</CardTitle>
          <CardDescription>
            Choose your preferred wallet to connect to Farion
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {availableWallets.map((wallet) => (
            <div key={wallet.name} className="relative">
              <Button
                variant={wallet.installed ? "outline" : "ghost"}
                className="w-full justify-between h-16 p-4"
                onClick={() => wallet.installed && connectWallet(wallet)}
                disabled={connecting || !wallet.installed}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{wallet.icon}</span>
                  <div className="text-left">
                    <div className="font-semibold">{wallet.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {wallet.installed ? 'Click to connect' : 'Not installed'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {wallet.installed ? (
                    <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                      Ready
                    </Badge>
                  ) : (
                    <Badge variant="outline">
                      Install
                    </Badge>
                  )}
                  {connecting && <Loader2 className="h-4 w-4 animate-spin" />}
                </div>
              </Button>
              
              {!wallet.installed && (
                <a
                  href={getInstallUrl(wallet.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute inset-0 z-10 flex items-center justify-center bg-background/80 backdrop-blur-sm rounded-lg opacity-0 hover:opacity-100 transition-opacity"
                >
                  <div className="flex items-center gap-2 text-sm font-medium text-primary">
                    Install {wallet.name}
                    <ExternalLink className="h-4 w-4" />
                  </div>
                </a>
              )}
            </div>
          ))}
          
          <div className="mt-6 text-center text-xs text-muted-foreground">
            <p>By connecting a wallet, you agree to our terms of service.</p>
            <p className="mt-1">Your wallet connection is secure and encrypted.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WalletSelector;