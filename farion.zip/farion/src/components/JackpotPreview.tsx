import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';
import { Trophy, Users, Timer, Coins, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Participant {
  id: string;
  wallet: string;
  amount: number;
  timestamp: Date;
}

const JackpotPreview = () => {
  const { walletAddress, tokenBalance } = useMultiWallet();
  const { toast } = useToast();
  
  // Mock state for preview
  const [participants, setParticipants] = useState<Participant[]>([
    { id: '1', wallet: 'ABC...XYZ', amount: 250, timestamp: new Date() },
    { id: '2', wallet: 'DEF...123', amount: 500, timestamp: new Date() },
    { id: '3', wallet: 'GHI...456', amount: 150, timestamp: new Date() },
  ]);
  
  const [betAmount, setBetAmount] = useState('100');
  const [countdown, setCountdown] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [showWinner, setShowWinner] = useState(false);
  
  const minParticipants = 10;
  const minBet = 100;
  const projectWallet = 'HuTQzoz9Zh4vM1MtcESj9PDs95hbPhoG2eJFh8fjNK96';
  
  const totalPot = participants.reduce((sum, p) => sum + p.amount, 0);
  const projectFee = totalPot * 0.1;
  const winnerPot = totalPot - projectFee;
  
  // Mock countdown effect
  useEffect(() => {
    if (participants.length >= minParticipants && !isActive) {
      setIsActive(true);
      setCountdown(120);
    }
    
    if (countdown > 0 && isActive) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (countdown === 0 && isActive) {
      setShowWinner(true);
      setTimeout(() => {
        setShowWinner(false);
        setIsActive(false);
        setParticipants([]);
      }, 5000);
    }
  }, [countdown, isActive, participants.length]);
  
  const handleJoinPot = () => {
    if (!walletAddress) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to join the jackpot.",
        variant: "destructive"
      });
      return;
    }
    
    const amount = parseFloat(betAmount);
    if (amount < minBet) {
      toast({
        title: "Minimum Bet Required",
        description: `Minimum bet is ${minBet} $FARION tokens.`,
        variant: "destructive"
      });
      return;
    }
    
    if (!tokenBalance || tokenBalance.tokenBalance < amount) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough $FARION tokens for this bet.",
        variant: "destructive"
      });
      return;
    }
    
    // Mock adding participant
    const newParticipant: Participant = {
      id: Date.now().toString(),
      wallet: `${walletAddress.slice(0, 3)}...${walletAddress.slice(-3)}`,
      amount,
      timestamp: new Date()
    };
    
    setParticipants([...participants, newParticipant]);
    setBetAmount('100');
    
    toast({
      title: "Joined Jackpot!",
      description: `Successfully joined with ${amount} $FARION tokens.`,
    });
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Main Jackpot Card */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-accent/5 border-primary/20">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Trophy className="h-6 w-6 text-primary" />
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              $FARION Jackpot
            </CardTitle>
          </div>
          <Badge variant="secondary" className="mx-auto">
            Preview Mode - Coming Soon
          </Badge>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Pot Amount */}
          <div className="text-center">
            <motion.div
              animate={{ scale: totalPot > 1000 ? [1, 1.05, 1] : 1 }}
              transition={{ duration: 0.5, repeat: totalPot > 1000 ? Infinity : 0, repeatDelay: 2 }}
            >
              <div className="text-4xl font-bold text-primary mb-2">
                {totalPot.toLocaleString()} $FARION
              </div>
            </motion.div>
            <div className="text-sm text-muted-foreground">
              Winner gets: {winnerPot.toLocaleString()} $FARION
              <br />
              Project fee (10%): {projectFee.toLocaleString()} $FARION
            </div>
          </div>
          
          {/* Status */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Users className="h-4 w-4 text-accent" />
                <span className="font-semibold">{participants.length}/{minParticipants}</span>
              </div>
              <div className="text-xs text-muted-foreground">Participants</div>
              <Progress 
                value={(participants.length / minParticipants) * 100} 
                className="mt-2 h-2"
              />
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Timer className="h-4 w-4 text-accent" />
                <span className="font-semibold">
                  {isActive ? formatTime(countdown) : 'Waiting'}
                </span>
              </div>
              <div className="text-xs text-muted-foreground">
                {isActive ? 'Time Left' : 'For Players'}
              </div>
            </div>
          </div>
          
          {/* Join Section */}
          {!showWinner && (
            <div className="space-y-4 p-4 bg-card/50 rounded-lg border">
              <div className="flex gap-2">
                <div className="flex-1">
                    <Input
                      type="number"
                      placeholder={`Min: ${minBet} $FARION`}
                      value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min={minBet}
                  />
                </div>
                <Button 
                  onClick={handleJoinPot}
                  disabled={!walletAddress || isActive}
                  className="bg-gradient-to-r from-primary to-accent hover:from-primary/80 hover:to-accent/80"
                >
                  <Coins className="h-4 w-4 mr-2" />
                  Join Pot
                </Button>
              </div>
              
              {walletAddress && tokenBalance && (
                <div className="text-xs text-muted-foreground text-center">
                  Your balance: {tokenBalance.tokenBalance.toLocaleString()} $FARION
                </div>
              )}
            </div>
          )}
          
          {/* Winner Animation */}
          <AnimatePresence>
            {showWinner && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-center p-6 bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg border border-primary/30"
              >
                <Trophy className="h-12 w-12 text-primary mx-auto mb-4" />
                <div className="text-xl font-bold text-primary mb-2">
                  🎉 Winner: {participants[Math.floor(Math.random() * participants.length)]?.wallet} 🎉
                </div>
                <div className="text-lg font-semibold">
                  Won {winnerPot.toLocaleString()} $FARION!
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
      
      {/* Recent Participants */}
      {participants.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Current Round Participants</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {participants.slice(-5).reverse().map((participant, index) => (
                <div key={participant.id} className="flex justify-between items-center p-2 bg-muted/50 rounded">
                  <span className="text-sm font-medium">{participant.wallet}</span>
                  <Badge variant="outline">
                    {participant.amount.toLocaleString()} $FARION
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="h-5 w-5" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>• Minimum bet: {minBet} $FARION tokens</p>
          <p>• Minimum {minParticipants} participants to start the round</p>
          <p>• 120-second countdown once minimum is reached</p>
          <p>• Winner is randomly selected when timer ends</p>
          <p>• 10% fee goes to project development</p>
          <p>• Winner takes 90% of the total pot</p>
          <div className="mt-4 p-2 bg-muted/50 rounded text-xs">
            <strong>Preview Notice:</strong> This is a preview feature. No real transactions are processed.
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default JackpotPreview;