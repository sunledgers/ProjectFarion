import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import TokenStats from './TokenStats';

const CONTRACT_ADDRESS = 'CMXuYtw7JUyoJdGVMvYfjp89GX5eA4o83477HJZypump';

const Hero = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(CONTRACT_ADDRESS);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Contract address copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please copy manually",
        variant: "destructive",
      });
    }
  };

  return <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-b from-emerald-900 via-emerald-800 to-emerald-900 dark:from-background dark:via-card dark:to-background overflow-hidden pt-20">
      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.div initial={{
        scale: 0,
        opacity: 0,
        rotateY: 180
      }} animate={{
        scale: 1,
        opacity: 1,
        rotateY: 0
      }} transition={{
        duration: 1.2,
        ease: "backOut"
      }} className="mb-8">
          <motion.img src="/farion-logo.png" alt="Farion Logo" className="w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 mx-auto mb-4 sm:mb-6" whileHover={{
          scale: 1.1,
          rotateY: 15,
          rotateX: 5,
          transition: {
            duration: 0.3
          }
        }} animate={{
          y: [0, -10, 0]
        }} transition={{
          y: {
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }
        }} />
        </motion.div>

        <motion.h1 initial={{
        y: 50,
        opacity: 0
      }} animate={{
        y: 0,
        opacity: 1
      }} transition={{
        delay: 0.3,
        duration: 0.8
      }} className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold text-white dark:text-foreground mb-4 sm:mb-6 font-rounded px-2" style={{
        fontFamily: '"Comic Neue", cursive'
      }}>
          <span className="text-emerald-300 dark:text-primary">FARION</span>
        </motion.h1>

        <motion.p initial={{
        y: 30,
        opacity: 0
      }} animate={{
        y: 0,
        opacity: 1
      }} transition={{
        delay: 0.5,
        duration: 0.8
      }} className="text-base sm:text-lg md:text-xl lg:text-2xl text-emerald-100 dark:text-muted-foreground mb-4 max-w-2xl mx-auto px-4">
          Staking, Jackpot, P2P and community features on Solana
        </motion.p>

        {/* Contract Address with Copy Button */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="mb-6 sm:mb-8"
        >
          <button
            onClick={handleCopyAddress}
            className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2 sm:py-3 bg-black/30 dark:bg-card/50 backdrop-blur-sm border border-emerald-400/30 dark:border-primary/30 rounded-xl hover:bg-black/40 dark:hover:bg-card/70 transition-all group cursor-pointer"
          >
            <span className="text-xs sm:text-sm font-mono text-emerald-200 dark:text-muted-foreground truncate max-w-[200px] sm:max-w-none">
              {CONTRACT_ADDRESS}
            </span>
            <div className="flex-shrink-0 p-1.5 sm:p-2 rounded-lg bg-emerald-500/20 dark:bg-primary/20 group-hover:bg-emerald-500/30 dark:group-hover:bg-primary/30 transition-colors">
              {copied ? (
                <Check className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400 dark:text-primary" />
              ) : (
                <Copy className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-300 dark:text-primary" />
              )}
            </div>
          </button>
          <p className="text-xs text-emerald-200/60 dark:text-muted-foreground/60 mt-2">
            Tap to copy contract address
          </p>
        </motion.div>

        <TokenStats />
      </div>
    </section>;
};
export default Hero;