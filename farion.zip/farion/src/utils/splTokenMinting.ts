import { 
  Connection, 
  PublicKey, 
  Keypair, 
  Transaction, 
  SystemProgram,
  LAMPORTS_PER_SOL
} from '@solana/web3.js';
import {
  createInitializeMintInstruction,
  createAssociatedTokenAccountInstruction,
  createMintToInstruction,
  getAssociatedTokenAddress,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  getMinimumBalanceForRentExemptMint,
} from '@solana/spl-token';
import { HELIUS_RPC_URL, DEFAULT_TOKEN_DECIMALS, DEFAULT_TOTAL_SUPPLY } from '@/config/meteora';

export interface TokenMintResult {
  success: boolean;
  mintAddress?: string;
  mintKeypair?: Keypair;
  txSignature?: string;
  error?: string;
}

export interface TokenTransferResult {
  success: boolean;
  txSignature?: string;
  error?: string;
}

/**
 * Creates a real SPL token mint on Solana
 */
export async function createSPLTokenMint(
  connection: Connection,
  payer: PublicKey,
  signTransaction: (tx: Transaction) => Promise<Transaction>,
  sendTransaction: (tx: Transaction, connection: Connection) => Promise<string>,
  decimals: number = DEFAULT_TOKEN_DECIMALS
): Promise<TokenMintResult> {
  try {
    // Generate a new keypair for the mint
    const mintKeypair = Keypair.generate();
    const mintAddress = mintKeypair.publicKey;

    // Get minimum lamports for rent exemption
    const lamports = await getMinimumBalanceForRentExemptMint(connection);

    // Create the mint account
    const transaction = new Transaction().add(
      // Create account for the mint
      SystemProgram.createAccount({
        fromPubkey: payer,
        newAccountPubkey: mintAddress,
        space: MINT_SIZE,
        lamports,
        programId: TOKEN_PROGRAM_ID,
      }),
      // Initialize the mint
      createInitializeMintInstruction(
        mintAddress,
        decimals,
        payer, // mint authority
        payer, // freeze authority (optional, can be null)
        TOKEN_PROGRAM_ID
      )
    );

    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = payer;
    
    // The mint keypair must sign to create the account
    transaction.partialSign(mintKeypair);

    // Send transaction
    const txSignature = await sendTransaction(transaction, connection);
    await connection.confirmTransaction(txSignature, 'confirmed');

    return {
      success: true,
      mintAddress: mintAddress.toBase58(),
      mintKeypair,
      txSignature,
    };
  } catch (error: any) {
    console.error('Error creating SPL token mint:', error);
    return {
      success: false,
      error: error.message || 'Failed to create token mint',
    };
  }
}

/**
 * Mints tokens to a specified wallet
 */
export async function mintTokensToWallet(
  connection: Connection,
  payer: PublicKey,
  mintAddress: PublicKey,
  recipientWallet: PublicKey,
  amount: number,
  decimals: number,
  sendTransaction: (tx: Transaction, connection: Connection) => Promise<string>
): Promise<TokenTransferResult> {
  try {
    // Get or create associated token account for recipient
    const recipientATA = await getAssociatedTokenAddress(
      mintAddress,
      recipientWallet,
      false,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const transaction = new Transaction();

    // Check if ATA exists, if not create it
    const ataInfo = await connection.getAccountInfo(recipientATA);
    if (!ataInfo) {
      transaction.add(
        createAssociatedTokenAccountInstruction(
          payer,
          recipientATA,
          recipientWallet,
          mintAddress,
          TOKEN_PROGRAM_ID,
          ASSOCIATED_TOKEN_PROGRAM_ID
        )
      );
    }

    // Mint tokens to the ATA
    const adjustedAmount = amount * Math.pow(10, decimals);
    transaction.add(
      createMintToInstruction(
        mintAddress,
        recipientATA,
        payer, // mint authority
        BigInt(Math.floor(adjustedAmount)),
        [],
        TOKEN_PROGRAM_ID
      )
    );

    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = payer;

    const txSignature = await sendTransaction(transaction, connection);
    await connection.confirmTransaction(txSignature, 'confirmed');

    return {
      success: true,
      txSignature,
    };
  } catch (error: any) {
    console.error('Error minting tokens:', error);
    return {
      success: false,
      error: error.message || 'Failed to mint tokens',
    };
  }
}

/**
 * Gets the token balance for a wallet
 */
export async function getTokenBalance(
  connection: Connection,
  mintAddress: PublicKey,
  walletAddress: PublicKey
): Promise<number> {
  try {
    const ata = await getAssociatedTokenAddress(
      mintAddress,
      walletAddress,
      false,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const balance = await connection.getTokenAccountBalance(ata);
    return Number(balance.value.uiAmount || 0);
  } catch (error) {
    // Account doesn't exist or other error
    return 0;
  }
}

/**
 * Transfers tokens between wallets
 */
export async function transferTokens(
  connection: Connection,
  payer: PublicKey,
  mintAddress: PublicKey,
  fromWallet: PublicKey,
  toWallet: PublicKey,
  amount: number,
  decimals: number,
  sendTransaction: (tx: Transaction, connection: Connection) => Promise<string>
): Promise<TokenTransferResult> {
  try {
    const { createTransferInstruction } = await import('@solana/spl-token');
    
    const fromATA = await getAssociatedTokenAddress(mintAddress, fromWallet);
    const toATA = await getAssociatedTokenAddress(mintAddress, toWallet);

    const transaction = new Transaction();

    // Create recipient ATA if needed
    const toAtaInfo = await connection.getAccountInfo(toATA);
    if (!toAtaInfo) {
      transaction.add(
        createAssociatedTokenAccountInstruction(
          payer,
          toATA,
          toWallet,
          mintAddress
        )
      );
    }

    const adjustedAmount = amount * Math.pow(10, decimals);
    transaction.add(
      createTransferInstruction(
        fromATA,
        toATA,
        fromWallet,
        BigInt(Math.floor(adjustedAmount))
      )
    );

    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = payer;

    const txSignature = await sendTransaction(transaction, connection);
    await connection.confirmTransaction(txSignature, 'confirmed');

    return {
      success: true,
      txSignature,
    };
  } catch (error: any) {
    console.error('Error transferring tokens:', error);
    return {
      success: false,
      error: error.message || 'Failed to transfer tokens',
    };
  }
}
