import { Keypair } from '@solana/web3.js';

export interface VanityGenerationResult {
  keypair: Keypair;
  attempts: number;
  timeMs: number;
}

export interface VanityProgress {
  attempts: number;
  rate: number; // attempts per second
  elapsed: number; // ms elapsed
}

/**
 * Generate a keypair where the public key ends with a specific suffix (case-insensitive)
 * Uses a timeout to prevent infinite loops
 */
export async function generateVanityAddress(
  suffix: string = 'far',
  timeoutMs: number = 60000,
  onProgress?: (progress: VanityProgress) => void
): Promise<VanityGenerationResult> {
  const startTime = Date.now();
  const lowerSuffix = suffix.toLowerCase();
  let attempts = 0;
  let lastProgressUpdate = startTime;
  const progressInterval = 500; // Update progress every 500ms
  
  return new Promise((resolve) => {
    const generate = () => {
      const batchSize = 1000; // Generate in batches to allow UI updates
      const batchStart = Date.now();
      
      for (let i = 0; i < batchSize; i++) {
        attempts++;
        const keypair = Keypair.generate();
        const address = keypair.publicKey.toBase58();
        
        if (address.toLowerCase().endsWith(lowerSuffix)) {
          const timeMs = Date.now() - startTime;
          console.log(`Found vanity address in ${attempts} attempts (${timeMs}ms): ${address}`);
          resolve({ keypair, attempts, timeMs });
          return;
        }
      }
      
      const elapsed = Date.now() - startTime;
      
      // Update progress callback
      if (onProgress && Date.now() - lastProgressUpdate >= progressInterval) {
        const rate = attempts / (elapsed / 1000);
        onProgress({ attempts, rate, elapsed });
        lastProgressUpdate = Date.now();
      }
      
      // Check timeout
      if (elapsed >= timeoutMs) {
        // Timeout reached, return a random keypair as fallback
        console.warn(`Vanity address timeout after ${attempts} attempts. Using fallback.`);
        const fallbackKeypair = Keypair.generate();
        resolve({ keypair: fallbackKeypair, attempts, timeMs: elapsed });
        return;
      }
      
      // Continue in next event loop tick to prevent blocking
      setTimeout(generate, 0);
    };
    
    // Start generation
    generate();
  });
}

/**
 * Generate vanity address synchronously (blocking) - use for small batches only
 */
export function generateVanityAddressSync(
  suffix: string = 'far',
  maxAttempts: number = 100000
): VanityGenerationResult {
  const startTime = Date.now();
  const lowerSuffix = suffix.toLowerCase();
  
  for (let attempts = 1; attempts <= maxAttempts; attempts++) {
    const keypair = Keypair.generate();
    const address = keypair.publicKey.toBase58();
    
    if (address.toLowerCase().endsWith(lowerSuffix)) {
      const timeMs = Date.now() - startTime;
      return { keypair, attempts, timeMs };
    }
  }
  
  // Fallback after max attempts
  console.warn(`Max attempts (${maxAttempts}) reached. Using fallback address.`);
  return {
    keypair: Keypair.generate(),
    attempts: maxAttempts,
    timeMs: Date.now() - startTime
  };
}

/**
 * Estimate time to find vanity address based on suffix length
 * Base58 has ~58 characters, so probability is (1/58)^length for exact match
 * For case-insensitive, some characters map to same (e.g., no 0, O, I, l), ~34 chars
 */
export function estimateVanityTime(suffix: string): {
  expectedAttempts: number;
  estimatedTimeSeconds: number;
} {
  // Rough calculation for case-insensitive base58
  // Effective alphabet size is ~34 (some chars like 0, O, I, l are excluded)
  const alphabetSize = 34;
  const expectedAttempts = Math.pow(alphabetSize, suffix.length);
  
  // Assume ~50,000 keypairs/second on average hardware
  const attemptsPerSecond = 50000;
  const estimatedTimeSeconds = expectedAttempts / attemptsPerSecond;
  
  return { expectedAttempts, estimatedTimeSeconds };
}

/**
 * Check if an address ends with the expected suffix
 */
export function hasVanitySuffix(address: string, suffix: string = 'far'): boolean {
  return address.toLowerCase().endsWith(suffix.toLowerCase());
}
