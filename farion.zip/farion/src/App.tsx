import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/ThemeProvider";
import { MultiWalletProvider } from "@/contexts/MultiWalletContext";
import Index from "./pages/Index";
import Chat from "./pages/Chat";
import P2PLoan from "./pages/P2PLoan";
import TokenDashboard from "./pages/TokenDashboard";
import TokenTrading from "./pages/TokenTrading";
import AukFaucet from "./pages/AukFaucet";
import Memes from "./pages/Memes";
import MemeDetail from "./pages/MemeDetail";
import Forum from "./pages/Forum";
import CreateThread from "./pages/CreateThread";
import ThreadView from "./pages/ThreadView";
import Staking from "./pages/Staking";
import Jackpot from "./pages/Jackpot";
import Powerball from "./pages/Powerball";
import Referral from "./pages/Referral";
import NFTMarketplace from "./pages/NFTMarketplace";
import TransactionHistory from "./pages/TransactionHistory";
import AdminPanel from "./pages/AdminPanel";
import Install from "./pages/Install";
import Dashboard from "./pages/Dashboard";
import LaunchpadNew from "./pages/LaunchpadNew";
import TokenDetail from "./pages/TokenDetail";
import Portfolio from "./pages/Portfolio";
import NotFound from "./pages/NotFound";
import Whitepaper from "./pages/Whitepaper";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <MultiWalletProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/p2p-loan" element={<P2PLoan />} />
              <Route path="/launchpad" element={<LaunchpadNew />} />
              <Route path="/launchpad/token/:tokenId" element={<TokenDetail />} />
              <Route path="/launchpad/trade/:tokenId" element={<TokenTrading />} />
              <Route path="/launchpad/faucet" element={<AukFaucet />} />
              <Route path="/portfolio" element={<Portfolio />} />
              <Route path="/memes" element={<Memes />} />
              <Route path="/memes/:memeId" element={<MemeDetail />} />
              <Route path="/staking" element={<Staking />} />
              <Route path="/jackpot" element={<Jackpot />} />
              <Route path="/powerball" element={<Powerball />} />
              <Route path="/referral" element={<Referral />} />
              <Route path="/nft-marketplace" element={<NFTMarketplace />} />
              <Route path="/transactions" element={<TransactionHistory />} />
              <Route path="/admin" element={<AdminPanel />} />
              <Route path="/install" element={<Install />} />
              <Route path="/forum" element={<Forum />} />
              <Route path="/forum/:board" element={<Forum />} />
              <Route path="/forum/:board/new" element={<CreateThread />} />
              <Route path="/forum/:board/thread/:threadId" element={<ThreadView />} />
              <Route path="/whitepaper" element={<Whitepaper />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </MultiWalletProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
