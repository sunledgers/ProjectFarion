import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom';
import { BackpackWalletAdapter } from '@solana/wallet-adapter-backpack';
import { TrustWalletAdapter } from '@solana/wallet-adapter-trust';
import { SolflareWalletAdapter } from '@solana/wallet-adapter-solflare';
import { WalletAdapter } from '@solana/wallet-adapter-base';
import { useToast } from '@/hooks/use-toast';
import { TokenBalanceData, useTokenBalance } from '@/hooks/useTokenBalance';
import { useUserProfile } from '@/hooks/useUserProfile';
import { supabase } from '@/integrations/supabase/client';

export interface WalletInfo {
  name: string;
  icon: string;
  adapter: WalletAdapter;
  installed: boolean;
}

interface MultiWalletContextType {
  connected: boolean;
  connecting: boolean;
  walletAddress: string | null;
  username: string | null;
  selectedWallet: WalletInfo | null;
  availableWallets: WalletInfo[];
  tokenBalance: TokenBalanceData | null;
  balanceLoading: boolean;
  balanceError: string | null;
  connectWallet: (wallet: WalletInfo) => Promise<void>;
  disconnect: () => void;
  refreshBalance: () => Promise<void>;
}

const MultiWalletContext = createContext<MultiWalletContextType | undefined>(undefined);

export const useMultiWallet = () => {
  const context = useContext(MultiWalletContext);
  if (!context) {
    // Return safe default values during HMR or when provider isn't mounted yet
    return {
      connected: false,
      connecting: false,
      walletAddress: null,
      username: null,
      selectedWallet: null,
      availableWallets: [],
      tokenBalance: null,
      balanceLoading: false,
      balanceError: null,
      connectWallet: async () => {},
      disconnect: () => {},
      refreshBalance: async () => {}
    } as MultiWalletContextType;
  }
  return context;
};

interface MultiWalletProviderProps {
  children: ReactNode;
}

export const MultiWalletProvider: React.FC<MultiWalletProviderProps> = ({ children }) => {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  const [selectedWallet, setSelectedWallet] = useState<WalletInfo | null>(null);
  const { toast } = useToast();

  const { balanceData, loading: balanceLoading, error: balanceError, refreshBalance } = useTokenBalance(walletAddress);
  const { profile, refreshProfile } = useUserProfile(walletAddress);

  // Update username when profile changes (e.g., custom username is set)
  useEffect(() => {
    if (walletAddress && profile) {
      const displayUsername = profile.custom_username || generateUsername(walletAddress);
      console.log('Updating username from profile:', { 
        custom: profile.custom_username, 
        generated: generateUsername(walletAddress),
        display: displayUsername 
      });
      setUsername(displayUsername);
    }
  }, [profile?.custom_username, walletAddress]);

  // Initialize wallet adapters with Solflare added
  const availableWallets: WalletInfo[] = [
    {
      name: 'Phantom',
      icon: '👻',
      adapter: new PhantomWalletAdapter(),
      installed: typeof window !== 'undefined' && 'solana' in window && (window as any).solana?.isPhantom
    },
    {
      name: 'Solflare',
      icon: '🔥',
      adapter: new SolflareWalletAdapter(),
      installed: typeof window !== 'undefined' && 'solflare' in window
    },
    {
      name: 'Backpack',
      icon: '🎒',
      adapter: new BackpackWalletAdapter(),
      installed: typeof window !== 'undefined' && 'backpack' in window
    },
    {
      name: 'Trust Wallet',
      icon: '🛡️',
      adapter: new TrustWalletAdapter(),
      installed: typeof window !== 'undefined' && 'trustwallet' in window
    }
  ];

  // Auto-reconnect on load
  useEffect(() => {
    const autoConnect = async () => {
      const savedWalletName = localStorage.getItem('selected-wallet');
      const savedAddress = localStorage.getItem('wallet-address');
      
      if (savedWalletName && savedAddress) {
        const wallet = availableWallets.find(w => w.name === savedWalletName);
        if (wallet && wallet.installed) {
          try {
            await wallet.adapter.connect();
            
            if (wallet.adapter.publicKey && wallet.adapter.publicKey.toString() === savedAddress) {
              const address = wallet.adapter.publicKey.toString();
              
              setSelectedWallet(wallet);
              setWalletAddress(address);
              setConnected(true);
              // Username will be set by useEffect watching profile changes
              
              toast({
                title: "Wallet reconnected",
                description: `Reconnected to ${wallet.name}`,
              });
            } else {
              // Address mismatch, clear storage
              localStorage.removeItem('selected-wallet');
              localStorage.removeItem('wallet-address');
            }
          } catch (error) {
            console.log('Auto-connect failed:', error);
            localStorage.removeItem('selected-wallet');
            localStorage.removeItem('wallet-address');
          }
        }
      }
    };

    autoConnect();
  }, [toast]);

  const generateUsername = (address: string): string => {
    if (address.length < 8) return address;
    
    // Override for specific wallet address
    if (address === 'HuTQzoz9Zh4vM1MtcESj9PDs95hbPhoG2eJFh8fjNK96') {
      return 'lavatoshi';
    }
    
    const prefixes = ['Alpha', 'Beta', 'Gamma', 'Delta', 'Sigma', 'Omega', 'Nova', 'Stellar'];
    const suffixes = ['Trader', 'Hodler', 'Moon', 'Diamond', 'Rocket', 'Ape', 'Bull', 'Bear'];
    
    const addressSum = address.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    const prefix = prefixes[addressSum % prefixes.length];
    const suffix = suffixes[(addressSum * 7) % suffixes.length];
    const numbers = address.slice(-3);
    
    return `${prefix}${suffix}${numbers}`;
  };

  const isIOS = () => {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
  };

  const getIOSVersion = () => {
    if (!isIOS()) return null;
    const match = navigator.userAgent.match(/OS (\d+)_/);
    return match ? parseInt(match[1], 10) : null;
  };

  const isIOS18Plus = () => {
    const version = getIOSVersion();
    return version && version >= 18;
  };

  const connectWallet = async (wallet: WalletInfo) => {
    if (!wallet.installed) {
      // Enhanced iOS handling with version-specific logic
      if (isIOS()) {
        const deepLinks: Record<string, string> = {
          'Phantom': `phantom://browse/${encodeURIComponent(window.location.href)}`,
          'Trust Wallet': `trust://browser_enable`,
          'Backpack': `backpack://`
        };

        const deepLink = deepLinks[wallet.name];
        if (deepLink) {
          const isIOS18 = isIOS18Plus();
          const timeout = isIOS18 ? 8000 : 3000; // Longer timeout for iOS 18+
          
          console.log(`Attempting iOS connection for ${wallet.name}, iOS 18+: ${isIOS18}, timeout: ${timeout}ms`);
          
          // Enhanced connection detection for iOS 18+
          let connectionDetected = false;
          let checkingInterval: NodeJS.Timeout;
          
          const handleAppSwitch = () => {
            if (connectionDetected) return;
            connectionDetected = true;
            console.log('App switch detected, checking for wallet connection');
            
            // Start polling for connection with longer intervals for iOS 18
            checkingInterval = setInterval(() => {
              if (wallet.adapter.connected) {
                console.log('Wallet connection detected');
                clearInterval(checkingInterval);
                handleSuccessfulConnection(wallet);
              }
            }, isIOS18 ? 2000 : 1000);
            
            // Stop checking after extended time for iOS 18
            setTimeout(() => {
              if (checkingInterval) {
                clearInterval(checkingInterval);
                console.log('Connection check timeout reached');
              }
            }, isIOS18 ? 45000 : 30000);
          };

          // Multiple event listeners for better iOS 18 compatibility
          window.addEventListener('blur', handleAppSwitch, { once: true });
          window.addEventListener('pagehide', handleAppSwitch, { once: true });
          window.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') {
              handleAppSwitch();
            }
          }, { once: true });

          // For iOS 18+, show user instructions before deep linking
          if (isIOS18) {
            toast({
              title: `Opening ${wallet.name}`,
              description: "If the app doesn't open automatically, please open it manually and return to this page.",
              duration: 6000,
            });
          }

          try {
            window.location.href = deepLink;
          } catch (error) {
            console.log('Deep link failed, falling back to install URL');
          }
          
          // Progressive fallback with longer timeout for iOS 18
          setTimeout(() => {
            if (!connectionDetected) {
              const installUrls: Record<string, string> = {
                'Phantom': 'https://apps.apple.com/app/phantom-solana-wallet/id1598432977',
                'Backpack': 'https://apps.apple.com/app/backpack-crypto-wallet/id1639175860',
                'Trust Wallet': 'https://apps.apple.com/app/trust-crypto-bitcoin-wallet/id1288339409'
              };
              const installUrl = installUrls[wallet.name];
              if (installUrl) {
                if (isIOS18) {
                  toast({
                    title: "Manual connection required",
                    description: `Please install ${wallet.name} if not already installed, then try connecting again.`,
                    duration: 8000,
                  });
                }
                window.open(installUrl, '_blank');
              }
            }
          }, timeout);
          return;
        }
      }
      
      toast({
        title: "Wallet not installed",
        description: `Please install ${wallet.name} to connect`,
        variant: "destructive",
      });
      return;
    }

    setConnecting(true);
    try {
      // Enhanced connection with timeout
      const connectionPromise = wallet.adapter.connect();
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Connection timeout')), 15000)
      );

      await Promise.race([connectionPromise, timeoutPromise]);
      
      if (wallet.adapter.publicKey) {
        await handleSuccessfulConnection(wallet);
      }
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      
      let errorMessage = `Failed to connect to ${wallet.name}. Please try again.`;
      if (isIOS()) {
        if (isIOS18Plus()) {
          errorMessage += ' For iOS 18+, you may need to manually open the wallet app first, then return to this page and try connecting again.';
        } else {
          errorMessage += ' For iOS, make sure the wallet app is installed and try opening the wallet app first.';
        }
      }
      
      toast({
        title: "Connection failed",
        description: errorMessage,
        variant: "destructive",
        duration: 8000,
      });
    } finally {
      setConnecting(false);
    }
  };

  const createUserProfile = async (address: string, generatedUsername: string) => {
    console.log('Creating user profile for:', address);
    try {
      const { error } = await supabase
        .from('user_profiles')
        .insert({
          wallet_address: address,
          username: generatedUsername
        });

      if (error) {
        console.error('Error creating user profile:', error);
        // Profile might already exist, which is fine
        if (!error.message.includes('duplicate key')) {
          throw error;
        }
      } else {
        console.log('User profile created successfully');
      }
    } catch (error) {
      console.error('Failed to create user profile:', error);
    }
  };

  const handleSuccessfulConnection = async (wallet: WalletInfo) => {
    if (!wallet.adapter.publicKey) return;

    const address = wallet.adapter.publicKey.toString();
    const generatedUsername = generateUsername(address);
    
    console.log('Handling successful connection for:', address);
    
    // Create user profile if it doesn't exist
    await createUserProfile(address, generatedUsername);
    
    setSelectedWallet(wallet);
    setWalletAddress(address);
    setConnected(true);
    // Username will be set by useEffect watching profile changes
    
    // Save to localStorage
    localStorage.setItem('selected-wallet', wallet.name);
    localStorage.setItem('wallet-address', address);
    
    toast({
      title: "Wallet connected",
      description: `Connected to ${wallet.name}`,
    });
  };

  const disconnect = () => {
    if (selectedWallet) {
      selectedWallet.adapter.disconnect();
    }
    
    setConnected(false);
    setSelectedWallet(null);
    setWalletAddress(null);
    setUsername(null);
    
    localStorage.removeItem('selected-wallet');
    localStorage.removeItem('wallet-address');
    
    toast({
      title: "Wallet disconnected",
      description: "Successfully disconnected from wallet",
    });
  };

  return (
    <MultiWalletContext.Provider value={{
      connected,
      connecting,
      walletAddress,
      username,
      selectedWallet,
      availableWallets,
      tokenBalance: balanceData,
      balanceLoading,
      balanceError,
      connectWallet,
      disconnect,
      refreshBalance
    }}>
      {children}
    </MultiWalletContext.Provider>
  );
};