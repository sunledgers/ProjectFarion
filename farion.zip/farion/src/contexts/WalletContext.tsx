import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Connection, PublicKey } from '@solana/web3.js';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom';
import { useToast } from '@/components/ui/use-toast';
import { useTokenBalance } from '@/hooks/useTokenBalance';

interface TokenBalanceData {
  tokenBalance: number;
  supplyPercentage: number;
  verificationStatus: 'verified' | 'no_tokens' | 'pending' | 'error';
  lastUpdated: Date;
}

interface WalletContextType {
  connected: boolean;
  connecting: boolean;
  walletAddress: string | null;
  username: string | null;
  tokenBalance: TokenBalanceData | null;
  balanceLoading: boolean;
  balanceError: string | null;
  phantomAdapter: PhantomWalletAdapter | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  refreshBalance: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

interface WalletProviderProps {
  children: ReactNode;
}

export const WalletProvider: React.FC<WalletProviderProps> = ({ children }) => {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  const [phantom, setPhantom] = useState<PhantomWalletAdapter | null>(null);
  const { toast } = useToast();
  
  // Use token balance hook
  const { balanceData, loading: balanceLoading, error: balanceError, refreshBalance } = useTokenBalance(walletAddress);

  useEffect(() => {
    const adapter = new PhantomWalletAdapter();
    setPhantom(adapter);
    
    // Attempt to auto-reconnect if wallet was previously connected
    const autoConnect = async () => {
      const savedAddress = localStorage.getItem('wallet-address');
      if (savedAddress) {
        try {
          // Try to connect to Phantom wallet
          await adapter.connect();
          
          // Verify the connection and address match
          if (adapter.publicKey && adapter.publicKey.toString() === savedAddress) {
            const address = adapter.publicKey.toString();
            const generatedUsername = generateUsername(address);
            
            setWalletAddress(address);
            setUsername(generatedUsername);
            setConnected(true);
            
            toast({
              title: "Wallet reconnected",
              description: `Reconnected as ${generatedUsername}`,
            });
          } else {
            // Address mismatch or connection failed, clear storage
            localStorage.removeItem('wallet-address');
            setConnected(false);
            setWalletAddress(null);
            setUsername(null);
          }
        } catch (error) {
          // Auto-connect failed, clear storage and stay disconnected
          console.log('Auto-connect failed:', error);
          localStorage.removeItem('wallet-address');
          setConnected(false);
          setWalletAddress(null);
          setUsername(null);
        }
      }
    };

    autoConnect();
  }, [toast]);

  const generateUsername = (address: string): string => {
    if (address.length < 8) return address;
    return `User_${address.slice(0, 4)}...${address.slice(-4)}`;
  };

  const connect = async () => {
    if (!phantom) {
      toast({
        title: "Wallet not found",
        description: "Please install Phantom wallet",
        variant: "destructive",
      });
      return;
    }

    try {
      setConnecting(true);
      
      await phantom.connect();
      
      if (phantom.publicKey) {
        const address = phantom.publicKey.toString();
        const generatedUsername = generateUsername(address);
        
        setWalletAddress(address);
        setUsername(generatedUsername);
        setConnected(true);
        
        // Save to localStorage for persistence
        localStorage.setItem('wallet-address', address);
        
        toast({
          title: "Wallet connected",
          description: `Connected as ${generatedUsername}`,
        });
      }
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      toast({
        title: "Connection failed",
        description: "Failed to connect to Phantom wallet",
        variant: "destructive",
      });
    } finally {
      setConnecting(false);
    }
  };

  const disconnect = () => {
    if (phantom) {
      phantom.disconnect();
    }
    
    setConnected(false);
    setWalletAddress(null);
    setUsername(null);
    
    localStorage.removeItem('wallet-address');
    
    toast({
      title: "Wallet disconnected",
      description: "You have been disconnected from chat",
    });
  };

  return (
    <WalletContext.Provider
      value={{
        connected,
        connecting,
        walletAddress,
        username,
        tokenBalance: balanceData,
        balanceLoading,
        balanceError,
        phantomAdapter: phantom,
        connect,
        disconnect,
        refreshBalance,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};