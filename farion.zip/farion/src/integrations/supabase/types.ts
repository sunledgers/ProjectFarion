export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      auk_claims: {
        Row: {
          amount: number
          claim_amount: number | null
          claimed_at: string | null
          created_at: string
          id: string
          next_claim_available_at: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          amount: number
          claim_amount?: number | null
          claimed_at?: string | null
          created_at?: string
          id?: string
          next_claim_available_at?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          amount?: number
          claim_amount?: number | null
          claimed_at?: string | null
          created_at?: string
          id?: string
          next_claim_available_at?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          message: string
          room_id: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          room_id?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          room_id?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_rooms: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_private: boolean | null
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_private?: boolean | null
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_private?: boolean | null
          name?: string
        }
        Relationships: []
      }
      comment_reactions: {
        Row: {
          comment_id: string
          created_at: string
          id: string
          reaction_type: string
          wallet_address: string
        }
        Insert: {
          comment_id: string
          created_at?: string
          id?: string
          reaction_type: string
          wallet_address: string
        }
        Update: {
          comment_id?: string
          created_at?: string
          id?: string
          reaction_type?: string
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "comment_reactions_comment_id_fkey"
            columns: ["comment_id"]
            isOneToOne: false
            referencedRelation: "token_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      created_tokens: {
        Row: {
          contract_address: string
          created_at: string
          creator_address: string
          creator_username: string | null
          creator_wallet_address: string | null
          current_supply: number | null
          description: string | null
          holders_count: number | null
          id: string
          image_url: string | null
          is_active: boolean | null
          logo_url: string | null
          market_cap: number | null
          name: string
          symbol: string
          tax_percentage: number | null
          total_supply: number | null
          updated_at: string
        }
        Insert: {
          contract_address: string
          created_at?: string
          creator_address: string
          creator_username?: string | null
          creator_wallet_address?: string | null
          current_supply?: number | null
          description?: string | null
          holders_count?: number | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          logo_url?: string | null
          market_cap?: number | null
          name: string
          symbol: string
          tax_percentage?: number | null
          total_supply?: number | null
          updated_at?: string
        }
        Update: {
          contract_address?: string
          created_at?: string
          creator_address?: string
          creator_username?: string | null
          creator_wallet_address?: string | null
          current_supply?: number | null
          description?: string | null
          holders_count?: number | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          logo_url?: string | null
          market_cap?: number | null
          name?: string
          symbol?: string
          tax_percentage?: number | null
          total_supply?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      escrow_transactions: {
        Row: {
          created_at: string | null
          creator_fee: number | null
          id: string
          payout_processed_at: string | null
          payout_status: string | null
          payout_tx_signature: string | null
          platform_fee: number | null
          sol_amount: number
          token_amount: number | null
          token_id: string | null
          transaction_type: string
          tx_signature: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string | null
          creator_fee?: number | null
          id?: string
          payout_processed_at?: string | null
          payout_status?: string | null
          payout_tx_signature?: string | null
          platform_fee?: number | null
          sol_amount: number
          token_amount?: number | null
          token_id?: string | null
          transaction_type: string
          tx_signature?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string | null
          creator_fee?: number | null
          id?: string
          payout_processed_at?: string | null
          payout_status?: string | null
          payout_tx_signature?: string | null
          platform_fee?: number | null
          sol_amount?: number
          token_amount?: number | null
          token_id?: string | null
          transaction_type?: string
          tx_signature?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "escrow_transactions_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      forum_boards: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          thread_count: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          thread_count?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          thread_count?: number | null
        }
        Relationships: []
      }
      forum_posts: {
        Row: {
          content: string
          created_at: string
          id: string
          image_path: string | null
          supply_percentage: number | null
          thread_id: string | null
          token_balance: number | null
          username: string
          verification_status: string | null
          wallet_address: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          image_path?: string | null
          supply_percentage?: number | null
          thread_id?: string | null
          token_balance?: number | null
          username: string
          verification_status?: string | null
          wallet_address: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          image_path?: string | null
          supply_percentage?: number | null
          thread_id?: string | null
          token_balance?: number | null
          username?: string
          verification_status?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "forum_posts_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "forum_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      forum_threads: {
        Row: {
          board_id: string | null
          content: string
          created_at: string
          id: string
          image_path: string | null
          reply_count: number | null
          supply_percentage: number | null
          title: string
          token_balance: number | null
          username: string
          verification_status: string | null
          wallet_address: string
        }
        Insert: {
          board_id?: string | null
          content: string
          created_at?: string
          id?: string
          image_path?: string | null
          reply_count?: number | null
          supply_percentage?: number | null
          title: string
          token_balance?: number | null
          username: string
          verification_status?: string | null
          wallet_address: string
        }
        Update: {
          board_id?: string | null
          content?: string
          created_at?: string
          id?: string
          image_path?: string | null
          reply_count?: number | null
          supply_percentage?: number | null
          title?: string
          token_balance?: number | null
          username?: string
          verification_status?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "forum_threads_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "forum_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      jackpot_participants: {
        Row: {
          amount: number
          bet_amount: number | null
          created_at: string
          id: string
          joined_at: string | null
          odds_percentage: number | null
          round_id: string | null
          transaction_verified: boolean | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          amount: number
          bet_amount?: number | null
          created_at?: string
          id?: string
          joined_at?: string | null
          odds_percentage?: number | null
          round_id?: string | null
          transaction_verified?: boolean | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          amount?: number
          bet_amount?: number | null
          created_at?: string
          id?: string
          joined_at?: string | null
          odds_percentage?: number | null
          round_id?: string | null
          transaction_verified?: boolean | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "jackpot_participants_round_id_fkey"
            columns: ["round_id"]
            isOneToOne: false
            referencedRelation: "jackpot_rounds"
            referencedColumns: ["id"]
          },
        ]
      }
      jackpot_rounds: {
        Row: {
          created_at: string
          ends_at: string | null
          id: string
          min_bet_amount: number | null
          min_participants: number | null
          participant_count: number | null
          round_number: number
          started_at: string | null
          status: string
          total_pot: number | null
          winner_address: string | null
          winner_username: string | null
        }
        Insert: {
          created_at?: string
          ends_at?: string | null
          id?: string
          min_bet_amount?: number | null
          min_participants?: number | null
          participant_count?: number | null
          round_number: number
          started_at?: string | null
          status?: string
          total_pot?: number | null
          winner_address?: string | null
          winner_username?: string | null
        }
        Update: {
          created_at?: string
          ends_at?: string | null
          id?: string
          min_bet_amount?: number | null
          min_participants?: number | null
          participant_count?: number | null
          round_number?: number
          started_at?: string | null
          status?: string
          total_pot?: number | null
          winner_address?: string | null
          winner_username?: string | null
        }
        Relationships: []
      }
      jackpot_winners: {
        Row: {
          amount: number
          created_at: string
          id: string
          round_id: string | null
          wallet_address: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          round_id?: string | null
          wallet_address: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          round_id?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "jackpot_winners_round_id_fkey"
            columns: ["round_id"]
            isOneToOne: false
            referencedRelation: "jackpot_rounds"
            referencedColumns: ["id"]
          },
        ]
      }
      launchpad_holders: {
        Row: {
          balance: number | null
          created_at: string | null
          id: string
          token_id: string | null
          updated_at: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          balance?: number | null
          created_at?: string | null
          id?: string
          token_id?: string | null
          updated_at?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          balance?: number | null
          created_at?: string | null
          id?: string
          token_id?: string | null
          updated_at?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "launchpad_holders_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      launchpad_tokens: {
        Row: {
          actual_token_mint: string | null
          bonding_curve_progress: number | null
          config_address: string | null
          contract_address: string
          created_at: string | null
          creation_fee_tx: string | null
          creator_claimed_fees: number | null
          creator_earnings: number | null
          creator_fee_percentage: number | null
          creator_username: string | null
          creator_wallet: string
          current_price: number | null
          current_supply: number | null
          damm_pool_address: string | null
          description: string | null
          encrypted_mint_keypair: string | null
          escrow_account: string | null
          escrow_sol_balance: number | null
          graduation_threshold: number | null
          graduation_tx: string | null
          holder_count: number | null
          id: string
          initial_buy_sol: number | null
          is_graduated: boolean | null
          is_on_chain: boolean | null
          is_real_token: boolean | null
          logo_url: string | null
          lp_mint_address: string | null
          market_cap: number | null
          migration_status: string | null
          mint_authority: string | null
          name: string
          pool_address: string | null
          pool_config_address: string | null
          symbol: string
          token_mint: string | null
          tokens_minted_onchain: boolean | null
          total_supply: number | null
          updated_at: string | null
          vanity_attempts: number | null
          volume_24h: number | null
        }
        Insert: {
          actual_token_mint?: string | null
          bonding_curve_progress?: number | null
          config_address?: string | null
          contract_address: string
          created_at?: string | null
          creation_fee_tx?: string | null
          creator_claimed_fees?: number | null
          creator_earnings?: number | null
          creator_fee_percentage?: number | null
          creator_username?: string | null
          creator_wallet: string
          current_price?: number | null
          current_supply?: number | null
          damm_pool_address?: string | null
          description?: string | null
          encrypted_mint_keypair?: string | null
          escrow_account?: string | null
          escrow_sol_balance?: number | null
          graduation_threshold?: number | null
          graduation_tx?: string | null
          holder_count?: number | null
          id?: string
          initial_buy_sol?: number | null
          is_graduated?: boolean | null
          is_on_chain?: boolean | null
          is_real_token?: boolean | null
          logo_url?: string | null
          lp_mint_address?: string | null
          market_cap?: number | null
          migration_status?: string | null
          mint_authority?: string | null
          name: string
          pool_address?: string | null
          pool_config_address?: string | null
          symbol: string
          token_mint?: string | null
          tokens_minted_onchain?: boolean | null
          total_supply?: number | null
          updated_at?: string | null
          vanity_attempts?: number | null
          volume_24h?: number | null
        }
        Update: {
          actual_token_mint?: string | null
          bonding_curve_progress?: number | null
          config_address?: string | null
          contract_address?: string
          created_at?: string | null
          creation_fee_tx?: string | null
          creator_claimed_fees?: number | null
          creator_earnings?: number | null
          creator_fee_percentage?: number | null
          creator_username?: string | null
          creator_wallet?: string
          current_price?: number | null
          current_supply?: number | null
          damm_pool_address?: string | null
          description?: string | null
          encrypted_mint_keypair?: string | null
          escrow_account?: string | null
          escrow_sol_balance?: number | null
          graduation_threshold?: number | null
          graduation_tx?: string | null
          holder_count?: number | null
          id?: string
          initial_buy_sol?: number | null
          is_graduated?: boolean | null
          is_on_chain?: boolean | null
          is_real_token?: boolean | null
          logo_url?: string | null
          lp_mint_address?: string | null
          market_cap?: number | null
          migration_status?: string | null
          mint_authority?: string | null
          name?: string
          pool_address?: string | null
          pool_config_address?: string | null
          symbol?: string
          token_mint?: string | null
          tokens_minted_onchain?: boolean | null
          total_supply?: number | null
          updated_at?: string | null
          vanity_attempts?: number | null
          volume_24h?: number | null
        }
        Relationships: []
      }
      launchpad_trades: {
        Row: {
          created_at: string | null
          id: string
          price_at_trade: number
          sol_amount: number
          token_amount: number
          token_id: string | null
          trade_type: string
          tx_signature: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          price_at_trade: number
          sol_amount: number
          token_amount: number
          token_id?: string | null
          trade_type: string
          tx_signature?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string | null
          id?: string
          price_at_trade?: number
          sol_amount?: number
          token_amount?: number
          token_id?: string | null
          trade_type?: string
          tx_signature?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "launchpad_trades_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      loans: {
        Row: {
          borrower_username: string | null
          borrower_wallet: string
          collateral_sol: number
          collateral_tx_signature: string | null
          created_at: string
          due_at: string | null
          duration_days: number
          id: string
          interest_rate: number
          loan_amount_sol: number
          ltv_ratio: number
          repaid_at: string | null
          repayment_tx_signature: string | null
          status: string
          updated_at: string
        }
        Insert: {
          borrower_username?: string | null
          borrower_wallet: string
          collateral_sol: number
          collateral_tx_signature?: string | null
          created_at?: string
          due_at?: string | null
          duration_days: number
          id?: string
          interest_rate?: number
          loan_amount_sol: number
          ltv_ratio: number
          repaid_at?: string | null
          repayment_tx_signature?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          borrower_username?: string | null
          borrower_wallet?: string
          collateral_sol?: number
          collateral_tx_signature?: string | null
          created_at?: string
          due_at?: string | null
          duration_days?: number
          id?: string
          interest_rate?: number
          loan_amount_sol?: number
          ltv_ratio?: number
          repaid_at?: string | null
          repayment_tx_signature?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      meme_comments: {
        Row: {
          content: string
          created_at: string | null
          id: string
          meme_id: string
          username: string | null
          wallet_address: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          meme_id: string
          username?: string | null
          wallet_address: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          meme_id?: string
          username?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      meme_donations: {
        Row: {
          amount: number
          created_at: string | null
          donor_username: string | null
          donor_wallet: string
          id: string
          meme_id: string
          recipient_wallet: string
          tx_signature: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          donor_username?: string | null
          donor_wallet: string
          id?: string
          meme_id: string
          recipient_wallet: string
          tx_signature?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          donor_username?: string | null
          donor_wallet?: string
          id?: string
          meme_id?: string
          recipient_wallet?: string
          tx_signature?: string | null
        }
        Relationships: []
      }
      meme_uploads: {
        Row: {
          content_type: string
          created_at: string
          donation_amount: number | null
          donation_tx_signature: string | null
          file_path: string
          file_size: number
          filename: string
          id: string
          supply_percentage: number | null
          token_balance: number | null
          username: string
          verification_status: string | null
          wallet_address: string
        }
        Insert: {
          content_type: string
          created_at?: string
          donation_amount?: number | null
          donation_tx_signature?: string | null
          file_path: string
          file_size: number
          filename: string
          id?: string
          supply_percentage?: number | null
          token_balance?: number | null
          username: string
          verification_status?: string | null
          wallet_address: string
        }
        Update: {
          content_type?: string
          created_at?: string
          donation_amount?: number | null
          donation_tx_signature?: string | null
          file_path?: string
          file_size?: number
          filename?: string
          id?: string
          supply_percentage?: number | null
          token_balance?: number | null
          username?: string
          verification_status?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      nft_collections: {
        Row: {
          boost_type: string
          boost_value: number
          created_at: string
          description: string | null
          id: string
          is_available: boolean | null
          name: string
          price_sol: number
          purchased_at: string | null
          purchased_by_wallet: string | null
          rarity: string
        }
        Insert: {
          boost_type: string
          boost_value: number
          created_at?: string
          description?: string | null
          id?: string
          is_available?: boolean | null
          name: string
          price_sol: number
          purchased_at?: string | null
          purchased_by_wallet?: string | null
          rarity?: string
        }
        Update: {
          boost_type?: string
          boost_value?: number
          created_at?: string
          description?: string | null
          id?: string
          is_available?: boolean | null
          name?: string
          price_sol?: number
          purchased_at?: string | null
          purchased_by_wallet?: string | null
          rarity?: string
        }
        Relationships: []
      }
      nft_purchases: {
        Row: {
          activated_at: string | null
          id: string
          is_active: boolean | null
          nft_id: string | null
          purchase_price_sol: number
          purchased_at: string | null
          transaction_hash: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          activated_at?: string | null
          id?: string
          is_active?: boolean | null
          nft_id?: string | null
          purchase_price_sol: number
          purchased_at?: string | null
          transaction_hash?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          activated_at?: string | null
          id?: string
          is_active?: boolean | null
          nft_id?: string | null
          purchase_price_sol?: number
          purchased_at?: string | null
          transaction_hash?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "nft_purchases_nft_id_fkey"
            columns: ["nft_id"]
            isOneToOne: false
            referencedRelation: "nft_collections"
            referencedColumns: ["id"]
          },
        ]
      }
      p2p_trades: {
        Row: {
          buyer_confirmed: boolean | null
          buyer_username: string | null
          buyer_wallet: string | null
          completed_at: string | null
          created_at: string
          dispute_raised_at: string | null
          dispute_reason: string | null
          disputed_by: string | null
          escrow_status: string
          escrow_tx_signature: string | null
          fiat_amount: number
          fiat_currency: string
          id: string
          locked_at: string | null
          payment_details: string | null
          payment_method: string | null
          seller_confirmed: boolean | null
          seller_username: string | null
          seller_wallet: string
          sol_amount: number
          updated_at: string
        }
        Insert: {
          buyer_confirmed?: boolean | null
          buyer_username?: string | null
          buyer_wallet?: string | null
          completed_at?: string | null
          created_at?: string
          dispute_raised_at?: string | null
          dispute_reason?: string | null
          disputed_by?: string | null
          escrow_status?: string
          escrow_tx_signature?: string | null
          fiat_amount: number
          fiat_currency?: string
          id?: string
          locked_at?: string | null
          payment_details?: string | null
          payment_method?: string | null
          seller_confirmed?: boolean | null
          seller_username?: string | null
          seller_wallet: string
          sol_amount: number
          updated_at?: string
        }
        Update: {
          buyer_confirmed?: boolean | null
          buyer_username?: string | null
          buyer_wallet?: string | null
          completed_at?: string | null
          created_at?: string
          dispute_raised_at?: string | null
          dispute_reason?: string | null
          disputed_by?: string | null
          escrow_status?: string
          escrow_tx_signature?: string | null
          fiat_amount?: number
          fiat_currency?: string
          id?: string
          locked_at?: string | null
          payment_details?: string | null
          payment_method?: string | null
          seller_confirmed?: boolean | null
          seller_username?: string | null
          seller_wallet?: string
          sol_amount?: number
          updated_at?: string
        }
        Relationships: []
      }
      platform_fees: {
        Row: {
          amount: number
          created_at: string | null
          fee_type: string
          id: string
          token_id: string | null
          tx_signature: string | null
          wallet_address: string
        }
        Insert: {
          amount: number
          created_at?: string | null
          fee_type: string
          id?: string
          token_id?: string | null
          tx_signature?: string | null
          wallet_address: string
        }
        Update: {
          amount?: number
          created_at?: string | null
          fee_type?: string
          id?: string
          token_id?: string | null
          tx_signature?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "platform_fees_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      powerball_participants: {
        Row: {
          created_at: string
          id: string
          joined_at: string | null
          qualification_checked_at: string | null
          qualification_verified: boolean | null
          round_id: string | null
          token_balance: number | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string
          id?: string
          joined_at?: string | null
          qualification_checked_at?: string | null
          qualification_verified?: boolean | null
          round_id?: string | null
          token_balance?: number | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string
          id?: string
          joined_at?: string | null
          qualification_checked_at?: string | null
          qualification_verified?: boolean | null
          round_id?: string | null
          token_balance?: number | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "powerball_participants_round_id_fkey"
            columns: ["round_id"]
            isOneToOne: false
            referencedRelation: "powerball_rounds"
            referencedColumns: ["id"]
          },
        ]
      }
      powerball_rounds: {
        Row: {
          completed_at: string | null
          created_at: string
          creator_fee: number | null
          current_volume: number | null
          ends_at: string | null
          id: string
          participant_count: number | null
          prize_pool: number | null
          round_number: number
          started_at: string | null
          status: string
          total_pot: number | null
          updated_at: string | null
          volume_threshold: number | null
          winner_address: string | null
          winner_username: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          creator_fee?: number | null
          current_volume?: number | null
          ends_at?: string | null
          id?: string
          participant_count?: number | null
          prize_pool?: number | null
          round_number: number
          started_at?: string | null
          status?: string
          total_pot?: number | null
          updated_at?: string | null
          volume_threshold?: number | null
          winner_address?: string | null
          winner_username?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          creator_fee?: number | null
          current_volume?: number | null
          ends_at?: string | null
          id?: string
          participant_count?: number | null
          prize_pool?: number | null
          round_number?: number
          started_at?: string | null
          status?: string
          total_pot?: number | null
          updated_at?: string | null
          volume_threshold?: number | null
          winner_address?: string | null
          winner_username?: string | null
        }
        Relationships: []
      }
      powerball_winners: {
        Row: {
          amount: number
          created_at: string
          id: string
          payout_completed: boolean | null
          payout_completed_at: string | null
          prize_amount: number | null
          round_id: string | null
          token_balance_at_win: number | null
          username: string | null
          volume_at_win: number | null
          wallet_address: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          payout_completed?: boolean | null
          payout_completed_at?: string | null
          prize_amount?: number | null
          round_id?: string | null
          token_balance_at_win?: number | null
          username?: string | null
          volume_at_win?: number | null
          wallet_address: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          payout_completed?: boolean | null
          payout_completed_at?: string | null
          prize_amount?: number | null
          round_id?: string | null
          token_balance_at_win?: number | null
          username?: string | null
          volume_at_win?: number | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "powerball_winners_round_id_fkey"
            columns: ["round_id"]
            isOneToOne: false
            referencedRelation: "powerball_rounds"
            referencedColumns: ["id"]
          },
        ]
      }
      price_alerts: {
        Row: {
          alert_type: string
          created_at: string
          id: string
          is_triggered: boolean
          target_price: number
          token_id: string
          triggered_at: string | null
          wallet_address: string
        }
        Insert: {
          alert_type: string
          created_at?: string
          id?: string
          is_triggered?: boolean
          target_price: number
          token_id: string
          triggered_at?: string | null
          wallet_address: string
        }
        Update: {
          alert_type?: string
          created_at?: string
          id?: string
          is_triggered?: boolean
          target_price?: number
          token_id?: string
          triggered_at?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "price_alerts_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_tasks: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          max_reward: number | null
          min_reward: number | null
          requirements: Json | null
          reward_amount: number
          task_type: string
          title: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          max_reward?: number | null
          min_reward?: number | null
          requirements?: Json | null
          reward_amount: number
          task_type: string
          title: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          max_reward?: number | null
          min_reward?: number | null
          requirements?: Json | null
          reward_amount?: number
          task_type?: string
          title?: string
        }
        Relationships: []
      }
      token_balances: {
        Row: {
          auk_balance: number | null
          balance: number
          created_at: string
          id: string
          token_balance: number | null
          token_id: string | null
          updated_at: string
          username: string | null
          wallet_address: string
        }
        Insert: {
          auk_balance?: number | null
          balance?: number
          created_at?: string
          id?: string
          token_balance?: number | null
          token_id?: string | null
          updated_at?: string
          username?: string | null
          wallet_address: string
        }
        Update: {
          auk_balance?: number | null
          balance?: number
          created_at?: string
          id?: string
          token_balance?: number | null
          token_id?: string | null
          updated_at?: string
          username?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      token_comments: {
        Row: {
          content: string
          created_at: string
          id: string
          token_id: string
          username: string | null
          wallet_address: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          token_id: string
          username?: string | null
          wallet_address: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          token_id?: string
          username?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "token_comments_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      token_dashboard_actions: {
        Row: {
          action_type: string
          created_at: string
          id: string
          reason: string | null
          token_amount: number
          token_id: string
          username: string | null
          wallet_address: string
        }
        Insert: {
          action_type: string
          created_at?: string
          id?: string
          reason?: string | null
          token_amount: number
          token_id: string
          username?: string | null
          wallet_address: string
        }
        Update: {
          action_type?: string
          created_at?: string
          id?: string
          reason?: string | null
          token_amount?: number
          token_id?: string
          username?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      token_transactions: {
        Row: {
          auk_amount: number
          created_at: string
          id: string
          market_cap_after: number | null
          market_cap_before: number | null
          tax_amount: number | null
          token_amount: number
          token_id: string
          token_price: number
          transaction_type: string
          username: string | null
          wallet_address: string
        }
        Insert: {
          auk_amount: number
          created_at?: string
          id?: string
          market_cap_after?: number | null
          market_cap_before?: number | null
          tax_amount?: number | null
          token_amount: number
          token_id: string
          token_price: number
          transaction_type: string
          username?: string | null
          wallet_address: string
        }
        Update: {
          auk_amount?: number
          created_at?: string
          id?: string
          market_cap_after?: number | null
          market_cap_before?: number | null
          tax_amount?: number | null
          token_amount?: number
          token_id?: string
          token_price?: number
          transaction_type?: string
          username?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      token_watchlist: {
        Row: {
          created_at: string
          id: string
          token_id: string
          wallet_address: string
        }
        Insert: {
          created_at?: string
          id?: string
          token_id: string
          wallet_address: string
        }
        Update: {
          created_at?: string
          id?: string
          token_id?: string
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "token_watchlist_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "launchpad_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      user_activity_log: {
        Row: {
          activity_type: string
          amount: number | null
          created_at: string | null
          details: Json | null
          id: string
          wallet_address: string
        }
        Insert: {
          activity_type: string
          amount?: number | null
          created_at?: string | null
          details?: Json | null
          id?: string
          wallet_address: string
        }
        Update: {
          activity_type?: string
          amount?: number | null
          created_at?: string | null
          details?: Json | null
          id?: string
          wallet_address?: string
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          created_at: string
          custom_username: string | null
          id: string
          updated_at: string
          username: string | null
          username_set_at: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string
          custom_username?: string | null
          id?: string
          updated_at?: string
          username?: string | null
          username_set_at?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string
          custom_username?: string | null
          id?: string
          updated_at?: string
          username?: string | null
          username_set_at?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      user_rewards: {
        Row: {
          created_at: string
          id: string
          reward_amount: number
          status: string
          submission_id: string | null
          transaction_hash: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string
          id?: string
          reward_amount: number
          status?: string
          submission_id?: string | null
          transaction_hash?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string
          id?: string
          reward_amount?: number
          status?: string
          submission_id?: string | null
          transaction_hash?: string | null
          wallet_address?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_rewards_submission_id_fkey"
            columns: ["submission_id"]
            isOneToOne: false
            referencedRelation: "user_task_submissions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_sessions: {
        Row: {
          created_at: string
          id: string
          is_online: boolean | null
          last_seen: string | null
          username: string | null
          wallet_address: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_online?: boolean | null
          last_seen?: string | null
          username?: string | null
          wallet_address: string
        }
        Update: {
          created_at?: string
          id?: string
          is_online?: boolean | null
          last_seen?: string | null
          username?: string | null
          wallet_address?: string
        }
        Relationships: []
      }
      user_task_submissions: {
        Row: {
          admin_notes: string | null
          id: string
          status: string
          submission_data: Json | null
          submitted_at: string
          task_id: string | null
          user_id: string
          username: string | null
          wallet_address: string | null
        }
        Insert: {
          admin_notes?: string | null
          id?: string
          status?: string
          submission_data?: Json | null
          submitted_at?: string
          task_id?: string | null
          user_id: string
          username?: string | null
          wallet_address?: string | null
        }
        Update: {
          admin_notes?: string | null
          id?: string
          status?: string
          submission_data?: Json | null
          submitted_at?: string
          task_id?: string | null
          user_id?: string
          username?: string | null
          wallet_address?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_task_submissions_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "referral_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_username_availability: {
        Args: { desired_username: string }
        Returns: boolean
      }
      get_or_create_active_jackpot_round: { Args: never; Returns: string }
      select_jackpot_winner: { Args: { round_uuid: string }; Returns: Json }
      set_custom_username: {
        Args: { desired_username: string; wallet_addr: string }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
