import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useMeteoraLaunchpad, MeteoraToken } from '@/hooks/useMeteoraLaunchpad';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import WalletConnector from '@/components/chat/WalletConnector';
import { motion } from 'framer-motion';
import { 
  Wallet,
  TrendingUp,
  TrendingDown,
  PieChart,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Coins,
  Activity,
  DollarSign,
  Percent,
  RefreshCw
} from 'lucide-react';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart as RechartsPieChart, Pie, Cell } from 'recharts';

interface PortfolioHolding {
  token: MeteoraToken;
  balance: number;
  currentValue: number;
  costBasis: number;
  pnl: number;
  pnlPercent: number;
  allocation: number;
}

interface TradeHistory {
  id: string;
  token_id: string;
  trade_type: string;
  sol_amount: number;
  token_amount: number;
  price_at_trade: number;
  created_at: string;
  tokenSymbol: string;
  tokenName: string;
}

const CHART_COLORS = ['#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9', '#3b82f6', '#6366f1', '#8b5cf6'];

const Portfolio = () => {
  const navigate = useNavigate();
  const { connected, walletAddress } = useMultiWallet();
  const { tokens, loading, getAllUserHoldings } = useMeteoraLaunchpad();
  
  const [holdings, setHoldings] = useState<PortfolioHolding[]>([]);
  const [trades, setTrades] = useState<TradeHistory[]>([]);
  const [portfolioValue, setPortfolioValue] = useState(0);
  const [totalPnl, setTotalPnl] = useState(0);
  const [totalPnlPercent, setTotalPnlPercent] = useState(0);
  const [totalInvested, setTotalInvested] = useState(0);
  const [loadingPortfolio, setLoadingPortfolio] = useState(true);
  const [valueHistory, setValueHistory] = useState<{ date: string; value: number }[]>([]);

  useEffect(() => {
    if (connected && walletAddress && tokens.length > 0) {
      loadPortfolio();
    } else if (!loading && tokens.length === 0) {
      setLoadingPortfolio(false);
    }
  }, [connected, walletAddress, tokens, loading]);

  const loadPortfolio = async () => {
    if (!walletAddress) return;
    setLoadingPortfolio(true);

    try {
      // Get all user holdings from the hook
      const holdingsMap = await getAllUserHoldings();

      // Get all user trades
      const { data: tradesData } = await supabase
        .from('launchpad_trades')
        .select('*')
        .eq('wallet_address', walletAddress)
        .order('created_at', { ascending: false })
        .limit(100);

      // Calculate holdings with P&L
      const portfolioHoldings: PortfolioHolding[] = [];
      let totalValue = 0;
      let totalCost = 0;

      // Group trades by token to calculate cost basis
      const tradesByToken = new Map<string, any[]>();
      (tradesData || []).forEach((trade: any) => {
        const existing = tradesByToken.get(trade.token_id) || [];
        existing.push(trade);
        tradesByToken.set(trade.token_id, existing);
      });

      holdingsMap.forEach((balance, tokenId) => {
        if (balance <= 0) return;
        
        const token = tokens.find(t => t.id === tokenId);
        if (!token) return;

        const currentValue = balance * token.currentPrice;
        totalValue += currentValue;

        // Calculate cost basis from buy trades
        const tokenTrades = tradesByToken.get(tokenId) || [];
        let costBasis = 0;
        let tokensAcquired = 0;

        tokenTrades.forEach((trade: any) => {
          if (trade.trade_type === 'buy') {
            costBasis += Number(trade.sol_amount);
            tokensAcquired += Number(trade.token_amount);
          }
        });

        // Proportional cost basis for remaining tokens
        const remainingRatio = tokensAcquired > 0 ? balance / tokensAcquired : 0;
        const adjustedCostBasis = costBasis * remainingRatio;
        totalCost += adjustedCostBasis;

        const pnl = currentValue - adjustedCostBasis;
        const pnlPercent = adjustedCostBasis > 0 ? (pnl / adjustedCostBasis) * 100 : 0;

        portfolioHoldings.push({
          token,
          balance,
          currentValue,
          costBasis: adjustedCostBasis,
          pnl,
          pnlPercent,
          allocation: 0 // Will be calculated after
        });
      });

      // Calculate allocation percentages
      portfolioHoldings.forEach(h => {
        h.allocation = totalValue > 0 ? (h.currentValue / totalValue) * 100 : 0;
      });

      // Sort by value
      portfolioHoldings.sort((a, b) => b.currentValue - a.currentValue);

      // Map trades with token info
      const tradeHistory: TradeHistory[] = (tradesData || []).map((trade: any) => {
        const token = tokens.find(t => t.id === trade.token_id);
        return {
          id: trade.id,
          token_id: trade.token_id,
          trade_type: trade.trade_type,
          sol_amount: Number(trade.sol_amount),
          token_amount: Number(trade.token_amount),
          price_at_trade: Number(trade.price_at_trade),
          created_at: trade.created_at,
          tokenSymbol: token?.symbol || 'Unknown',
          tokenName: token?.name || 'Unknown Token',
        };
      });

      // Generate simulated value history
      const history = generateValueHistory(totalValue);

      setHoldings(portfolioHoldings);
      setTrades(tradeHistory);
      setPortfolioValue(totalValue);
      setTotalInvested(totalCost);
      setTotalPnl(totalValue - totalCost);
      setTotalPnlPercent(totalCost > 0 ? ((totalValue - totalCost) / totalCost) * 100 : 0);
      setValueHistory(history);
    } catch (error) {
      console.error('Error loading portfolio:', error);
    } finally {
      setLoadingPortfolio(false);
    }
  };

  const generateValueHistory = (currentValue: number) => {
    const days = 7;
    const history: { date: string; value: number }[] = [];
    const now = Date.now();

    for (let i = days; i >= 0; i--) {
      const date = new Date(now - i * 24 * 60 * 60 * 1000);
      const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      
      // Simulate value with some variance
      const variance = (Math.random() - 0.5) * 0.3 * currentValue;
      const dayValue = Math.max(0, currentValue * (1 - (i * 0.05)) + variance);
      
      history.push({ date: dateStr, value: dayValue });
    }

    // Make sure current day shows actual value
    if (history.length > 0) {
      history[history.length - 1].value = currentValue;
    }

    return history;
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(2)}K`;
    if (num < 0.001 && num > 0) return num.toFixed(6);
    return num.toFixed(4);
  };

  const formatPrice = (price: number): string => {
    if (price < 0.000001) return price.toExponential(2);
    if (price < 0.001) return price.toFixed(8);
    return price.toFixed(6);
  };

  const getTimeAgo = (dateString: string): string => {
    const seconds = Math.floor((Date.now() - new Date(dateString).getTime()) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="flex items-center justify-center pt-20 px-4">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mb-4">
                <PieChart className="h-8 w-8 text-white" />
              </div>
              <CardTitle>Portfolio Tracker</CardTitle>
              <CardDescription>
                Connect your wallet to view your launchpad holdings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WalletConnector />
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      <main className="container mx-auto px-4 py-8 pt-20 sm:pt-8 sm:ml-64 lg:ml-72">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-500 to-emerald-500 bg-clip-text text-transparent flex items-center gap-2">
                <PieChart className="h-8 w-8 text-green-500" />
                Portfolio
              </h1>
              <p className="text-muted-foreground mt-1">
                Track your launchpad holdings and P&L
              </p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={loadPortfolio}
              disabled={loadingPortfolio}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loadingPortfolio ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          {/* Portfolio Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-green-500/20">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Value</p>
                    <p className="text-2xl font-bold font-mono">{formatNumber(portfolioValue)} SOL</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center">
                    <Wallet className="h-6 w-6 text-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className={totalPnl >= 0 ? 'border-green-500/20' : 'border-red-500/20'}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total P&L</p>
                    <p className={`text-2xl font-bold font-mono ${totalPnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {totalPnl >= 0 ? '+' : ''}{formatNumber(totalPnl)} SOL
                    </p>
                  </div>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    totalPnl >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'
                  }`}>
                    {totalPnl >= 0 ? (
                      <TrendingUp className="h-6 w-6 text-green-500" />
                    ) : (
                      <TrendingDown className="h-6 w-6 text-red-500" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className={totalPnlPercent >= 0 ? 'border-green-500/20' : 'border-red-500/20'}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">P&L %</p>
                    <p className={`text-2xl font-bold font-mono ${totalPnlPercent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {totalPnlPercent >= 0 ? '+' : ''}{totalPnlPercent.toFixed(2)}%
                    </p>
                  </div>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    totalPnlPercent >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'
                  }`}>
                    <Percent className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Invested</p>
                    <p className="text-2xl font-bold font-mono">{formatNumber(totalInvested)} SOL</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-muted-foreground" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts and Holdings */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Value Chart */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Portfolio Value (7 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingPortfolio ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin h-8 w-8 border-2 border-green-500 border-t-transparent rounded-full" />
                  </div>
                ) : valueHistory.length > 0 && portfolioValue > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={valueHistory}>
                      <defs>
                        <linearGradient id="valueGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#22c55e" stopOpacity={0.3} />
                          <stop offset="100%" stopColor="#22c55e" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="date" tick={{ fontSize: 12 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 12 }} className="text-muted-foreground" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number) => [`${formatNumber(value)} SOL`, 'Value']}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#22c55e" 
                        strokeWidth={2}
                        fill="url(#valueGradient)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    No data available
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Allocation Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Allocation
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingPortfolio ? (
                  <div className="h-48 flex items-center justify-center">
                    <div className="animate-spin h-8 w-8 border-2 border-green-500 border-t-transparent rounded-full" />
                  </div>
                ) : holdings.length > 0 ? (
                  <>
                    <ResponsiveContainer width="100%" height={180}>
                      <RechartsPieChart>
                        <Pie
                          data={holdings.slice(0, 8)}
                          dataKey="allocation"
                          nameKey="token.symbol"
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={70}
                        >
                          {holdings.slice(0, 8).map((_, index) => (
                            <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value: number) => [`${value.toFixed(1)}%`, 'Allocation']}
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px'
                          }}
                        />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                    <div className="space-y-2 mt-2">
                      {holdings.slice(0, 5).map((h, i) => (
                        <div key={h.token.id} className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}
                            />
                            <span className="truncate max-w-[100px]">{h.token.symbol}</span>
                          </div>
                          <span className="font-mono">{h.allocation.toFixed(1)}%</span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="h-48 flex items-center justify-center text-muted-foreground">
                    No holdings
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Holdings and Trade History Tabs */}
          <Tabs defaultValue="holdings" className="space-y-4">
            <TabsList>
              <TabsTrigger value="holdings" className="flex items-center gap-2">
                <Coins className="h-4 w-4" />
                Holdings ({holdings.length})
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Trade History ({trades.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="holdings">
              {loadingPortfolio ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-muted" />
                          <div className="flex-1">
                            <div className="h-4 bg-muted rounded w-32 mb-2" />
                            <div className="h-3 bg-muted rounded w-24" />
                          </div>
                          <div className="h-4 bg-muted rounded w-20" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : holdings.length === 0 ? (
                <Card className="p-12 text-center">
                  <Wallet className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No Holdings</h3>
                  <p className="text-muted-foreground mb-4">Start trading to build your portfolio</p>
                  <Button onClick={() => navigate('/launchpad')}>
                    Go to Launchpad
                  </Button>
                </Card>
              ) : (
                <div className="space-y-3">
                  {holdings.map((holding) => (
                    <Card 
                      key={holding.token.id}
                      className="hover:border-green-500/30 cursor-pointer transition-all"
                      onClick={() => navigate(`/launchpad/token/${holding.token.id}`)}
                    >
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                          {/* Token Info */}
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            {holding.token.logoUrl ? (
                              <img 
                                src={holding.token.logoUrl} 
                                alt={holding.token.name}
                                className="w-12 h-12 rounded-full object-cover border border-green-500/30"
                              />
                            ) : (
                              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white font-bold">
                                {holding.token.symbol.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <h3 className="font-bold truncate">{holding.token.name}</h3>
                              <p className="text-sm text-muted-foreground">${holding.token.symbol}</p>
                            </div>
                          </div>

                          {/* Balance */}
                          <div className="text-right hidden sm:block">
                            <p className="text-sm text-muted-foreground">Balance</p>
                            <p className="font-mono font-medium">{formatNumber(holding.balance)}</p>
                          </div>

                          {/* Value */}
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">Value</p>
                            <p className="font-mono font-medium">{formatNumber(holding.currentValue)} SOL</p>
                          </div>

                          {/* P&L */}
                          <div className="text-right min-w-[80px]">
                            <p className="text-sm text-muted-foreground">P&L</p>
                            <div className={`font-mono font-medium flex items-center justify-end gap-1 ${
                              holding.pnl >= 0 ? 'text-green-500' : 'text-red-500'
                            }`}>
                              {holding.pnl >= 0 ? (
                                <ArrowUpRight className="h-4 w-4" />
                              ) : (
                                <ArrowDownRight className="h-4 w-4" />
                              )}
                              {holding.pnlPercent >= 0 ? '+' : ''}{holding.pnlPercent.toFixed(1)}%
                            </div>
                          </div>

                          {/* Allocation */}
                          <Badge variant="outline" className="hidden md:flex">
                            {holding.allocation.toFixed(1)}%
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="history">
              {loadingPortfolio ? (
                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg animate-pulse">
                      <div className="w-8 h-8 rounded-full bg-muted" />
                      <div className="flex-1">
                        <div className="h-4 bg-muted rounded w-40 mb-2" />
                        <div className="h-3 bg-muted rounded w-24" />
                      </div>
                      <div className="h-4 bg-muted rounded w-20" />
                    </div>
                  ))}
                </div>
              ) : trades.length === 0 ? (
                <Card className="p-12 text-center">
                  <Activity className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No Trade History</h3>
                  <p className="text-muted-foreground">Your trades will appear here</p>
                </Card>
              ) : (
                <div className="space-y-2">
                  {trades.map((trade) => (
                    <div 
                      key={trade.id}
                      className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      {/* Trade Type Icon */}
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        trade.trade_type === 'buy' ? 'bg-green-500/10' : 'bg-red-500/10'
                      }`}>
                        {trade.trade_type === 'buy' ? (
                          <ArrowUpRight className="h-5 w-5 text-green-500" />
                        ) : (
                          <ArrowDownRight className="h-5 w-5 text-red-500" />
                        )}
                      </div>

                      {/* Trade Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Badge variant={trade.trade_type === 'buy' ? 'default' : 'destructive'} className="text-xs">
                            {trade.trade_type.toUpperCase()}
                          </Badge>
                          <span className="font-medium truncate">
                            {trade.tokenSymbol}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {formatNumber(trade.token_amount)} tokens @ {formatPrice(trade.price_at_trade)} SOL
                        </p>
                      </div>

                      {/* Amount */}
                      <div className="text-right">
                        <p className={`font-mono font-medium ${
                          trade.trade_type === 'buy' ? 'text-red-500' : 'text-green-500'
                        }`}>
                          {trade.trade_type === 'buy' ? '-' : '+'}{trade.sol_amount.toFixed(4)} SOL
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {getTimeAgo(trade.created_at)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Portfolio;
