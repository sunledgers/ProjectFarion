import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Users, Clock, Hash } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import UnifiedNavigation from '@/components/UnifiedNavigation';

interface Board {
  id: string;
  name: string;
  description: string;
  thread_count?: number;
}

interface Thread {
  id: string;
  title: string;
  content: string;
  username: string;
  wallet_address: string;
  supply_percentage: number | null;
  reply_count: number;
  created_at: string;
  image_path?: string;
}

const Forum = () => {
  const { board } = useParams<{ board?: string }>();
  const { connected } = useMultiWallet();
  const [boards, setBoards] = useState<Board[]>([]);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBoards();
    if (board) {
      loadThreads(board);
    }
  }, [board]);

  const loadBoards = async () => {
    try {
      const { data, error } = await supabase
        .from('forum_boards')
        .select('*');

      if (error) throw error;
      setBoards(data || []);
    } catch (error) {
      console.error('Error loading boards:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadThreads = async (boardName: string) => {
    try {
      setLoading(true);
      const { data: boardData } = await supabase
        .from('forum_boards')
        .select('id')
        .eq('name', boardName)
        .single();

      if (!boardData) return;

      const { data, error } = await supabase
        .from('forum_threads')
        .select('*')
        .eq('board_id', boardData.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setThreads(data || []);
    } catch (error) {
      console.error('Error loading threads:', error);
    } finally {
      setLoading(false);
    }
  };

  const getVerificationBadge = (percentage: number | null) => {
    if (!percentage) return <Badge variant="secondary">Not Verified</Badge>;
    
    if (percentage >= 1) return <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black">Whale 🐋</Badge>;
    if (percentage >= 0.1) return <Badge className="bg-gradient-to-r from-purple-500 to-purple-700">Big Holder 💎</Badge>;
    if (percentage >= 0.01) return <Badge className="bg-gradient-to-r from-blue-500 to-blue-700">Holder 📈</Badge>;
    return <Badge variant="outline">Small Bag 💼</Badge>;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!board) {
    // Board selection view
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 pt-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto"
          >
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                ACHAN
              </h1>
              <p className="text-muted-foreground">
                Connect your wallet and join the ACHAN community discussions
              </p>
            </div>

            <div className="grid gap-6">
              {boards.map((board) => (
                <Link key={board.id} to={`/forum/${board.name}`}>
                  <Card className="hover:shadow-lg transition-all duration-300 hover:scale-[1.02] cursor-pointer">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <Hash className="h-6 w-6 text-primary" />
                        /{board.name}/
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{board.description}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4" />
                          Active Discussions
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          Token Holders Only
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Thread list view for specific board
  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 pt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-6xl mx-auto"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Hash className="h-8 w-8 text-primary" />
                /{board}/
              </h1>
              <p className="text-muted-foreground mt-2">
                {boards.find(b => b.name === board)?.description}
              </p>
            </div>
            <div className="flex gap-4">
              <Link to="/forum">
                <Button variant="outline">← Back to Boards</Button>
              </Link>
              {connected && (
                <Link to={`/forum/${board}/new`}>
                  <Button>Create Thread</Button>
                </Link>
              )}
            </div>
          </div>

          {!connected && (
            <Card className="mb-8 border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20 dark:border-yellow-800">
              <CardContent className="pt-6">
                <p className="text-center text-yellow-800 dark:text-yellow-200">
                  Connect your wallet to create threads and verify your token holdings
                </p>
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            {loading ? (
              <div className="text-center py-8">Loading threads...</div>
            ) : threads.length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">No threads yet. Be the first to start a discussion!</p>
                </CardContent>
              </Card>
            ) : (
              threads.map((thread) => (
                <Link key={thread.id} to={`/forum/${board}/thread/${thread.id}`}>
                  <Card className="hover:shadow-lg transition-all duration-300 hover:scale-[1.01] cursor-pointer">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-2 hover:text-primary transition-colors">
                            {thread.title}
                          </h3>
                          <p className="text-muted-foreground mb-3 line-clamp-2">
                            {thread.content.substring(0, 200)}...
                          </p>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="font-medium">{thread.username}</span>
                            {getVerificationBadge(thread.supply_percentage)}
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              {formatDate(thread.created_at)}
                            </div>
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <MessageSquare className="h-4 w-4" />
                              {thread.reply_count} replies
                            </div>
                          </div>
                        </div>
                        {thread.image_path && (
                          <div className="ml-4">
                            <img
                              src={`https://qkbivmakdasuupmiigbp.supabase.co/storage/v1/object/public/forum-images/${thread.image_path}`}
                              alt="Thread image"
                              className="w-16 h-16 object-cover rounded"
                            />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Forum;