import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import PowerballInterface from '@/components/PowerballInterface';
import WalletConnectionPrompt from '@/components/WalletConnectionPrompt';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

const Powerball = () => {
  const { walletAddress } = useMultiWallet();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 py-8 pt-24">
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate('/')}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {walletAddress ? (
            <PowerballInterface />
          ) : (
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="text-center space-y-4"
              >
                <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                  FARION Powerball
                </h1>
                <p className="text-lg text-muted-foreground max-w-md">
                  Volume-based lottery system where FARION token holders can win prizes every 6 hours based on trading volume.
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <WalletConnectionPrompt 
                  title="Join FARION Powerball"
                  description="Connect your wallet to participate in the Powerball lottery and check if you qualify as a FARION token holder."
                />
              </motion.div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Powerball;