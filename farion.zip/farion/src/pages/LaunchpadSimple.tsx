import React from 'react';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import LaunchpadMaintenance from '@/components/LaunchpadMaintenance';

const LaunchpadSimple = () => {
  return (
    <div className="min-h-screen relative">
      <UnifiedNavigation />
      <LaunchpadMaintenance />
      <Footer />
    </div>
  );
};

export default LaunchpadSimple;