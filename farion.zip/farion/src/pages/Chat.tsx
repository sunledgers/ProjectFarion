import React, { useEffect, useState } from 'react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useChat } from '@/hooks/useChat';
import WalletSelector from '@/components/WalletSelector';
import ChatRooms from '@/components/chat/ChatRooms';
import ChatMessages from '@/components/chat/ChatMessages';
import ChatInput from '@/components/chat/ChatInput';
import UserList from '@/components/chat/UserList';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LogOut, Menu, MessageCircle, Users } from 'lucide-react';
import UnifiedNavigation from '@/components/UnifiedNavigation';

const Chat: React.FC = () => {
  const { connected, username, disconnect } = useMultiWallet();
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const { rooms, messages, onlineUsers, offlineUsers, loading, sendMessage } = useChat(activeRoomId || undefined);

  useEffect(() => {
    if (rooms.length > 0 && !activeRoomId) {
      const generalRoom = rooms.find(room => room.name.toLowerCase() === 'general');
      setActiveRoomId(generalRoom?.id || rooms[0]?.id || null);
    }
  }, [rooms, activeRoomId]);

  if (!connected) {
    return <WalletSelector />;
  }

  const handleSendMessage = async (messageText: string) => {
    if (activeRoomId) {
      return await sendMessage(activeRoomId, messageText);
    }
    return false;
  };

  const activeRoom = rooms.find(room => room.id === activeRoomId);

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      {/* Desktop Layout */}
      <div className="hidden md:flex h-screen pt-16">
        <ChatRooms 
          rooms={rooms} 
          activeRoom={activeRoomId} 
          onRoomSelect={setActiveRoomId} 
        />
        
        <div className="flex-1 flex flex-col">
          <div className="border-b bg-card p-4 flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground">Farion Chat</h1>
              {activeRoom && (
                <p className="text-sm text-muted-foreground">#{activeRoom.name}</p>
              )}
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                Connected as: {username}
              </span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={disconnect}
                className="gap-2"
              >
                <LogOut className="h-4 w-4" />
                Disconnect
              </Button>
            </div>
          </div>
          
          <ChatMessages messages={messages} loading={loading} />
          <ChatInput onSendMessage={handleSendMessage} />
        </div>
        
        <UserList users={onlineUsers} offlineUsers={offlineUsers} />
      </div>

      {/* Mobile Layout */}
      <div className="md:hidden flex flex-col h-screen pt-16">
        {/* Mobile Header */}
        <div className="border-b bg-card p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 p-0">
                <div className="p-4">
                  <h3 className="font-semibold text-foreground mb-4">Navigation</h3>
                  <Tabs defaultValue="rooms" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="rooms" className="gap-2">
                        <MessageCircle className="h-4 w-4" />
                        Rooms
                      </TabsTrigger>
                      <TabsTrigger value="users" className="gap-2">
                        <Users className="h-4 w-4" />
                        Online
                      </TabsTrigger>
                    </TabsList>
                    <TabsContent value="rooms" className="mt-4">
                      <ChatRooms 
                        rooms={rooms} 
                        activeRoom={activeRoomId} 
                        onRoomSelect={setActiveRoomId} 
                      />
                    </TabsContent>
                    <TabsContent value="users" className="mt-4">
                      <UserList users={onlineUsers} offlineUsers={offlineUsers} />
                    </TabsContent>
                  </Tabs>
                </div>
              </SheetContent>
            </Sheet>
            <div>
              <h1 className="text-base font-bold text-foreground">Farion Chat</h1>
              {activeRoom && (
                <p className="text-xs text-muted-foreground">#{activeRoom.name}</p>
              )}
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={disconnect}
            className="gap-1"
          >
            <LogOut className="h-3 w-3" />
            <span className="text-xs">Exit</span>
          </Button>
        </div>
        
        {/* Mobile Chat Content */}
        <div className="flex-1 flex flex-col min-h-0">
          <ChatMessages messages={messages} loading={loading} />
          <ChatInput onSendMessage={handleSendMessage} />
        </div>
      </div>
    </div>
  );
};

export default Chat;
