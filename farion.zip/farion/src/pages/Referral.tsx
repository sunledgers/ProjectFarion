import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Gift, Trophy, Star, Coins } from 'lucide-react';
import ReferralTasks from '@/components/ReferralTasks';
import UserRewards from '@/components/UserRewards';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import UnifiedNavigation from '@/components/UnifiedNavigation';

const Referral = () => {
  const { connected } = useMultiWallet();

  if (!connected) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10">
        <UnifiedNavigation />
        <div className="pt-24 sm:pt-32">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-md mx-auto"
            >
              <Gift className="h-16 w-16 mx-auto mb-6 text-primary" />
              <h1 className="text-3xl font-bold mb-4">Connect Your Wallet</h1>
              <p className="text-muted-foreground">
                Connect your wallet to access referral tasks and earn $FARION rewards!
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/10">
      <UnifiedNavigation />
      <div className="pt-24 sm:pt-32">
        <div className="container mx-auto px-4">
          {/* Header Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <div className="flex items-center justify-center gap-3 mb-6">
              <Gift className="h-12 w-12 text-primary" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Referral Tasks
              </h1>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
              Complete social media tasks to earn $FARION tokens! Each completed task rewards you with 5-50 $FARION tokens after manual verification.
            </p>
            
            {/* Reward Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto mb-8">
              <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
                <CardContent className="p-4 text-center">
                  <Coins className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">Reward Range</h3>
                  <p className="text-2xl font-bold text-primary">5-50 $FARION</p>
                  <p className="text-sm text-muted-foreground">Random rewards</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
                <CardContent className="p-4 text-center">
                  <Trophy className="h-8 w-8 mx-auto mb-2 text-accent" />
                  <h3 className="font-semibold">Manual Review</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    All tasks are verified manually before rewards
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20">
                <CardContent className="p-4 text-center">
                  <Star className="h-8 w-8 mx-auto mb-2 text-secondary" />
                  <h3 className="font-semibold">Status Updates</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    Track your task progress and approval status
                  </p>
                </CardContent>
              </Card>
            </div>
          </motion.div>

          {/* Tasks Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-12"
          >
            <ReferralTasks />
          </motion.div>

          {/* Rewards Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <UserRewards />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Referral;