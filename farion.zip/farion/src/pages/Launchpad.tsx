import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Upload, Rocket, AlertCircle, Wallet } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useTokenData } from '@/hooks/useTokenData';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

const Launchpad: React.FC = () => {
  const { connected, connectWallet, availableWallets, walletAddress, username } = useMultiWallet();
  const { createToken } = useTokenData();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [tokenData, setTokenData] = useState({
    name: '',
    symbol: '',
    description: '',
    logo: null as File | null,
    taxPercentage: [0] as number[]
  });
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file",
          variant: "destructive"
        });
        return;
      }

      setTokenData(prev => ({ ...prev, logo: file }));
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!walletAddress || !username) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet first",
        variant: "destructive"
      });
      return;
    }

    if (!tokenData.name || !tokenData.symbol) {
      toast({
        title: "Missing information",
        description: "Please fill in the token name and symbol",
        variant: "destructive"
      });
      return;
    }

    setIsCreating(true);
    
    try {
      const newToken = await createToken({
        name: tokenData.name,
        symbol: tokenData.symbol.toUpperCase(),
        description: tokenData.description || null,
        logo_url: logoPreview || null,
        tax_percentage: tokenData.taxPercentage[0],
        creator_wallet_address: walletAddress,
        creator_username: username
      });

      if (newToken) {
        toast({
          title: "Token created successfully!",
          description: `${tokenData.name} (${tokenData.symbol}) has been launched`,
        });
        
        // Navigate to token dashboard
        navigate(`/launchpad/token/${newToken.id}`);
      } else {
        throw new Error('Failed to create token');
      }
    } catch (error) {
      console.error('Error creating token:', error);
      toast({
        title: "Failed to create token",
        description: "There was an error creating your token. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsCreating(false);
    }
  };

  const resetForm = () => {
    setTokenData({
      name: '',
      symbol: '',
      description: '',
      logo: null,
      taxPercentage: [0]
    });
    setLogoPreview(null);
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-md mx-auto">
            <Card>
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Wallet className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Connect Your Wallet</CardTitle>
                <CardDescription>
                  You need to connect your wallet to access the Launchpad
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-sm text-muted-foreground">
                  Select a wallet to get started:
                </p>
                {availableWallets.map((wallet) => (
                  <Button 
                    key={wallet.name}
                    onClick={() => connectWallet(wallet)} 
                    className="w-full mb-2" 
                    disabled={!wallet.installed}
                  >
                    <span className="mr-2">{wallet.icon}</span>
                    {wallet.name}
                    {!wallet.installed && ' (Not Installed)'}
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="mx-auto mb-4 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <Rocket className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Launchpad</h1>
            <p className="text-muted-foreground">
              Create and launch your own token on the Farion platform
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Token Details</CardTitle>
              <CardDescription>
                Fill in the information for your new token
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Token Logo */}
                <div className="space-y-2">
                  <Label htmlFor="logo">Token Logo</Label>
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-24 border-2 border-dashed border-border rounded-lg flex items-center justify-center bg-muted/50">
                      {logoPreview ? (
                        <img
                          src={logoPreview}
                          alt="Token logo preview"
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <Upload className="h-8 w-8 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1">
                      <Input
                        id="logo"
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="mb-2"
                      />
                      <p className="text-sm text-muted-foreground">
                        Recommended: 500x500px, PNG or JPG format
                      </p>
                    </div>
                  </div>
                </div>

                {/* Token Name */}
                <div className="space-y-2">
                  <Label htmlFor="name">Token Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., My Awesome Token"
                    value={tokenData.name}
                    onChange={(e) => setTokenData(prev => ({ ...prev, name: e.target.value }))}
                    maxLength={50}
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    The full name of your token (max 50 characters)
                  </p>
                </div>

                {/* Token Symbol */}
                <div className="space-y-2">
                  <Label htmlFor="symbol">Token Symbol/Ticker *</Label>
                  <Input
                    id="symbol"
                    placeholder="e.g., MAT"
                    value={tokenData.symbol}
                    onChange={(e) => setTokenData(prev => ({ 
                      ...prev, 
                      symbol: e.target.value.toUpperCase() 
                    }))}
                    maxLength={10}
                    style={{ textTransform: 'uppercase' }}
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    3-10 characters, letters only (automatically converted to uppercase)
                  </p>
                </div>

                {/* Tax Percentage */}
                <div className="space-y-4">
                  <Label>Tax Percentage: {tokenData.taxPercentage[0]}%</Label>
                  <Slider
                    value={tokenData.taxPercentage}
                    onValueChange={(value) => setTokenData(prev => ({ ...prev, taxPercentage: value }))}
                    max={2}
                    min={0}
                    step={0.1}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Transaction tax from 0% to 2% - applied to all trades
                  </p>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your token, its purpose, and what makes it special..."
                    value={tokenData.description}
                    onChange={(e) => setTokenData(prev => ({ ...prev, description: e.target.value }))}
                    maxLength={500}
                    rows={4}
                  />
                  <p className="text-sm text-muted-foreground">
                    {tokenData.description.length}/500 characters
                  </p>
                </div>

                {/* Token Economics Preview */}
                <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                  <h3 className="font-semibold text-sm">Token Economics</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Total Supply:</span>
                      <span className="ml-2 font-mono">1,000,000</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Starting Market Cap:</span>
                      <span className="ml-2 font-mono">$5,000</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Tax Rate:</span>
                      <span className="ml-2 font-mono">{tokenData.taxPercentage[0]}%</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Initial Price:</span>
                      <span className="ml-2 font-mono">$0.005</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button 
                    type="submit" 
                    className="flex-1" 
                    disabled={isCreating || !tokenData.name || !tokenData.symbol}
                  >
                    <Rocket className="h-4 w-4 mr-2" />
                    {isCreating ? 'Launching...' : 'Launch Token'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={resetForm}
                    disabled={isCreating}
                  >
                    Reset
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Launchpad;