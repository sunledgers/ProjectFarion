import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Check, Share, Plus, ArrowDown, Smartphone, Apple, Chrome } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

const Install = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    const userAgent = navigator.userAgent.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(userAgent));
    setIsAndroid(/android/.test(userAgent));

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <UnifiedNavigation />
      
      <main className="container mx-auto px-4 py-8 sm:py-16 pt-24 sm:pt-8 sm:ml-80">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-lg mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
            >
              <img 
                src="/farion-logo.png" 
                alt="Farion" 
                className="w-24 h-24 mx-auto mb-4 rounded-3xl shadow-2xl ring-4 ring-primary/20"
              />
            </motion.div>
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">
              Get the Farion App
            </h1>
            <p className="text-muted-foreground text-lg">
              Install for the best mobile experience
            </p>
          </div>

          {/* Already Installed */}
          <AnimatePresence>
            {isInstalled && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
              >
                <Card className="p-8 text-center bg-gradient-to-br from-primary/20 to-primary/5 border-primary/30">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", bounce: 0.5 }}
                  >
                    <Check className="w-20 h-20 mx-auto text-primary mb-4" />
                  </motion.div>
                  <h2 className="text-2xl font-bold mb-2">Already Installed!</h2>
                  <p className="text-muted-foreground">
                    Look for Farion on your home screen
                  </p>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Android with Install Prompt Available */}
          {!isInstalled && isAndroid && deferredPrompt && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <Button 
                onClick={handleInstallClick}
                size="lg"
                className="w-full h-20 text-xl gap-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 shadow-xl shadow-green-500/30"
              >
                <Download className="w-8 h-8" />
                Install Farion Now
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                One tap install • No app store needed • Free forever
              </p>
            </motion.div>
          )}

          {/* Android without Install Prompt */}
          {!isInstalled && isAndroid && !deferredPrompt && (
            <Card className="p-6 border-2 border-dashed border-primary/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-green-500/20 rounded-lg">
                  <Chrome className="w-6 h-6 text-green-500" />
                </div>
                <h2 className="text-xl font-bold">Install on Android</h2>
              </div>
              <div className="space-y-3 text-sm">
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl"
                >
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">1</span>
                  <span>Tap the menu <strong className="bg-muted px-2 py-1 rounded">⋮</strong> in Chrome</span>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl"
                >
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">2</span>
                  <span>Tap <strong className="bg-muted px-2 py-1 rounded">"Install app"</strong> or <strong className="bg-muted px-2 py-1 rounded">"Add to Home Screen"</strong></span>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl"
                >
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">3</span>
                  <span>Tap <strong className="bg-primary text-primary-foreground px-3 py-1 rounded">Install</strong> to confirm</span>
                </motion.div>
              </div>
            </Card>
          )}

          {/* iOS Instructions - Enhanced */}
          {!isInstalled && isIOS && (
            <Card className="p-0 overflow-hidden border-2 border-blue-500/30">
              {/* iOS Header */}
              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-6 text-white">
                <div className="flex items-center gap-3">
                  <Apple className="w-8 h-8" />
                  <div>
                    <h2 className="text-xl font-bold">Install on iPhone</h2>
                    <p className="text-blue-100 text-sm">Follow these simple steps</p>
                  </div>
                </div>
              </div>
              
              {/* Steps */}
              <div className="p-6 space-y-4">
                {/* Step 1 - Safari Share */}
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="flex items-start gap-4 p-4 bg-blue-500/10 rounded-xl border border-blue-500/20"
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center text-lg font-bold">
                    1
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold mb-2">Tap the Share button</p>
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-background rounded-lg border">
                        <Share className="w-6 h-6 text-blue-500" />
                      </div>
                      <span className="text-sm text-muted-foreground">at the bottom of Safari</span>
                    </div>
                  </div>
                </motion.div>

                {/* Animated Arrow */}
                <motion.div 
                  animate={{ y: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="flex justify-center"
                >
                  <ArrowDown className="w-6 h-6 text-blue-500" />
                </motion.div>

                {/* Step 2 - Add to Home Screen */}
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex items-start gap-4 p-4 bg-blue-500/10 rounded-xl border border-blue-500/20"
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center text-lg font-bold">
                    2
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold mb-2">Tap "Add to Home Screen"</p>
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-background rounded-lg border">
                        <Plus className="w-6 h-6 text-blue-500" />
                      </div>
                      <span className="text-sm text-muted-foreground">scroll down in the menu</span>
                    </div>
                  </div>
                </motion.div>

                {/* Animated Arrow */}
                <motion.div 
                  animate={{ y: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
                  className="flex justify-center"
                >
                  <ArrowDown className="w-6 h-6 text-blue-500" />
                </motion.div>

                {/* Step 3 - Confirm */}
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex items-start gap-4 p-4 bg-green-500/10 rounded-xl border border-green-500/20"
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center text-lg font-bold">
                    3
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold mb-2">Tap "Add" in the top right</p>
                    <p className="text-sm text-muted-foreground">
                      Farion will appear on your home screen!
                    </p>
                  </div>
                </motion.div>

                {/* Safari Note */}
                <div className="p-4 bg-amber-500/10 rounded-lg border border-amber-500/20">
                  <p className="text-sm text-amber-600 dark:text-amber-400 flex items-center gap-2">
                    <Smartphone className="w-4 h-4" />
                    <strong>Important:</strong> This only works in Safari browser
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Desktop with Install Prompt */}
          {!isInstalled && !isIOS && !isAndroid && deferredPrompt && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <Button 
                onClick={handleInstallClick}
                size="lg"
                className="w-full h-16 text-lg gap-3 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg"
              >
                <Download className="w-6 h-6" />
                Install Farion Desktop App
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                Install as a desktop app for quick access
              </p>
            </motion.div>
          )}

          {/* Desktop without Install Prompt */}
          {!isInstalled && !isIOS && !isAndroid && !deferredPrompt && (
            <Card className="p-6">
              <h2 className="text-lg font-semibold mb-4 text-center">Install on Desktop</h2>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">1</span>
                  <span>Look for <Download className="w-4 h-4 inline" /> in the address bar</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">2</span>
                  <span>Click <strong className="bg-primary text-primary-foreground px-2 py-1 rounded">"Install"</strong></span>
                </div>
              </div>
            </Card>
          )}

          {/* Features - Enhanced */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-8 grid grid-cols-2 gap-3"
          >
            {[
              { icon: '⚡', text: 'Lightning fast' },
              { icon: '📴', text: 'Works offline' },
              { icon: '🔒', text: 'Secure & private' },
              { icon: '🔄', text: 'Auto updates' },
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <span className="text-lg">{feature.icon}</span>
                <span className="text-sm text-muted-foreground">{feature.text}</span>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
};

export default Install;
