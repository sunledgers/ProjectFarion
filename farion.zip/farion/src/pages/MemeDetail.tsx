import React, { useState, useCallback, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { 
  ArrowLeft, Gift, Coins, Clock, Shield, MessageCircle, 
  Send, Heart, User, Wallet 
} from 'lucide-react';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import WalletConnector from '@/components/chat/WalletConnector';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';

interface MemeUpload {
  id: string;
  wallet_address: string;
  username: string;
  filename: string;
  file_path: string;
  file_size: number;
  content_type: string;
  token_balance: number | null;
  supply_percentage: number | null;
  verification_status: string;
  created_at: string;
  donation_amount?: number;
}

interface MemeDonation {
  id: string;
  meme_id: string;
  donor_wallet: string;
  donor_username: string | null;
  recipient_wallet: string;
  amount: number;
  tx_signature: string | null;
  created_at: string;
}

interface MemeComment {
  id: string;
  meme_id: string;
  wallet_address: string;
  username: string | null;
  content: string;
  created_at: string;
}

const MemeDetail: React.FC = () => {
  const { memeId } = useParams<{ memeId: string }>();
  const navigate = useNavigate();
  const { connected, walletAddress, username, selectedWallet } = useMultiWallet();
  
  const [meme, setMeme] = useState<MemeUpload | null>(null);
  const [donations, setDonations] = useState<MemeDonation[]>([]);
  const [comments, setComments] = useState<MemeComment[]>([]);
  const [loading, setLoading] = useState(true);
  const [donationAmount, setDonationAmount] = useState([0.05]);
  const [donating, setDonating] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  // Load meme details
  const loadMeme = useCallback(async () => {
    if (!memeId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('meme_uploads')
        .select('*')
        .eq('id', memeId)
        .single();

      if (error) throw error;
      setMeme(data);
    } catch (error) {
      console.error('Error loading meme:', error);
      toast.error('Failed to load meme');
      navigate('/memes');
    } finally {
      setLoading(false);
    }
  }, [memeId, navigate]);

  // Load donations
  const loadDonations = useCallback(async () => {
    if (!memeId) return;
    
    try {
      const { data, error } = await supabase
        .from('meme_donations')
        .select('*')
        .eq('meme_id', memeId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDonations(data || []);
    } catch (error) {
      console.error('Error loading donations:', error);
    }
  }, [memeId]);

  // Load comments
  const loadComments = useCallback(async () => {
    if (!memeId) return;
    
    try {
      const { data, error } = await supabase
        .from('meme_comments')
        .select('*')
        .eq('meme_id', memeId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setComments(data || []);
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  }, [memeId]);

  useEffect(() => {
    loadMeme();
    loadDonations();
    loadComments();
  }, [loadMeme, loadDonations, loadComments]);

  // Subscribe to realtime updates
  useEffect(() => {
    if (!memeId) return;

    const donationsChannel = supabase
      .channel('meme-donations')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'meme_donations', filter: `meme_id=eq.${memeId}` },
        (payload) => {
          setDonations(prev => [payload.new as MemeDonation, ...prev]);
        }
      )
      .subscribe();

    const commentsChannel = supabase
      .channel('meme-comments')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'meme_comments', filter: `meme_id=eq.${memeId}` },
        (payload) => {
          setComments(prev => [...prev, payload.new as MemeComment]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(donationsChannel);
      supabase.removeChannel(commentsChannel);
    };
  }, [memeId]);

  // Donate to meme creator
  const handleDonate = async () => {
    if (!connected || !walletAddress || !selectedWallet?.adapter || !meme) {
      toast.error('Please connect your wallet first');
      return;
    }

    if (donationAmount[0] <= 0) {
      toast.error('Please select a donation amount');
      return;
    }

    if (walletAddress === meme.wallet_address) {
      toast.error('You cannot donate to your own meme');
      return;
    }

    setDonating(true);
    try {
      const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186', 'confirmed');
      const fromPubkey = new PublicKey(walletAddress);
      const toPubkey = new PublicKey(meme.wallet_address); // Send to meme creator
      const lamports = Math.floor(donationAmount[0] * LAMPORTS_PER_SOL);

      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey,
          toPubkey,
          lamports,
        })
      );

      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
      transaction.recentBlockhash = blockhash;
      transaction.feePayer = fromPubkey;

      let signature: string;
      if ('sendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.sendTransaction === 'function') {
        signature = await selectedWallet.adapter.sendTransaction(transaction, connection);
      } else if ('signTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signTransaction === 'function') {
        const signedTx = await selectedWallet.adapter.signTransaction(transaction);
        signature = await connection.sendRawTransaction(signedTx.serialize());
      } else {
        throw new Error('Wallet does not support transaction signing');
      }

      await connection.confirmTransaction({ signature, blockhash, lastValidBlockHeight }, 'confirmed');

      // Record donation in database
      const { error: dbError } = await supabase
        .from('meme_donations')
        .insert({
          meme_id: memeId,
          donor_wallet: walletAddress,
          donor_username: username,
          recipient_wallet: meme.wallet_address,
          amount: donationAmount[0],
          tx_signature: signature
        });

      if (dbError) throw dbError;

      toast.success(`Donated ${donationAmount[0]} SOL to ${meme.username}!`);
      setDonationAmount([0.05]);
    } catch (error: any) {
      console.error('Donation error:', error);
      if (error.message?.includes('User rejected')) {
        toast.error('Transaction cancelled');
      } else {
        toast.error('Failed to send donation');
      }
    } finally {
      setDonating(false);
    }
  };

  // Submit comment
  const handleSubmitComment = async () => {
    if (!connected || !walletAddress) {
      toast.error('Please connect your wallet to comment');
      return;
    }

    if (!commentText.trim()) {
      toast.error('Please enter a comment');
      return;
    }

    if (commentText.length > 500) {
      toast.error('Comment must be less than 500 characters');
      return;
    }

    setSubmittingComment(true);
    try {
      const { error } = await supabase
        .from('meme_comments')
        .insert({
          meme_id: memeId,
          wallet_address: walletAddress,
          username: username,
          content: commentText.trim()
        });

      if (error) throw error;

      toast.success('Comment posted!');
      setCommentText('');
    } catch (error) {
      console.error('Comment error:', error);
      toast.error('Failed to post comment');
    } finally {
      setSubmittingComment(false);
    }
  };

  const getImageUrl = (filePath: string) => {
    try {
      const { data } = supabase.storage.from('memes').getPublicUrl(filePath);
      return data.publicUrl;
    } catch (error) {
      console.error('Error generating image URL:', error);
      return '/placeholder.svg';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatShortDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getVerificationBadge = (status: string, percentage: number | null) => {
    if (!percentage || percentage === 0) {
      return <Badge variant="outline">No Tokens</Badge>;
    }
    if (percentage > 1) {
      return <Badge className="bg-yellow-500 text-black">Whale 🐋</Badge>;
    }
    if (percentage > 0.1) {
      return <Badge variant="default">Diamond Hands 💎</Badge>;
    }
    return <Badge variant="secondary">Holder 🚀</Badge>;
  };

  const totalDonations = donations.reduce((sum, d) => sum + Number(d.amount), 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="flex items-center justify-center pt-20">
          <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  if (!meme) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="flex items-center justify-center pt-20">
          <Card className="p-6">
            <p>Meme not found</p>
            <Button onClick={() => navigate('/memes')} className="mt-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Gallery
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="p-4 md:p-8 pt-20">
        <div className="max-w-6xl mx-auto">
          {/* Back Button */}
          <Button 
            variant="ghost" 
            onClick={() => navigate('/memes')} 
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Gallery
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Image */}
            <div className="lg:col-span-2">
              <Card className="overflow-hidden">
                <div className="aspect-auto max-h-[70vh] overflow-hidden bg-muted">
                  <img
                    src={getImageUrl(meme.file_path)}
                    alt={meme.filename}
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      e.currentTarget.src = '/placeholder.svg';
                    }}
                  />
                </div>
              </Card>

              {/* Comments Section */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Comments ({comments.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Comment Input */}
                  {connected ? (
                    <div className="flex gap-2">
                      <Textarea
                        placeholder="Write a comment..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        className="flex-1 min-h-[60px]"
                        maxLength={500}
                      />
                      <Button 
                        onClick={handleSubmitComment}
                        disabled={submittingComment || !commentText.trim()}
                        size="icon"
                        className="h-[60px] w-[60px]"
                      >
                        {submittingComment ? (
                          <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground mb-2">Connect wallet to comment</p>
                      <WalletConnector />
                    </div>
                  )}

                  {/* Comments List */}
                  <div className="space-y-3 max-h-[400px] overflow-y-auto">
                    {comments.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        No comments yet. Be the first!
                      </p>
                    ) : (
                      comments.map((comment) => (
                        <div key={comment.id} className="p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center gap-2 mb-1">
                            <User className="h-3 w-3 text-muted-foreground" />
                            <span className="font-medium text-sm">
                              {comment.username || `${comment.wallet_address.slice(0, 6)}...${comment.wallet_address.slice(-4)}`}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {formatShortDate(comment.created_at)}
                            </span>
                          </div>
                          <p className="text-sm">{comment.content}</p>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Creator Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Creator
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{meme.username}</span>
                    {getVerificationBadge(meme.verification_status, meme.supply_percentage)}
                  </div>
                  <div className="text-xs text-muted-foreground font-mono">
                    {meme.wallet_address.slice(0, 12)}...{meme.wallet_address.slice(-8)}
                  </div>
                  {meme.supply_percentage && meme.supply_percentage > 0 && (
                    <div className="text-sm text-muted-foreground">
                      Holds {meme.supply_percentage.toFixed(4)}% of supply
                    </div>
                  )}
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatDate(meme.created_at)}
                  </div>
                </CardContent>
              </Card>

              {/* Donation Card */}
              <Card className="border-pink-500/30 bg-gradient-to-br from-pink-500/5 to-orange-500/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-pink-500" />
                    Support Creator
                  </CardTitle>
                  <CardDescription>
                    Send SOL directly to {meme.username}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {connected ? (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Donation Amount</span>
                        <Badge variant="outline" className="font-mono">
                          <Coins className="h-3 w-3 mr-1" />
                          {donationAmount[0].toFixed(2)} SOL
                        </Badge>
                      </div>
                      <Slider
                        value={donationAmount}
                        onValueChange={setDonationAmount}
                        min={0.01}
                        max={2}
                        step={0.01}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>0.01</span>
                        <span>0.5</span>
                        <span>1</span>
                        <span>2 SOL</span>
                      </div>
                      <Button
                        onClick={handleDonate}
                        disabled={donating || walletAddress === meme.wallet_address}
                        className="w-full bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600"
                      >
                        {donating ? (
                          <>
                            <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                            Sending...
                          </>
                        ) : (
                          <>
                            <Gift className="h-4 w-4 mr-2" />
                            Donate {donationAmount[0]} SOL
                          </>
                        )}
                      </Button>
                      {walletAddress === meme.wallet_address && (
                        <p className="text-xs text-center text-muted-foreground">
                          This is your meme
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-3">
                        Connect wallet to donate
                      </p>
                      <WalletConnector />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Donation Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Coins className="h-5 w-5 text-yellow-500" />
                    Total Donations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-yellow-500 mb-4">
                    {totalDonations.toFixed(3)} SOL
                  </div>
                  
                  {donations.length > 0 && (
                    <div className="space-y-2 max-h-[200px] overflow-y-auto">
                      <p className="text-sm font-medium text-muted-foreground mb-2">
                        Recent Donations
                      </p>
                      {donations.slice(0, 10).map((donation) => (
                        <div 
                          key={donation.id} 
                          className="flex items-center justify-between text-sm p-2 rounded bg-muted/50"
                        >
                          <span className="truncate max-w-[100px]">
                            {donation.donor_username || `${donation.donor_wallet.slice(0, 6)}...`}
                          </span>
                          <Badge variant="outline" className="text-yellow-500">
                            {Number(donation.amount).toFixed(2)} SOL
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {donations.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      Be the first to donate!
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemeDetail;
