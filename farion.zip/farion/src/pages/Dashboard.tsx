import React, { useState, useEffect, useCallback } from 'react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import WalletConnector from '@/components/chat/WalletConnector';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  Trophy, 
  Image as ImageIcon, 
  MessageSquare, 
  TrendingUp,
  Clock,
  Coins,
  Copy,
  Check,
  RefreshCw,
  Zap,
  Target,
  Gift
} from 'lucide-react';
import { toast } from 'sonner';

interface ActivityItem {
  id: string;
  activity_type: string;
  details: any;
  amount: number | null;
  created_at: string;
}

interface DashboardStats {
  jackpotParticipations: number;
  jackpotWins: number;
  memeUploads: number;
  forumPosts: number;
  totalWinnings: number;
}

const Dashboard = () => {
  const { connected, walletAddress, username, tokenBalance, balanceLoading, refreshBalance } = useMultiWallet();
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    jackpotParticipations: 0,
    jackpotWins: 0,
    memeUploads: 0,
    forumPosts: 0,
    totalWinnings: 0
  });
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const loadDashboardData = useCallback(async () => {
    if (!walletAddress) return;
    
    setLoading(true);
    try {
      // Load jackpot participations
      const { data: jackpotData, count: jackpotCount } = await supabase
        .from('jackpot_participants')
        .select('*', { count: 'exact' })
        .eq('wallet_address', walletAddress);

      // Load jackpot wins
      const { data: winsData, count: winsCount } = await supabase
        .from('jackpot_winners')
        .select('*', { count: 'exact' })
        .eq('wallet_address', walletAddress);

      const totalWinnings = winsData?.reduce((sum, win) => sum + Number(win.amount || 0), 0) || 0;

      // Load meme uploads
      const { count: memeCount } = await supabase
        .from('meme_uploads')
        .select('*', { count: 'exact' })
        .eq('wallet_address', walletAddress);

      // Load forum posts
      const { count: postCount } = await supabase
        .from('forum_posts')
        .select('*', { count: 'exact' })
        .eq('wallet_address', walletAddress);

      // Load recent activities
      const { data: activityData } = await supabase
        .from('user_activity_log')
        .select('*')
        .eq('wallet_address', walletAddress)
        .order('created_at', { ascending: false })
        .limit(20);

      setStats({
        jackpotParticipations: jackpotCount || 0,
        jackpotWins: winsCount || 0,
        memeUploads: memeCount || 0,
        forumPosts: postCount || 0,
        totalWinnings
      });

      setActivities(activityData || []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, [walletAddress]);

  useEffect(() => {
    if (connected && walletAddress) {
      loadDashboardData();
    }
  }, [connected, walletAddress, loadDashboardData]);

  const copyAddress = () => {
    if (walletAddress) {
      navigator.clipboard.writeText(walletAddress);
      setCopied(true);
      toast.success('Address copied!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'jackpot_join': return <Target className="h-4 w-4 text-orange-500" />;
      case 'jackpot_win': return <Trophy className="h-4 w-4 text-yellow-500" />;
      case 'meme_upload': return <ImageIcon className="h-4 w-4 text-purple-500" />;
      case 'forum_post': return <MessageSquare className="h-4 w-4 text-blue-500" />;
      case 'donation': return <Gift className="h-4 w-4 text-pink-500" />;
      default: return <Zap className="h-4 w-4 text-muted-foreground" />;
    }
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="flex items-center justify-center pt-20 px-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="h-5 w-5" />
                User Dashboard
              </CardTitle>
              <CardDescription>
                Connect your wallet to view your dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WalletConnector />
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      <main className="container mx-auto px-4 py-8 pt-20 sm:pt-8 sm:ml-64 lg:ml-72">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                Welcome, {username}
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-sm text-muted-foreground font-mono">
                  {walletAddress?.slice(0, 6)}...{walletAddress?.slice(-4)}
                </span>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={copyAddress}>
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                </Button>
              </div>
            </div>
            
            <Button variant="outline" onClick={refreshBalance} disabled={balanceLoading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${balanceLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          {/* Holdings Overview */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Coins className="h-5 w-5 text-blue-500" />
                  <span className="text-sm text-muted-foreground">FARION Balance</span>
                </div>
                <p className="text-2xl font-bold">
                  {tokenBalance?.tokenBalance?.toLocaleString() || '0'} FARION
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="h-5 w-5 text-orange-500" />
                  <span className="text-sm text-muted-foreground">Jackpot Plays</span>
                </div>
                <p className="text-2xl font-bold">{stats.jackpotParticipations}</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  <span className="text-sm text-muted-foreground">Total Winnings</span>
                </div>
                <p className="text-2xl font-bold text-green-500">
                  {stats.totalWinnings.toFixed(3)} SOL
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <ImageIcon className="h-5 w-5 text-purple-500" />
                  <span className="text-sm text-muted-foreground">Memes Uploaded</span>
                </div>
                <p className="text-2xl font-bold">{stats.memeUploads}</p>
              </CardContent>
            </Card>
          </div>

          {/* Stats & Activity Tabs */}
          <Tabs defaultValue="stats" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2 max-w-md">
              <TabsTrigger value="stats">Statistics</TabsTrigger>
              <TabsTrigger value="activity">Recent Activity</TabsTrigger>
            </TabsList>

            <TabsContent value="stats">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Jackpot Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-orange-500" />
                      Jackpot Statistics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Rounds Played</span>
                      <Badge variant="secondary">{stats.jackpotParticipations}</Badge>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Wins</span>
                      <Badge className="bg-yellow-500/20 text-yellow-600">{stats.jackpotWins}</Badge>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Win Rate</span>
                      <Badge variant="outline">
                        {stats.jackpotParticipations > 0 
                          ? ((stats.jackpotWins / stats.jackpotParticipations) * 100).toFixed(1)
                          : 0}%
                      </Badge>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Winnings</span>
                      <span className="font-bold text-green-500">{stats.totalWinnings.toFixed(3)} SOL</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Community Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-blue-500" />
                      Community Engagement
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Memes Uploaded</span>
                      <Badge variant="secondary">{stats.memeUploads}</Badge>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Forum Posts</span>
                      <Badge variant="secondary">{stats.forumPosts}</Badge>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Member Since</span>
                      <Badge variant="outline">Active</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="activity">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Your latest actions on the platform</CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="animate-pulse flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                          <div className="h-8 w-8 bg-muted rounded-full" />
                          <div className="flex-1 space-y-2">
                            <div className="h-4 bg-muted rounded w-3/4" />
                            <div className="h-3 bg-muted rounded w-1/2" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : activities.length === 0 ? (
                    <div className="text-center py-8">
                      <Zap className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                      <p className="text-muted-foreground">No activity yet</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Start playing games and engaging with the community!
                      </p>
                    </div>
                  ) : (
                    <ScrollArea className="h-[400px]">
                      <div className="space-y-3">
                        {activities.map((activity) => (
                          <motion.div
                            key={activity.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg"
                          >
                            <div className="h-8 w-8 rounded-full bg-background flex items-center justify-center">
                              {getActivityIcon(activity.activity_type)}
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-sm capitalize">
                                {activity.activity_type.replace(/_/g, ' ')}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatDate(activity.created_at)}
                              </p>
                            </div>
                            {activity.amount && (
                              <Badge variant="outline" className="font-mono">
                                {activity.amount} SOL
                              </Badge>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;