import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Coins, Clock, ArrowLeft, Droplets } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useAukBalance } from '@/hooks/useAukBalance';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

const AukFaucet: React.FC = () => {
  const { connected, walletAddress, username } = useMultiWallet();
  const { aukBalance, canClaim, nextClaimAt, loading, claimAuk } = useAukBalance(walletAddress, username);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleClaim = async () => {
    const success = await claimAuk();
    if (success) {
      toast({
        title: "Claim successful!",
        description: "You've received 5 $FARION tokens",
      });
    } else {
      toast({
        title: "Claim failed",
        description: "There was an error claiming your $FARION tokens",
        variant: "destructive"
      });
    }
  };

  const formatTimeUntilNextClaim = (nextClaim: Date | null): string => {
    if (!nextClaim) return '';
    
    const now = new Date();
    const diff = nextClaim.getTime() - now.getTime();
    
    if (diff <= 0) return 'Available now';
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-md mx-auto text-center">
            <Card>
              <CardHeader>
                <div className="mx-auto mb-4 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Droplets className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>$FARION Faucet</CardTitle>
                <CardDescription>
                  Connect your wallet to claim free $FARION tokens
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={() => navigate('/launchpad')} className="w-full">
                  Connect Wallet
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/launchpad')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">$FARION Faucet</h1>
              <p className="text-muted-foreground">
                Claim free $FARION tokens every 24 hours
              </p>
            </div>
          </div>

          {/* Faucet Card */}
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <Droplets className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="flex items-center justify-center gap-2">
                <Coins className="h-5 w-5" />
                Free $FARION Tokens
              </CardTitle>
              <CardDescription>
                Get 5 $FARION tokens every 24 hours to trade on the Launchpad
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Balance */}
              <div className="text-center">
                <div className="text-sm font-medium text-muted-foreground mb-2">
                  Your Current Balance
                </div>
                  <div className="text-3xl font-bold flex items-center justify-center gap-2">
                    <Coins className="h-6 w-6" />
                    {aukBalance.toFixed(2)} $FARION
                </div>
                <div className="text-sm text-muted-foreground">
                  ≈ ${(aukBalance * 180).toLocaleString()} USD value
                </div>
              </div>

              {/* Claim Status */}
              <div className="bg-muted/50 rounded-lg p-4 text-center">
                {canClaim ? (
                  <div className="space-y-3">
                    <Badge variant="secondary" className="mb-2">
                      Ready to claim
                    </Badge>
                    <div className="text-lg font-semibold">
                      5 $FARION tokens available
                    </div>
                    <Button
                      onClick={handleClaim}
                      disabled={loading}
                      className="w-full"
                      size="lg"
                    >
                      <Droplets className="h-4 w-4 mr-2" />
                      {loading ? 'Claiming...' : 'Claim 5 $FARION'}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Badge variant="outline" className="mb-2">
                      <Clock className="h-3 w-3 mr-1" />
                      Cooldown active
                    </Badge>
                    <div className="text-lg font-semibold">
                      Next claim in {formatTimeUntilNextClaim(nextClaimAt)}
                    </div>
                    <Button
                      disabled
                      className="w-full"
                      size="lg"
                    >
                      <Clock className="h-4 w-4 mr-2" />
                      Wait for cooldown
                    </Button>
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="text-center space-y-2 text-sm text-muted-foreground">
                <p>• Claim 5 $FARION tokens every 24 hours</p>
                <p>• Use $FARION to buy and sell tokens on the Launchpad</p>
                <p>• $1 FARION = $180 trading value</p>
              </div>
            </CardContent>
          </Card>

          {/* How to Use */}
          <Card>
            <CardHeader>
              <CardTitle>How to Use $FARION</CardTitle>
              <CardDescription>
                Learn how to make the most of your $AUK tokens
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-sm font-medium">
                    1
                  </div>
                  <div>
                    <div className="font-medium">Claim Your Tokens</div>
                    <div className="text-sm text-muted-foreground">
                      Visit this faucet every 24 hours to claim 5 free $FARION tokens
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-sm font-medium">
                    2
                  </div>
                  <div>
                    <div className="font-medium">Browse Tokens</div>
                    <div className="text-sm text-muted-foreground">
                      Explore tokens created on the Launchpad and find ones you're interested in
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-sm font-medium">
                    3
                  </div>
                  <div>
                    <div className="font-medium">Trade & Invest</div>
                    <div className="text-sm text-muted-foreground">
                      Use your $FARION to buy tokens early and potentially profit as market caps grow
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AukFaucet;