import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ADMIN_WALLET, ESCROW_WALLET, PLATFORM_FEE_WALLET } from '@/config/wallets';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Users, 
  DollarSign,
  Clock,
  ExternalLink,
  ArrowLeft,
  Coins,
  TrendingUp,
  Rocket
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

interface DisputedTrade {
  id: string;
  seller_wallet: string;
  seller_username: string | null;
  buyer_wallet: string | null;
  buyer_username: string | null;
  sol_amount: number;
  fiat_amount: number;
  fiat_currency: string;
  escrow_status: string;
  disputed_by: string | null;
  dispute_reason: string | null;
  dispute_raised_at: string | null;
  created_at: string;
  escrow_tx_signature: string | null;
}

interface PlatformFee {
  id: string;
  amount: number;
  fee_type: string;
  wallet_address: string;
  tx_signature: string | null;
  created_at: string;
  token_id: string | null;
}

interface AdminStats {
  totalDisputed: number;
  totalPendingLoans: number;
  totalSOLInEscrow: number;
  totalPlatformFees: number;
  tokenCreationFees: number;
  tradingFees: number;
}

const AdminPanel = () => {
  const { walletAddress, connected } = useMultiWallet();
  const { toast } = useToast();
  const [disputedTrades, setDisputedTrades] = useState<DisputedTrade[]>([]);
  const [platformFees, setPlatformFees] = useState<PlatformFee[]>([]);
  const [adminStats, setAdminStats] = useState<AdminStats>({
    totalDisputed: 0,
    totalPendingLoans: 0,
    totalSOLInEscrow: 0,
    totalPlatformFees: 0,
    tokenCreationFees: 0,
    tradingFees: 0
  });
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState<string>('');

  const isAdmin = walletAddress === ADMIN_WALLET;

  useEffect(() => {
    if (isAdmin) {
      loadAdminData();
    }
  }, [isAdmin]);

  const loadAdminData = async () => {
    try {
      // Load disputed trades
      const { data: trades, error: tradesError } = await supabase
        .from('p2p_trades')
        .select('*')
        .eq('escrow_status', 'disputed')
        .order('dispute_raised_at', { ascending: false });

      if (tradesError) throw tradesError;
      setDisputedTrades(trades || []);

      // Load platform fees
      const { data: fees, error: feesError } = await supabase
        .from('platform_fees')
        .select('*')
        .order('created_at', { ascending: false });

      if (feesError) throw feesError;
      setPlatformFees(fees || []);

      // Load stats
      const { data: allTrades } = await supabase
        .from('p2p_trades')
        .select('sol_amount, escrow_status');

      const { data: pendingLoans } = await supabase
        .from('loans')
        .select('*')
        .eq('status', 'pending');

      const lockedTrades = allTrades?.filter(t => 
        ['locked', 'seller_confirmed', 'buyer_confirmed', 'disputed'].includes(t.escrow_status)
      ) || [];

      const totalEscrow = lockedTrades.reduce((sum, t) => sum + Number(t.sol_amount), 0);

      // Calculate fee stats
      const totalPlatformFees = fees?.reduce((sum, f) => sum + Number(f.amount), 0) || 0;
      const tokenCreationFees = fees?.filter(f => f.fee_type === 'token_creation').reduce((sum, f) => sum + Number(f.amount), 0) || 0;
      const tradingFees = fees?.filter(f => f.fee_type === 'sell_fee' || f.fee_type === 'buy_fee').reduce((sum, f) => sum + Number(f.amount), 0) || 0;

      setAdminStats({
        totalDisputed: trades?.length || 0,
        totalPendingLoans: pendingLoans?.length || 0,
        totalSOLInEscrow: totalEscrow,
        totalPlatformFees,
        tokenCreationFees,
        tradingFees
      });
    } catch (error) {
      console.error('Error loading admin data:', error);
      toast({
        title: "Error",
        description: "Failed to load admin data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const resolveForSeller = async (tradeId: string) => {
    setProcessingId(tradeId);
    try {
      await supabase.from('p2p_trades').update({
        escrow_status: 'cancelled',
        completed_at: new Date().toISOString()
      }).eq('id', tradeId);

      toast({
        title: "Resolved for Seller",
        description: "Trade cancelled. SOL should be released back to seller from escrow wallet."
      });

      loadAdminData();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to resolve dispute",
        variant: "destructive"
      });
    } finally {
      setProcessingId(null);
    }
  };

  const resolveForBuyer = async (tradeId: string) => {
    setProcessingId(tradeId);
    try {
      await supabase.from('p2p_trades').update({
        escrow_status: 'completed',
        seller_confirmed: true,
        buyer_confirmed: true,
        completed_at: new Date().toISOString()
      }).eq('id', tradeId);

      toast({
        title: "Resolved for Buyer",
        description: "Trade completed. SOL should be released to buyer from escrow wallet."
      });

      loadAdminData();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to resolve dispute",
        variant: "destructive"
      });
    } finally {
      setProcessingId(null);
    }
  };

  const cancelTrade = async (tradeId: string) => {
    setProcessingId(tradeId);
    try {
      await supabase.from('p2p_trades').update({
        escrow_status: 'cancelled',
        completed_at: new Date().toISOString()
      }).eq('id', tradeId);

      toast({
        title: "Trade Cancelled",
        description: "Trade has been cancelled. SOL should be returned to seller."
      });

      loadAdminData();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to cancel trade",
        variant: "destructive"
      });
    } finally {
      setProcessingId(null);
    }
  };

  // Access denied view
  if (!connected || !isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-8 sm:ml-80">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center min-h-[60vh]"
          >
            <Card className="max-w-md w-full text-center p-8">
              <Shield className="h-16 w-16 mx-auto text-destructive mb-4" />
              <h1 className="text-2xl font-bold text-foreground mb-2">Access Denied</h1>
              <p className="text-muted-foreground mb-4">
                {!connected 
                  ? "Please connect your wallet to access the admin panel."
                  : "This area is restricted to admin wallets only."}
              </p>
              <Link to="/">
                <Button variant="outline">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Return Home
                </Button>
              </Link>
            </Card>
          </motion.div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      <div className="container mx-auto px-4 py-8 sm:ml-80">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header */}
          <div className="flex items-center gap-4">
            <Shield className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-foreground">Admin Panel</h1>
              <p className="text-muted-foreground">Manage P2P disputes and escrow</p>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <Card className="bg-destructive/10 border-destructive/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <AlertTriangle className="h-10 w-10 text-destructive" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{adminStats.totalDisputed}</p>
                    <p className="text-sm text-muted-foreground">Active Disputes</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-warning/10 border-warning/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <Clock className="h-10 w-10 text-warning" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{adminStats.totalPendingLoans}</p>
                    <p className="text-sm text-muted-foreground">Pending Loans</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary/10 border-primary/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <DollarSign className="h-10 w-10 text-primary" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{adminStats.totalSOLInEscrow.toFixed(2)} SOL</p>
                    <p className="text-sm text-muted-foreground">In Escrow</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-green-500/10 border-green-500/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <Coins className="h-10 w-10 text-green-500" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{adminStats.totalPlatformFees.toFixed(4)} SOL</p>
                    <p className="text-sm text-muted-foreground">Total Fees</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-500/10 border-blue-500/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <Rocket className="h-10 w-10 text-blue-500" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{adminStats.tokenCreationFees.toFixed(4)} SOL</p>
                    <p className="text-sm text-muted-foreground">Creation Fees</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-500/10 border-purple-500/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <TrendingUp className="h-10 w-10 text-purple-500" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{adminStats.tradingFees.toFixed(4)} SOL</p>
                    <p className="text-sm text-muted-foreground">Trading Fees</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Escrow Wallet Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Escrow Wallet
              </CardTitle>
              <CardDescription>
                All P2P trades and loans use this escrow wallet
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 bg-accent/20 rounded-lg">
                <code className="text-sm font-mono">{ESCROW_WALLET}</code>
                <a 
                  href={`https://solscan.io/account/${ESCROW_WALLET}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="outline" size="sm">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View on Solscan
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>

          {/* Tabs for different sections */}
          <Tabs defaultValue="fees" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="fees" className="flex items-center gap-2">
                <Coins className="h-4 w-4" />
                Platform Fees
              </TabsTrigger>
              <TabsTrigger value="disputes" className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Disputes
              </TabsTrigger>
            </TabsList>

            {/* Platform Fees Tab */}
            <TabsContent value="fees" className="space-y-4 mt-4">
              {/* Platform Fee Wallet Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Coins className="h-5 w-5 text-green-500" />
                    Platform Fee Wallet
                  </CardTitle>
                  <CardDescription>
                    All token creation and trading fees are sent to this wallet
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between p-4 bg-accent/20 rounded-lg">
                    <code className="text-sm font-mono">{PLATFORM_FEE_WALLET}</code>
                    <a 
                      href={`https://solscan.io/account/${PLATFORM_FEE_WALLET}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View on Solscan
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Fee History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Fee Collection History
                  </CardTitle>
                  <CardDescription>
                    All platform fees collected from token launches and trading
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="text-center py-8 text-muted-foreground">Loading...</div>
                  ) : platformFees.length === 0 ? (
                    <div className="text-center py-8">
                      <Coins className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                      <p className="text-muted-foreground">No fees collected yet</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      <div className="grid grid-cols-5 gap-4 p-3 bg-muted/50 rounded-lg text-sm font-medium text-muted-foreground">
                        <span>Type</span>
                        <span>Amount</span>
                        <span>Wallet</span>
                        <span>Date</span>
                        <span>TX</span>
                      </div>
                      {platformFees.map((fee) => (
                        <div key={fee.id} className="grid grid-cols-5 gap-4 p-3 bg-card rounded-lg border text-sm items-center">
                          <Badge 
                            variant={fee.fee_type === 'token_creation' ? 'default' : 'secondary'}
                            className="w-fit"
                          >
                            {fee.fee_type === 'token_creation' ? 'Creation' : 
                             fee.fee_type === 'sell_fee' ? 'Sell Fee' : 
                             fee.fee_type === 'buy_fee' ? 'Buy Fee' : fee.fee_type}
                          </Badge>
                          <span className="font-mono font-bold text-green-500">
                            {Number(fee.amount).toFixed(4)} SOL
                          </span>
                          <code className="text-xs text-muted-foreground truncate">
                            {fee.wallet_address.slice(0, 6)}...{fee.wallet_address.slice(-4)}
                          </code>
                          <span className="text-muted-foreground">
                            {new Date(fee.created_at).toLocaleDateString()}
                          </span>
                          {fee.tx_signature ? (
                            <a 
                              href={`https://solscan.io/tx/${fee.tx_signature}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-primary hover:underline flex items-center gap-1"
                            >
                              View <ExternalLink className="h-3 w-3" />
                            </a>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Disputes Tab */}
            <TabsContent value="disputes" className="space-y-4 mt-4">
              {/* Escrow Wallet Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Escrow Wallet
                  </CardTitle>
                  <CardDescription>
                    All P2P trades and loans use this escrow wallet
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between p-4 bg-accent/20 rounded-lg">
                    <code className="text-sm font-mono">{ESCROW_WALLET}</code>
                    <a 
                      href={`https://solscan.io/account/${ESCROW_WALLET}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View on Solscan
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Disputed Trades */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                    Disputed P2P Trades
                  </CardTitle>
                  <CardDescription>
                    Resolve disputes by releasing SOL to the appropriate party
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="text-center py-8 text-muted-foreground">Loading...</div>
                  ) : disputedTrades.length === 0 ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-2" />
                      <p className="text-muted-foreground">No active disputes</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {disputedTrades.map((trade) => (
                        <Card key={trade.id} className="border-destructive/30 bg-destructive/5">
                          <CardContent className="p-4">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                              {/* Trade Details */}
                              <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                  <Badge variant="destructive">DISPUTED</Badge>
                                  <span className="text-xs text-muted-foreground">
                                    {trade.dispute_raised_at && new Date(trade.dispute_raised_at).toLocaleString()}
                                  </span>
                                </div>

                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  <div>
                                    <p className="text-muted-foreground">Amount</p>
                                    <p className="font-bold text-lg">{trade.sol_amount} SOL</p>
                                    <p className="text-muted-foreground">
                                      ≈ {trade.fiat_amount} {trade.fiat_currency}
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-muted-foreground">Disputed By</p>
                                    <p className="font-medium">
                                      {trade.disputed_by === trade.seller_wallet ? 'Seller' : 'Buyer'}
                                    </p>
                                  </div>
                                </div>

                                <div className="text-sm">
                                  <p className="text-muted-foreground">Seller</p>
                                  <p className="font-medium">{trade.seller_username || 'Anonymous'}</p>
                                  <code className="text-xs text-muted-foreground">
                                    {trade.seller_wallet.slice(0, 8)}...{trade.seller_wallet.slice(-8)}
                                  </code>
                                </div>

                                <div className="text-sm">
                                  <p className="text-muted-foreground">Buyer</p>
                                  <p className="font-medium">{trade.buyer_username || 'Anonymous'}</p>
                                  <code className="text-xs text-muted-foreground">
                                    {trade.buyer_wallet?.slice(0, 8)}...{trade.buyer_wallet?.slice(-8)}
                                  </code>
                                </div>

                                {trade.dispute_reason && (
                                  <div className="text-sm">
                                    <p className="text-muted-foreground">Dispute Reason</p>
                                    <p className="bg-background/50 p-2 rounded text-foreground">
                                      {trade.dispute_reason}
                                    </p>
                                  </div>
                                )}

                                {trade.escrow_tx_signature && (
                                  <a 
                                    href={`https://solscan.io/tx/${trade.escrow_tx_signature}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-xs text-primary hover:underline flex items-center gap-1"
                                  >
                                    View Escrow TX <ExternalLink className="h-3 w-3" />
                                  </a>
                                )}
                              </div>

                              {/* Resolution Actions */}
                              <div className="space-y-3 flex flex-col justify-center">
                                <p className="text-sm font-medium text-foreground">Resolution Actions</p>
                                
                                <Button
                                  onClick={() => resolveForSeller(trade.id)}
                                  disabled={processingId === trade.id}
                                  variant="outline"
                                  className="w-full justify-start"
                                >
                                  <XCircle className="h-4 w-4 mr-2 text-orange-500" />
                                  Resolve for Seller (Return SOL)
                                </Button>

                                <Button
                                  onClick={() => resolveForBuyer(trade.id)}
                                  disabled={processingId === trade.id}
                                  variant="outline"
                                  className="w-full justify-start"
                                >
                                  <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                                  Resolve for Buyer (Release SOL)
                                </Button>

                                <Button
                                  onClick={() => cancelTrade(trade.id)}
                                  disabled={processingId === trade.id}
                                  variant="destructive"
                                  className="w-full justify-start"
                                >
                                  <XCircle className="h-4 w-4 mr-2" />
                                  Cancel Trade
                                </Button>

                                <p className="text-xs text-muted-foreground mt-2">
                                  After resolving, manually transfer SOL from escrow wallet to the winner.
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Instructions */}
              <Card>
                <CardHeader>
                  <CardTitle>Dispute Resolution Guide</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm text-muted-foreground">
                  <div className="flex gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shrink-0">1</span>
                    <p>Review the dispute reason and transaction history carefully.</p>
                  </div>
                  <div className="flex gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shrink-0">2</span>
                    <p>Contact both parties if needed for additional information.</p>
                  </div>
                  <div className="flex gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shrink-0">3</span>
                    <p>Click the appropriate resolution button to update the trade status.</p>
                  </div>
                  <div className="flex gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shrink-0">4</span>
                    <p>Manually transfer SOL from the escrow wallet ({ESCROW_WALLET.slice(0, 8)}...) to the winner's wallet.</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
};

export default AdminPanel;
