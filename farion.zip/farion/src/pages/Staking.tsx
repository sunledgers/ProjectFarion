import React from 'react';
import { motion } from 'framer-motion';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import StakingPreview from '@/components/StakingPreview';
import WalletConnectionPrompt from '@/components/WalletConnectionPrompt';
import Footer from '@/components/Footer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, TrendingUp, Clock, Coins, Lock, Zap } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';

const stakingFeatures = [
  {
    icon: Shield,
    title: "Secure Staking",
    description: "Your tokens are secured by smart contracts with multiple security audits."
  },
  {
    icon: TrendingUp,
    title: "Competitive APY",
    description: "Earn up to 35% APY with our flexible lock periods and reward tiers."
  },
  {
    icon: Clock,
    title: "Flexible Periods",
    description: "Choose from 30, 60, 90, or 120-day lock periods to maximize your rewards."
  },
  {
    icon: Coins,
    title: "Auto-Compounding",
    description: "Rewards are automatically compounded to maximize your earning potential."
  },
  {
    icon: Lock,
    title: "No Hidden Fees",
    description: "Transparent staking with no hidden fees or unexpected charges."
  },
  {
    icon: Zap,
    title: "Instant Rewards",
    description: "Track your rewards in real-time and claim them whenever you want."
  }
];

const Staking = () => {
  const { connected } = useMultiWallet();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10">
      <UnifiedNavigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Stake Your $FARION Tokens
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Earn passive income by staking your $FARION tokens. Choose from flexible lock periods 
              and enjoy competitive APY rates while supporting the Farion ecosystem.
            </p>
            <div className="flex flex-wrap justify-center items-center gap-4 mb-8">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                Up to 35% APY
              </Badge>
              <Badge variant="outline" className="text-lg px-4 py-2">
                Multiple Lock Periods
              </Badge>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                Auto-Compounding
              </Badge>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Wallet Connection or Staking Pools */}
      {!connected ? (
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <WalletConnectionPrompt 
              title="Connect Wallet to Start Staking"
              description="Connect your wallet to stake $FARION tokens and earn rewards"
            />
          </div>
        </section>
      ) : (
        <StakingPreview />
      )}

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold mb-4">Why Stake with Farion?</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Our staking platform offers the best combination of security, rewards, and flexibility 
              in the crypto space.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stakingFeatures.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 bg-card/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <feature.icon className="w-6 h-6 text-primary" />
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center"
          >
            <div>
              <h3 className="text-3xl font-bold text-primary mb-2">28.7M</h3>
              <p className="text-muted-foreground">Total $FARION Staked</p>
            </div>
            <div>
              <h3 className="text-3xl font-bold text-primary mb-2">1,847</h3>
              <p className="text-muted-foreground">Active Stakers</p>
            </div>
            <div>
              <h3 className="text-3xl font-bold text-primary mb-2">2.1M</h3>
              <p className="text-muted-foreground">Rewards Distributed</p>
            </div>
            <div>
              <h3 className="text-3xl font-bold text-primary mb-2">99.7%</h3>
              <p className="text-muted-foreground">Uptime Guarantee</p>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Staking;