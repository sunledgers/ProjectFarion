import React from 'react';
import Hero from '@/components/Hero';
import GameFeatures from '@/components/GameFeatures';
import BlogNews from '@/components/BlogNews';
import Footer from '@/components/Footer';
import UnifiedNavigation from '@/components/UnifiedNavigation';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <UnifiedNavigation />
      <Hero />
      <GameFeatures />
      <BlogNews />
      <Footer />
    </div>
  );
};

export default Index;
