import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, ArrowLeft, Coins } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useTokenData, CreatedToken } from '@/hooks/useTokenData';
import { useAukBalance } from '@/hooks/useAukBalance';
import { useTokenTrading, AUK_USD_RATE } from '@/hooks/useTokenTrading';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { useToast } from '@/hooks/use-toast';

const TokenTrading: React.FC = () => {
  const { tokenId } = useParams<{ tokenId: string }>();
  const navigate = useNavigate();
  const { walletAddress, username, connected } = useMultiWallet();
  const { getTokenById } = useTokenData();
  const { aukBalance, refreshBalance } = useAukBalance(walletAddress, username);
  const { calculateTradeAmount, executeTrade, loading: tradeLoading } = useTokenTrading();
  const { toast } = useToast();
  
  const [token, setToken] = useState<CreatedToken | null>(null);
  const [loading, setLoading] = useState(true);
  const [buyAmount, setBuyAmount] = useState('');
  const [sellAmount, setSellAmount] = useState('');

  useEffect(() => {
    const fetchToken = async () => {
      if (!tokenId) return;
      
      const tokenData = await getTokenById(tokenId);
      setToken(tokenData);
      setLoading(false);
    };

    fetchToken();
  }, [tokenId, getTokenById]);

  const handleBuy = async () => {
    if (!token || !walletAddress || !username || !buyAmount) return;
    
    const amount = parseFloat(buyAmount);
    if (amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount to buy",
        variant: "destructive"
      });
      return;
    }

    const calculation = calculateTradeAmount(
      token.market_cap,
      token.current_supply,
      amount,
      token.tax_percentage,
      true
    );

    if (calculation.finalAukAmount > aukBalance) {
      toast({
        title: "Insufficient $AUK balance",
        description: `You need ${calculation.finalAukAmount.toFixed(2)} $AUK but only have ${aukBalance.toFixed(2)} $AUK`,
        variant: "destructive"
      });
      return;
    }

    const success = await executeTrade(
      token.id,
      walletAddress,
      username,
      amount,
      'buy',
      calculation
    );

    if (success) {
      toast({
        title: "Purchase successful!",
        description: `Bought ${amount} ${token.symbol} for ${calculation.finalAukAmount.toFixed(2)} $AUK`,
      });
      setBuyAmount('');
      setToken(prev => prev ? { ...prev, market_cap: calculation.newMarketCap } : null);
      refreshBalance();
    } else {
      toast({
        title: "Purchase failed",
        description: "There was an error processing your purchase",
        variant: "destructive"
      });
    }
  };

  const handleSell = async () => {
    if (!token || !walletAddress || !username || !sellAmount) return;
    
    const amount = parseFloat(sellAmount);
    if (amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount to sell",
        variant: "destructive"
      });
      return;
    }

    const calculation = calculateTradeAmount(
      token.market_cap,
      token.current_supply,
      amount,
      token.tax_percentage,
      false
    );

    const success = await executeTrade(
      token.id,
      walletAddress,
      username,
      amount,
      'sell',
      calculation
    );

    if (success) {
      toast({
        title: "Sale successful!",
        description: `Sold ${amount} ${token.symbol} for ${calculation.finalAukAmount.toFixed(2)} $AUK`,
      });
      setSellAmount('');
      setToken(prev => prev ? { ...prev, market_cap: calculation.newMarketCap } : null);
      refreshBalance();
    } else {
      toast({
        title: "Sale failed",
        description: "There was an error processing your sale",
        variant: "destructive"
      });
    }
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Connect your wallet to trade</h1>
            <Button onClick={() => navigate('/launchpad')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Launchpad
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="text-center">Loading token trading...</div>
        </div>
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Token not found</h1>
            <Button onClick={() => navigate('/launchpad')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Launchpad
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const currentPrice = token.market_cap / token.current_supply;
  const buyCalculation = buyAmount ? calculateTradeAmount(
    token.market_cap,
    token.current_supply,
    parseFloat(buyAmount) || 0,
    token.tax_percentage,
    true
  ) : null;

  const sellCalculation = sellAmount ? calculateTradeAmount(
    token.market_cap,
    token.current_supply,
    parseFloat(sellAmount) || 0,
    token.tax_percentage,
    false
  ) : null;

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/launchpad')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-4">
              {token.logo_url && (
                <img
                  src={token.logo_url}
                  alt={token.name}
                  className="w-12 h-12 rounded-full"
                />
              )}
              <div>
                <h1 className="text-2xl font-bold">{token.name}</h1>
                <p className="text-muted-foreground">{token.symbol}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Token Stats */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Token Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Current Price</span>
                  <div className="text-xl font-bold">${currentPrice.toFixed(6)}</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Market Cap</span>
                  <div className="text-xl font-bold">${token.market_cap.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Total Supply</span>
                  <div className="font-mono">{token.current_supply.toLocaleString()} {token.symbol}</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Tax Rate</span>
                  <div className="font-mono">{token.tax_percentage}%</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Your $AUK Balance</span>
                  <div className="text-lg font-bold flex items-center gap-2">
                    <Coins className="h-4 w-4" />
                    {aukBalance.toFixed(2)} $AUK
                  </div>
                  <div className="text-xs text-muted-foreground">
                    ≈ ${(aukBalance * AUK_USD_RATE).toLocaleString()} USD
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Trading Interface */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Trade {token.symbol}</CardTitle>
                <CardDescription>
                  Buy and sell {token.name} tokens using $AUK
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="buy" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="buy" className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Buy
                    </TabsTrigger>
                    <TabsTrigger value="sell" className="flex items-center gap-2">
                      <TrendingDown className="h-4 w-4" />
                      Sell
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="buy" className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Amount to buy</label>
                      <Input
                        type="number"
                        placeholder="0"
                        value={buyAmount}
                        onChange={(e) => setBuyAmount(e.target.value)}
                      />
                    </div>

                    {buyCalculation && (
                      <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                        <h4 className="font-medium text-sm">Purchase Summary</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span>Token Price:</span>
                            <span>${buyCalculation.tokenPrice.toFixed(6)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Base Cost:</span>
                            <span>{buyCalculation.aukNeeded.toFixed(2)} $AUK</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Tax ({token.tax_percentage}%):</span>
                            <span>{buyCalculation.taxAmount.toFixed(2)} $AUK</span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-1">
                            <span>Total Cost:</span>
                            <span>{buyCalculation.finalAukAmount.toFixed(2)} $AUK</span>
                          </div>
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>New Market Cap:</span>
                            <span>${buyCalculation.newMarketCap.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    <Button
                      onClick={handleBuy}
                      disabled={!buyAmount || tradeLoading || (buyCalculation && buyCalculation.finalAukAmount > aukBalance)}
                      className="w-full"
                    >
                      <TrendingUp className="h-4 w-4 mr-2" />
                      {tradeLoading ? 'Processing...' : `Buy ${token.symbol}`}
                    </Button>
                  </TabsContent>

                  <TabsContent value="sell" className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Amount to sell</label>
                      <Input
                        type="number"
                        placeholder="0"
                        value={sellAmount}
                        onChange={(e) => setSellAmount(e.target.value)}
                      />
                    </div>

                    {sellCalculation && (
                      <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                        <h4 className="font-medium text-sm">Sale Summary</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span>Token Price:</span>
                            <span>${sellCalculation.tokenPrice.toFixed(6)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Base Value:</span>
                            <span>{sellCalculation.aukNeeded.toFixed(2)} $AUK</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Tax ({token.tax_percentage}%):</span>
                            <span>-{sellCalculation.taxAmount.toFixed(2)} $AUK</span>
                          </div>
                          <div className="flex justify-between font-medium border-t pt-1">
                            <span>You Receive:</span>
                            <span>{sellCalculation.finalAukAmount.toFixed(2)} $AUK</span>
                          </div>
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>New Market Cap:</span>
                            <span>${sellCalculation.newMarketCap.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    <Button
                      onClick={handleSell}
                      disabled={!sellAmount || tradeLoading}
                      className="w-full"
                      variant="destructive"
                    >
                      <TrendingDown className="h-4 w-4 mr-2" />
                      {tradeLoading ? 'Processing...' : `Sell ${token.symbol}`}
                    </Button>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TokenTrading;