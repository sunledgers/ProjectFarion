import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useMeteoraLaunchpad, MeteoraToken } from '@/hooks/useMeteoraLaunchpad';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import WalletConnector from '@/components/chat/WalletConnector';
import { motion } from 'framer-motion';
import { 
  ArrowLeft,
  TrendingUp, 
  Users, 
  Coins, 
  Crown,
  ArrowUpRight,
  ArrowDownRight,
  Copy,
  Wallet,
  BarChart3,
  Activity,
  MessageCircle,
  Send,
  Bell,
  BellPlus,
  Trash2,
  PieChart
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { z } from 'zod';
import { toast } from 'sonner';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell } from 'recharts';

// Comment validation schema
const commentSchema = z.string().trim().min(1, "Comment cannot be empty").max(500, "Comment must be less than 500 characters");

interface TokenComment {
  id: string;
  token_id: string;
  wallet_address: string;
  username: string | null;
  content: string;
  created_at: string;
}

interface CommentReaction {
  id: string;
  comment_id: string;
  wallet_address: string;
  reaction_type: string;
  created_at: string;
}

interface TokenHolder {
  walletAddress: string;
  username: string | null;
  balance: number;
}

const REACTION_EMOJIS = [
  { type: 'like', emoji: '👍' },
  { type: 'fire', emoji: '🔥' },
  { type: 'rocket', emoji: '🚀' },
  { type: 'heart', emoji: '❤️' },
  { type: 'laugh', emoji: '😂' },
];

const HOLDER_COLORS = [
  '#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6',
  '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#6366f1',
];

const TokenDetail = () => {
  const { tokenId } = useParams<{ tokenId: string }>();
  const navigate = useNavigate();
  const { connected, walletAddress, username } = useMultiWallet();
  const { 
    tokens, 
    trading, 
    buyTokens, 
    sellTokens, 
    getUserHoldings, 
    getTokenTrades,
    getTokenHolders 
  } = useMeteoraLaunchpad();
  
  const [token, setToken] = useState<MeteoraToken | null>(null);
  const [trades, setTrades] = useState<any[]>([]);
  const [holders, setHolders] = useState<TokenHolder[]>([]);
  const [userHoldings, setUserHoldings] = useState<number>(0);
  const [buyAmount, setBuyAmount] = useState('0.01');
  const [sellAmount, setSellAmount] = useState('');
  const [loading, setLoading] = useState(true);
  const [priceHistory, setPriceHistory] = useState<{ time: string; price: number; }[]>([]);
  const [isLive, setIsLive] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [comments, setComments] = useState<TokenComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const [reactions, setReactions] = useState<Record<string, CommentReaction[]>>({});
  
  // Price alerts state
  const [priceAlerts, setPriceAlerts] = useState<any[]>([]);
  const [alertPrice, setAlertPrice] = useState('');
  const [alertType, setAlertType] = useState<'above' | 'below'>('above');
  const [showAlertForm, setShowAlertForm] = useState(false);

  useEffect(() => {
    if (tokenId) {
      loadTokenData();
    }
  }, [tokenId, tokens]);

  useEffect(() => {
    if (tokenId && walletAddress) {
      loadUserHoldings();
      loadPriceAlerts();
    }
  }, [tokenId, walletAddress]);

  const loadPriceAlerts = async () => {
    if (!tokenId || !walletAddress) return;
    const { data } = await supabase
      .from('price_alerts')
      .select('*')
      .eq('token_id', tokenId)
      .eq('wallet_address', walletAddress);
    setPriceAlerts(data || []);
  };

  const handleCreateAlert = async () => {
    if (!tokenId || !alertPrice || !walletAddress) {
      toast.error('Please enter a target price');
      return;
    }
    const price = parseFloat(alertPrice);
    if (isNaN(price) || price <= 0) {
      toast.error('Please enter a valid price');
      return;
    }
    
    const { error } = await supabase
      .from('price_alerts')
      .insert({
        token_id: tokenId,
        wallet_address: walletAddress,
        target_price: price,
        alert_type: alertType,
      });
    
    if (!error) {
      toast.success('Price alert created');
      setAlertPrice('');
      setShowAlertForm(false);
      await loadPriceAlerts();
    }
  };

  const handleDeleteAlert = async (alertId: string) => {
    const { error } = await supabase
      .from('price_alerts')
      .delete()
      .eq('id', alertId);
    
    if (!error) {
      toast.success('Alert deleted');
      await loadPriceAlerts();
    }
  };

  // Real-time subscription for token updates
  useEffect(() => {
    if (!tokenId) return;

    const channel = supabase
      .channel(`token-${tokenId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'launchpad_tokens',
          filter: `id=eq.${tokenId}`
        },
        (payload) => {
          const updated = payload.new;
          setToken({
            id: updated.id,
            name: updated.name,
            symbol: updated.symbol,
            description: updated.description,
            logoUrl: updated.logo_url,
            creatorWallet: updated.creator_wallet,
            creatorUsername: updated.creator_username,
            contractAddress: updated.contract_address,
            poolAddress: updated.pool_address,
            tokenMint: updated.token_mint,
            configAddress: updated.config_address,
            poolConfigAddress: updated.pool_config_address || null,
            isOnChain: updated.is_on_chain || false,
            totalSupply: Number(updated.total_supply),
            currentSupply: Number(updated.current_supply),
            currentPrice: Number(updated.current_price),
            marketCap: Number(updated.market_cap),
            volume24h: Number(updated.volume_24h),
            holderCount: updated.holder_count || 0,
            bondingCurveProgress: Number(updated.bonding_curve_progress),
            isGraduated: updated.is_graduated || false,
            graduationThreshold: Number(updated.graduation_threshold),
            createdAt: updated.created_at || '',
            updatedAt: updated.updated_at || '',
            creatorFeePercentage: Number(updated.creator_fee_percentage || 0),
            creatorEarnings: Number(updated.creator_earnings || 0),
            creatorClaimedFees: Number(updated.creator_claimed_fees || 0),
            initialBuySol: Number(updated.initial_buy_sol || 0),
            migrationStatus: updated.migration_status || 'pending',
            dammPoolAddress: updated.damm_pool_address || null,
            lpMintAddress: updated.lp_mint_address || null,
          });
          setLastUpdate(new Date());
          
          // Add new price point to history
          setPriceHistory(prev => {
            const newPoint = {
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              price: Number(updated.current_price)
            };
            return [...prev.slice(-19), newPoint];
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'launchpad_trades',
          filter: `token_id=eq.${tokenId}`
        },
        async (payload) => {
          const newTrade = payload.new;
          setTrades(prev => [newTrade, ...prev].slice(0, 50));
          setLastUpdate(new Date());
          
          // Reload user holdings and holders in case they made a trade
          if (walletAddress) {
            loadUserHoldings();
          }
          loadHolders();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'token_comments',
          filter: `token_id=eq.${tokenId}`
        },
        (payload) => {
          const newComment = payload.new as TokenComment;
          setComments(prev => [...prev, newComment]);
        }
      )
      .subscribe((status) => {
        setIsLive(status === 'SUBSCRIBED');
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [tokenId, walletAddress]);

  // Load comments
  const loadComments = async () => {
    if (!tokenId) return;
    
    const { data } = await supabase
      .from('token_comments')
      .select('*')
      .eq('token_id', tokenId)
      .order('created_at', { ascending: true })
      .limit(100);
    
    const commentsData = (data as TokenComment[]) || [];
    setComments(commentsData);
    
    // Load reactions for all comments
    if (commentsData.length > 0) {
      const commentIds = commentsData.map(c => c.id);
      const { data: reactionsData } = await supabase
        .from('comment_reactions')
        .select('*')
        .in('comment_id', commentIds);
      
      if (reactionsData) {
        const reactionsMap: Record<string, CommentReaction[]> = {};
        reactionsData.forEach((reaction: CommentReaction) => {
          if (!reactionsMap[reaction.comment_id]) {
            reactionsMap[reaction.comment_id] = [];
          }
          reactionsMap[reaction.comment_id].push(reaction);
        });
        setReactions(reactionsMap);
      }
    }
  };

  const loadHolders = async () => {
    if (!tokenId) return;
    const holdersData = await getTokenHolders(tokenId);
    setHolders(holdersData);
  };

  // Toggle reaction on a comment
  const toggleReaction = async (commentId: string, reactionType: string) => {
    if (!connected || !walletAddress) {
      toast.error('Connect your wallet to react');
      return;
    }

    const existingReactions = reactions[commentId] || [];
    const userReaction = existingReactions.find(
      r => r.wallet_address === walletAddress && r.reaction_type === reactionType
    );

    if (userReaction) {
      // Remove reaction
      const { error } = await supabase
        .from('comment_reactions')
        .delete()
        .eq('id', userReaction.id);
      
      if (!error) {
        setReactions(prev => ({
          ...prev,
          [commentId]: prev[commentId].filter(r => r.id !== userReaction.id)
        }));
      }
    } else {
      // Add reaction
      const { data, error } = await supabase
        .from('comment_reactions')
        .insert({
          comment_id: commentId,
          wallet_address: walletAddress,
          reaction_type: reactionType
        })
        .select()
        .single();
      
      if (!error && data) {
        setReactions(prev => ({
          ...prev,
          [commentId]: [...(prev[commentId] || []), data as CommentReaction]
        }));
      }
    }
  };

  // Get reaction counts for a comment
  const getReactionCounts = (commentId: string) => {
    const commentReactions = reactions[commentId] || [];
    const counts: Record<string, number> = {};
    commentReactions.forEach(r => {
      counts[r.reaction_type] = (counts[r.reaction_type] || 0) + 1;
    });
    return counts;
  };

  // Check if user has reacted with a specific type
  const hasUserReacted = (commentId: string, reactionType: string) => {
    if (!walletAddress) return false;
    const commentReactions = reactions[commentId] || [];
    return commentReactions.some(
      r => r.wallet_address === walletAddress && r.reaction_type === reactionType
    );
  };

  // Post comment
  const handlePostComment = async () => {
    if (!connected || !walletAddress) {
      toast.error('Please connect your wallet to comment');
      return;
    }

    const validationResult = commentSchema.safeParse(newComment);
    if (!validationResult.success) {
      toast.error(validationResult.error.errors[0].message);
      return;
    }

    setSubmittingComment(true);
    try {
      const { error } = await supabase
        .from('token_comments')
        .insert({
          token_id: tokenId,
          wallet_address: walletAddress,
          username: username,
          content: validationResult.data
        });

      if (error) throw error;
      
      setNewComment('');
      toast.success('Comment posted!');
    } catch (error) {
      console.error('Error posting comment:', error);
      toast.error('Failed to post comment');
    } finally {
      setSubmittingComment(false);
    }
  };

  // Load comments when tokenId changes
  useEffect(() => {
    if (tokenId) {
      loadComments();
      loadHolders();
    }
  }, [tokenId]);

  const loadTokenData = async () => {
    setLoading(true);
    try {
      // Find token from loaded tokens
      const foundToken = tokens.find(t => t.id === tokenId);
      if (foundToken) {
        setToken(foundToken);
      } else {
        // Fetch directly if not in list
        const { data } = await supabase
          .from('launchpad_tokens')
          .select('*')
          .eq('id', tokenId)
          .single();
        if (data) {
          setToken({
            id: data.id,
            name: data.name,
            symbol: data.symbol,
            description: data.description,
            logoUrl: data.logo_url,
            creatorWallet: data.creator_wallet,
            creatorUsername: data.creator_username,
            contractAddress: data.contract_address,
            poolAddress: data.pool_address,
            tokenMint: data.token_mint,
            configAddress: data.config_address,
            poolConfigAddress: data.pool_config_address || null,
            isOnChain: data.is_on_chain || false,
            totalSupply: Number(data.total_supply),
            currentSupply: Number(data.current_supply),
            currentPrice: Number(data.current_price),
            marketCap: Number(data.market_cap),
            volume24h: Number(data.volume_24h),
            holderCount: data.holder_count || 0,
            bondingCurveProgress: Number(data.bonding_curve_progress),
            isGraduated: data.is_graduated || false,
            graduationThreshold: Number(data.graduation_threshold),
            createdAt: data.created_at || '',
            updatedAt: data.updated_at || '',
            creatorFeePercentage: Number(data.creator_fee_percentage || 0),
            creatorEarnings: Number(data.creator_earnings || 0),
            creatorClaimedFees: Number(data.creator_claimed_fees || 0),
            initialBuySol: Number(data.initial_buy_sol || 0),
            migrationStatus: data.migration_status || 'pending',
            dammPoolAddress: data.damm_pool_address || null,
            lpMintAddress: data.lp_mint_address || null,
          });
        }
      }

      // Load trades
      const tradeData = await getTokenTrades(tokenId!);
      setTrades(tradeData);

      // Generate price history from trades
      generatePriceHistory(tradeData);
    } catch (error) {
      console.error('Error loading token:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUserHoldings = async () => {
    if (!tokenId) return;
    const holdings = await getUserHoldings(tokenId);
    setUserHoldings(holdings);
  };

  const generatePriceHistory = (tradeData: any[]) => {
    if (tradeData.length === 0) {
      // Generate mock starting data if no trades
      const now = Date.now();
      const mockData = Array.from({ length: 12 }, (_, i) => ({
        time: new Date(now - (11 - i) * 3600000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        price: 0.000001 * (1 + Math.random() * 0.1)
      }));
      setPriceHistory(mockData);
      return;
    }

    // Build price history from trades
    const sortedTrades = [...tradeData].sort((a, b) => 
      new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );

    const history = sortedTrades.map(trade => ({
      time: new Date(trade.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      price: trade.price_at_trade
    }));

    // Add current price as last point
    if (token) {
      history.push({
        time: 'Now',
        price: token.currentPrice
      });
    }

    setPriceHistory(history.slice(-20)); // Last 20 data points
  };

  const handleBuy = async () => {
    if (!token) return;
    const amount = parseFloat(buyAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    const result = await buyTokens(token.id, amount);
    if (result.success) {
      await loadTokenData();
      await loadUserHoldings();
      await loadHolders();
    }
  };

  const handleSell = async () => {
    if (!token) return;
    const amount = parseFloat(sellAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (amount > userHoldings) {
      toast.error('Insufficient balance');
      return;
    }
    
    const result = await sellTokens(token.id, amount);
    if (result.success) {
      await loadTokenData();
      await loadUserHoldings();
      await loadHolders();
    }
  };

  const copyAddress = () => {
    if (token) {
      navigator.clipboard.writeText(token.contractAddress);
      toast.success('Contract address copied!');
    }
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(2)}K`;
    return num.toFixed(2);
  };

  const formatPrice = (price: number): string => {
    if (price < 0.000001) return price.toExponential(2);
    if (price < 0.001) return price.toFixed(8);
    return price.toFixed(6);
  };

  const getTimeAgo = (dateString: string): string => {
    const seconds = Math.floor((Date.now() - new Date(dateString).getTime()) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  // Prepare holder distribution data for pie chart
  const getHolderDistributionData = () => {
    if (holders.length === 0) return [];
    
    const totalBalance = holders.reduce((sum, h) => sum + h.balance, 0);
    const topHolders = holders.slice(0, 8);
    const othersBalance = holders.slice(8).reduce((sum, h) => sum + h.balance, 0);
    
    const data = topHolders.map((h, index) => ({
      name: h.username || `${h.walletAddress.slice(0, 4)}...${h.walletAddress.slice(-4)}`,
      value: h.balance,
      percentage: ((h.balance / totalBalance) * 100).toFixed(1),
      color: HOLDER_COLORS[index % HOLDER_COLORS.length],
    }));
    
    if (othersBalance > 0) {
      data.push({
        name: 'Others',
        value: othersBalance,
        percentage: ((othersBalance / totalBalance) * 100).toFixed(1),
        color: '#6b7280',
      });
    }
    
    return data;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <main className="container mx-auto px-4 py-8 pt-20 sm:pt-8 sm:ml-64 lg:ml-72">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48" />
            <div className="h-64 bg-muted rounded" />
            <div className="grid grid-cols-2 gap-4">
              <div className="h-32 bg-muted rounded" />
              <div className="h-32 bg-muted rounded" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <main className="container mx-auto px-4 py-8 pt-20 sm:pt-8 sm:ml-64 lg:ml-72">
          <Card className="p-12 text-center">
            <h2 className="text-2xl font-bold mb-4">Token Not Found</h2>
            <p className="text-muted-foreground mb-6">The token you're looking for doesn't exist.</p>
            <Button onClick={() => navigate('/launchpad')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Launchpad
            </Button>
          </Card>
        </main>
      </div>
    );
  }

  const estimatedTokens = parseFloat(buyAmount) / token.currentPrice;
  const estimatedSol = parseFloat(sellAmount || '0') * token.currentPrice * 0.99;
  const holderDistributionData = getHolderDistributionData();

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      <main className="container mx-auto px-4 py-8 pt-20 sm:pt-8 sm:ml-64 lg:ml-72">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Back Button and Live Indicator */}
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => navigate('/launchpad')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Launchpad
            </Button>
            <div className="flex items-center gap-2">
              {isLive && (
                <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">
                  <span className="relative flex h-2 w-2 mr-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                  </span>
                  Live
                </Badge>
              )}
              {lastUpdate && (
                <span className="text-xs text-muted-foreground">
                  Updated {lastUpdate.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>

          {/* Token Header */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex items-center gap-4">
              {token.logoUrl ? (
                <img 
                  src={token.logoUrl} 
                  alt={token.name} 
                  className="w-16 h-16 rounded-full object-cover border-2 border-green-500/30"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white font-bold text-2xl">
                  {token.symbol.charAt(0)}
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold">{token.name}</h1>
                  {token.isGraduated && (
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500">
                      <Crown className="h-3 w-3 mr-1" />
                      Graduated
                    </Badge>
                  )}
                </div>
                <p className="text-muted-foreground">${token.symbol}</p>
              </div>
            </div>
            <div className="sm:ml-auto flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={copyAddress}>
                <Copy className="h-4 w-4 mr-2" />
                {token.contractAddress.slice(0, 6)}...{token.contractAddress.slice(-4)}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const text = `Check out $${token.symbol} on Farion Launchpad! 🚀\n\nPrice: ${formatPrice(token.currentPrice)} SOL\nMarket Cap: ${formatNumber(token.marketCap)} SOL\n\n`;
                  const url = window.location.href;
                  window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
                }}
                className="bg-black hover:bg-black/80 text-white border-none"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const text = `Check out $${token.symbol} on Farion Launchpad! 🚀\n\nPrice: ${formatPrice(token.currentPrice)} SOL\nMarket Cap: ${formatNumber(token.marketCap)} SOL\n\n${window.location.href}`;
                  window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(text)}`, '_blank');
                }}
                className="bg-[#0088cc] hover:bg-[#0088cc]/80 text-white border-none"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                </svg>
              </Button>
            </div>
          </div>

          {/* Price and Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Coins className="h-4 w-4" />
                  Price
                </div>
                <p className="text-xl font-bold font-mono">{formatPrice(token.currentPrice)} SOL</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <BarChart3 className="h-4 w-4" />
                  Market Cap
                </div>
                <p className="text-xl font-bold">{formatNumber(token.marketCap)} SOL</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-pink-500/10 to-red-500/10 border-pink-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Users className="h-4 w-4" />
                  Holders
                </div>
                <p className="text-xl font-bold">{token.holderCount}</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Activity className="h-4 w-4" />
                  24h Volume
                </div>
                <p className="text-xl font-bold">{formatNumber(token.volume24h)} SOL</p>
              </CardContent>
            </Card>
          </div>

          {/* Price Alerts Section */}
          {connected && (
            <Card className="border-amber-500/20">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="h-5 w-5 text-amber-500" />
                    <CardTitle className="text-lg">Price Alerts</CardTitle>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAlertForm(!showAlertForm)}
                    className="border-amber-500/30 text-amber-600 hover:bg-amber-500/10"
                  >
                    <BellPlus className="h-4 w-4 mr-1" />
                    {showAlertForm ? 'Cancel' : 'Add Alert'}
                  </Button>
                </div>
                <CardDescription>
                  Get notified when this token reaches your target price
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {showAlertForm && (
                  <div className="flex flex-col sm:flex-row gap-3 p-4 bg-amber-500/5 rounded-lg border border-amber-500/20">
                    <div className="flex-1">
                      <label className="text-xs text-muted-foreground mb-1 block">Target Price (SOL)</label>
                      <Input
                        type="number"
                        step="0.00000001"
                        placeholder={formatPrice(token.currentPrice)}
                        value={alertPrice}
                        onChange={(e) => setAlertPrice(e.target.value)}
                        className="font-mono"
                      />
                    </div>
                    <div className="sm:w-32">
                      <label className="text-xs text-muted-foreground mb-1 block">Alert When</label>
                      <Select value={alertType} onValueChange={(v: 'above' | 'below') => setAlertType(v)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="above">Above</SelectItem>
                          <SelectItem value="below">Below</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      <Button 
                        onClick={handleCreateAlert}
                        className="bg-amber-500 hover:bg-amber-600 w-full sm:w-auto"
                      >
                        <Bell className="h-4 w-4 mr-1" />
                        Create
                      </Button>
                    </div>
                  </div>
                )}

                {priceAlerts.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No price alerts set for this token
                  </p>
                ) : (
                  <div className="space-y-2">
                    {priceAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`flex items-center justify-between p-3 rounded-lg border ${
                          alert.is_triggered 
                            ? 'bg-green-500/10 border-green-500/30' 
                            : 'bg-muted/30 border-border'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-full ${
                            alert.is_triggered ? 'bg-green-500/20' : 'bg-amber-500/20'
                          }`}>
                            {alert.alert_type === 'above' ? (
                              <ArrowUpRight className={`h-4 w-4 ${alert.is_triggered ? 'text-green-500' : 'text-amber-500'}`} />
                            ) : (
                              <ArrowDownRight className={`h-4 w-4 ${alert.is_triggered ? 'text-green-500' : 'text-amber-500'}`} />
                            )}
                          </div>
                          <div>
                            <p className="font-mono text-sm font-medium">
                              {alert.alert_type === 'above' ? 'Above' : 'Below'} {formatPrice(alert.target_price)} SOL
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {alert.is_triggered 
                                ? `Triggered ${new Date(alert.triggered_at).toLocaleDateString()}`
                                : `Current: ${formatPrice(token.currentPrice)} SOL`
                              }
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {alert.is_triggered && (
                            <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">
                              Triggered
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAlert(alert.id)}
                            className="text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Bonding Curve Progress */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Bonding Curve Progress</CardTitle>
              <CardDescription>
                Token graduates to DEX at {token.graduationThreshold}%
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium text-green-500">
                    {token.bondingCurveProgress.toFixed(2)}%
                  </span>
                </div>
                <Progress value={token.bondingCurveProgress} className="h-3" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0%</span>
                  <span>{token.graduationThreshold}% (Graduation)</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chart Section */}
            <div className="lg:col-span-2 space-y-6">
              {/* Price Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    Price Chart
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={priceHistory}>
                        <defs>
                          <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted))" />
                        <XAxis 
                          dataKey="time" 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <YAxis 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                          tickFormatter={(v) => v.toExponential(1)}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px'
                          }}
                          formatter={(value: number) => [formatPrice(value) + ' SOL', 'Price']}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="price" 
                          stroke="#22c55e" 
                          strokeWidth={2}
                          fill="url(#priceGradient)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Holder Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="h-5 w-5 text-purple-500" />
                    Holder Distribution
                  </CardTitle>
                  <CardDescription>
                    Top {Math.min(holders.length, 8)} holders by balance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {holders.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      No holders yet. Be the first to buy!
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="h-64 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPie>
                            <Pie
                              data={holderDistributionData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={90}
                              dataKey="value"
                              paddingAngle={2}
                            >
                              {holderDistributionData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip
                              contentStyle={{
                                backgroundColor: 'hsl(var(--card))',
                                border: '1px solid hsl(var(--border))',
                                borderRadius: '8px',
                              }}
                              formatter={(value: number) => [formatNumber(value) + ` ${token.symbol}`, 'Balance']}
                            />
                          </RechartsPie>
                        </ResponsiveContainer>
                      </div>
                      <div className="space-y-2">
                        {holderDistributionData.map((holder, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-2 bg-muted/30 rounded-lg"
                          >
                            <div className="flex items-center gap-2">
                              <div
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: holder.color }}
                              />
                              <span className="text-sm truncate max-w-[120px]">{holder.name}</span>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-mono">{holder.percentage}%</p>
                              <p className="text-xs text-muted-foreground">
                                {formatNumber(holder.value)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Trade History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Trade History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {trades.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      No trades yet. Be the first to buy!
                    </p>
                  ) : (
                    <div className="space-y-3 max-h-80 overflow-y-auto">
                      {trades.map((trade) => (
                        <div 
                          key={trade.id} 
                          className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full ${
                              trade.trade_type === 'buy' 
                                ? 'bg-green-500/20 text-green-500' 
                                : 'bg-red-500/20 text-red-500'
                            }`}>
                              {trade.trade_type === 'buy' ? (
                                <ArrowUpRight className="h-4 w-4" />
                              ) : (
                                <ArrowDownRight className="h-4 w-4" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium">
                                {trade.trade_type === 'buy' ? 'Buy' : 'Sell'}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {trade.username || trade.wallet_address.slice(0, 8) + '...'}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-mono text-sm">
                              {formatNumber(trade.token_amount)} {token.symbol}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {Number(trade.sol_amount).toFixed(4)} SOL • {getTimeAgo(trade.created_at)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Community Comments */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Community Discussion ({comments.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Comment Input */}
                  {connected ? (
                    <div className="space-y-2">
                      <Textarea
                        placeholder="Share your thoughts on this token..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        maxLength={500}
                        rows={3}
                        className="resize-none"
                      />
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {newComment.length}/500 characters
                        </span>
                        <Button
                          size="sm"
                          onClick={handlePostComment}
                          disabled={submittingComment || !newComment.trim()}
                          className="bg-gradient-to-r from-green-500 to-emerald-500"
                        >
                          {submittingComment ? (
                            <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <>
                              <Send className="h-4 w-4 mr-1" />
                              Post
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-2">
                        Connect wallet to join the discussion
                      </p>
                      <WalletConnector />
                    </div>
                  )}

                  <Separator />

                  {/* Comments List */}
                  {comments.length === 0 ? (
                    <p className="text-center text-muted-foreground py-6">
                      No comments yet. Be the first to share your thoughts!
                    </p>
                  ) : (
                    <ScrollArea className="h-64">
                      <div className="space-y-3 pr-4">
                        {comments.map((comment) => {
                          const reactionCounts = getReactionCounts(comment.id);
                          return (
                            <div key={comment.id} className="p-3 bg-muted/30 rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white text-xs font-bold">
                                    {(comment.username || comment.wallet_address).charAt(0).toUpperCase()}
                                  </div>
                                  <span className="text-sm font-medium">
                                    {comment.username || comment.wallet_address.slice(0, 8) + '...'}
                                  </span>
                                </div>
                                <span className="text-xs text-muted-foreground">
                                  {getTimeAgo(comment.created_at)}
                                </span>
                              </div>
                              <p className="text-sm mb-2">{comment.content}</p>
                              
                              {/* Emoji Reactions */}
                              <div className="flex items-center gap-1 flex-wrap">
                                {REACTION_EMOJIS.map(({ type, emoji }) => {
                                  const count = reactionCounts[type] || 0;
                                  const hasReacted = hasUserReacted(comment.id, type);
                                  return (
                                    <button
                                      key={type}
                                      onClick={() => toggleReaction(comment.id, type)}
                                      className={`
                                        inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs
                                        transition-all duration-200 hover:scale-110
                                        ${hasReacted 
                                          ? 'bg-primary/20 border border-primary/40' 
                                          : 'bg-muted/50 hover:bg-muted border border-transparent'
                                        }
                                        ${count > 0 ? '' : 'opacity-60 hover:opacity-100'}
                                      `}
                                    >
                                      <span>{emoji}</span>
                                      {count > 0 && <span className="font-medium">{count}</span>}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Trading Panel */}
            <div className="space-y-6">
              {/* Your Holdings */}
              {connected && (
                <Card className="border-green-500/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Wallet className="h-5 w-5" />
                      Your Holdings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold font-mono">
                      {formatNumber(userHoldings)} {token.symbol}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      ≈ {formatPrice(userHoldings * token.currentPrice)} SOL
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Trade Card */}
              <Card>
                <CardHeader>
                  <CardTitle>Trade {token.symbol}</CardTitle>
                </CardHeader>
                <CardContent>
                  {!connected ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground text-center">
                        Connect wallet to trade
                      </p>
                      <WalletConnector />
                    </div>
                  ) : (
                    <Tabs defaultValue="buy" className="space-y-4">
                      <TabsList className="w-full">
                        <TabsTrigger value="buy" className="flex-1">Buy</TabsTrigger>
                        <TabsTrigger value="sell" className="flex-1">Sell</TabsTrigger>
                      </TabsList>

                      <TabsContent value="buy" className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Amount (SOL)</label>
                          <Input
                            type="number"
                            placeholder="0.01"
                            value={buyAmount}
                            onChange={(e) => setBuyAmount(e.target.value)}
                            min="0.001"
                            step="0.01"
                          />
                        </div>
                        <div className="flex gap-2">
                          {['0.01', '0.05', '0.1', '0.5'].map(amt => (
                            <Button
                              key={amt}
                              variant="outline"
                              size="sm"
                              onClick={() => setBuyAmount(amt)}
                              className="flex-1"
                            >
                              {amt}
                            </Button>
                          ))}
                        </div>
                        <div className="p-3 bg-muted/50 rounded-lg text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">You receive</span>
                            <span className="font-mono">
                              ~{formatNumber(estimatedTokens)} {token.symbol}
                            </span>
                          </div>
                        </div>
                        <Button 
                          onClick={handleBuy}
                          disabled={trading || !buyAmount}
                          className="w-full bg-gradient-to-r from-green-500 to-emerald-500"
                        >
                          {trading ? (
                            <>
                              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                              Processing...
                            </>
                          ) : (
                            <>
                              <ArrowUpRight className="h-4 w-4 mr-2" />
                              Buy {token.symbol}
                            </>
                          )}
                        </Button>
                      </TabsContent>

                      <TabsContent value="sell" className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Amount ({token.symbol})</label>
                          <Input
                            type="number"
                            placeholder="0"
                            value={sellAmount}
                            onChange={(e) => setSellAmount(e.target.value)}
                            max={userHoldings}
                          />
                        </div>
                        <div className="flex gap-2">
                          {[25, 50, 75, 100].map(pct => (
                            <Button
                              key={pct}
                              variant="outline"
                              size="sm"
                              onClick={() => setSellAmount((userHoldings * pct / 100).toString())}
                              className="flex-1"
                            >
                              {pct}%
                            </Button>
                          ))}
                        </div>
                        <div className="p-3 bg-muted/50 rounded-lg text-sm space-y-1">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">You receive</span>
                            <span className="font-mono">
                              ~{estimatedSol.toFixed(6)} SOL
                            </span>
                          </div>
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">Platform fee</span>
                            <span>1%</span>
                          </div>
                          {token.creatorFeePercentage > 0 && (
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Creator fee</span>
                              <span>{token.creatorFeePercentage}%</span>
                            </div>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            Total fees: {1 + token.creatorFeePercentage}%
                          </p>
                        </div>
                        <Button 
                          onClick={handleSell}
                          disabled={trading || !sellAmount || userHoldings === 0}
                          variant="destructive"
                          className="w-full"
                        >
                          {trading ? (
                            <>
                              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                              Processing...
                            </>
                          ) : (
                            <>
                              <ArrowDownRight className="h-4 w-4 mr-2" />
                              Sell {token.symbol}
                            </>
                          )}
                        </Button>
                      </TabsContent>
                    </Tabs>
                  )}
                </CardContent>
              </Card>

              {/* Token Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Token Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  {token.description && (
                    <div>
                      <p className="text-muted-foreground">Description</p>
                      <p>{token.description}</p>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Supply</span>
                    <span className="font-mono">{formatNumber(token.totalSupply)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Circulating</span>
                    <span className="font-mono">{formatNumber(token.totalSupply - token.currentSupply)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Creator</span>
                    <span>{token.creatorUsername || token.creatorWallet.slice(0, 8) + '...'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Creator Fee</span>
                    <span className="text-green-500 font-medium">{token.creatorFeePercentage}%</span>
                  </div>
                  {token.creatorEarnings > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Creator Earnings</span>
                      <span className="text-green-500 font-mono">{token.creatorEarnings.toFixed(4)} SOL</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created</span>
                    <span>{new Date(token.createdAt).toLocaleDateString()}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </motion.div>
      </main>
      
      <Footer />
    </div>
  );
};

export default TokenDetail;
