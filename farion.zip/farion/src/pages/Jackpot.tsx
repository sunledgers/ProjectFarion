import React from 'react';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import JackpotSystem from '@/components/JackpotSystem';
import WalletConnectionPrompt from '@/components/WalletConnectionPrompt';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, TrendingUp, Users, Zap } from 'lucide-react';
import { motion } from 'framer-motion';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useJackpotStats } from '@/hooks/useJackpotStats';

const Jackpot = () => {
  const { connected } = useMultiWallet();
  const { stats, recentWinners, loading } = useJackpotStats();

  // Convert database stats to display format
  const displayStats = [
    { 
      label: 'Total Distributed', 
      value: `${stats.totalPot.toFixed(1)} SOL`, 
      icon: TrendingUp 
    },
    { 
      label: 'Average Pot', 
      value: `${stats.averagePot.toFixed(1)} SOL`, 
      icon: Trophy 
    },
    { 
      label: 'Total Players', 
      value: stats.participantsCount.toLocaleString(), 
      icon: Users 
    },
    { 
      label: 'Rounds Played', 
      value: stats.totalRounds.toString(), 
      icon: Zap 
    },
  ];

  return (
    <div className="min-h-screen relative">
      <UnifiedNavigation />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 via-background to-accent/10">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center justify-center gap-3 mb-6">
              <Trophy className="h-12 w-12 text-primary" />
              <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                $FARION Jackpot
              </h1>
            </div>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Join the live SOL jackpot! Real Solana betting with instant payouts and fair winner selection.
            </p>
            <div className="flex justify-center gap-3">
              <Badge variant="outline" className="text-lg px-4 py-2 border-green-500/30 text-green-600">
                🔴 Live Game
              </Badge>
              <Badge variant="outline" className="text-lg px-4 py-2 border-orange-500/30 text-orange-600">
                Real SOL Betting
              </Badge>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 bg-card/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Jackpot Statistics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {displayStats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <stat.icon className="h-8 w-8 text-primary mx-auto mb-4" />
                    <div className="text-2xl font-bold mb-2">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Jackpot Interface */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {!connected ? (
            <div className="text-center">
            <WalletConnectionPrompt 
              title="Connect Wallet to Join Jackpot"
              description="Connect your wallet to participate in $FARION jackpot games"
            />
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Jackpot Preview - Takes 2 columns */}
              <div className="lg:col-span-2">
                <JackpotSystem />
              </div>

            {/* Recent Winners */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-primary" />
                    Recent Winners
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="space-y-3">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="animate-pulse flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                          <div className="space-y-2">
                            <div className="h-4 bg-muted-foreground/20 rounded w-24"></div>
                            <div className="h-3 bg-muted-foreground/20 rounded w-16"></div>
                          </div>
                          <div className="h-4 bg-muted-foreground/20 rounded w-16"></div>
                        </div>
                      ))}
                    </div>
                  ) : recentWinners.length > 0 ? (
                    <div className="space-y-3">
                      {recentWinners.map((winner, index) => (
                        <motion.div
                          key={winner.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          className="flex justify-between items-center p-3 bg-muted/50 rounded-lg"
                        >
                          <div>
                            <div className="font-medium">
                              {winner.wallet_address.slice(0, 4)}...{winner.wallet_address.slice(-4)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Round #{winner.round_number} • {new Date(winner.created_at).toLocaleDateString()}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-orange-500">
                              {winner.winnings_amount.toFixed(3)} SOL
                            </div>
                            {index === 0 && <Badge variant="outline" className="text-xs">Latest</Badge>}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Trophy className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No winners yet. Be the first!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Jackpot;