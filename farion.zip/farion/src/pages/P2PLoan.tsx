import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useEscrowTransactions } from '@/hooks/useEscrowTransactions';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import WalletConnectionPrompt from '@/components/WalletConnectionPrompt';
import { ESCROW_WALLET } from '@/config/wallets';
import { 
  Wallet, 
  ArrowRightLeft, 
  Clock, 
  Shield, 
  TrendingUp, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  DollarSign,
  Coins,
  Handshake,
  Loader2
} from 'lucide-react';

interface Loan {
  id: string;
  borrower_wallet: string;
  borrower_username: string;
  collateral_sol: number;
  loan_amount_sol: number;
  interest_rate: number;
  duration_days: number;
  status: string;
  ltv_ratio: number;
  due_at: string | null;
  created_at: string;
  collateral_tx_signature: string | null;
  repayment_tx_signature: string | null;
}

interface P2PTrade {
  id: string;
  seller_wallet: string;
  seller_username: string;
  buyer_wallet: string | null;
  buyer_username: string | null;
  sol_amount: number;
  fiat_amount: number;
  fiat_currency: string;
  escrow_status: string;
  seller_confirmed: boolean;
  buyer_confirmed: boolean;
  payment_method: string;
  created_at: string;
  escrow_tx_signature: string | null;
  disputed_by: string | null;
  dispute_reason: string | null;
}

const P2PLoan = () => {
  const { connected, walletAddress, username } = useMultiWallet();
  const { sendSOLToEscrow, loading: escrowLoading } = useEscrowTransactions();
  const { toast } = useToast();
  
  // Loan states
  const [loans, setLoans] = useState<Loan[]>([]);
  const [myLoans, setMyLoans] = useState<Loan[]>([]);
  const [loanCollateral, setLoanCollateral] = useState('');
  const [loanDuration, setLoanDuration] = useState([7]);
  const [loadingLoans, setLoadingLoans] = useState(false);
  const [processingLoan, setProcessingLoan] = useState(false);
  
  // P2P Trade states
  const [p2pTrades, setP2pTrades] = useState<P2PTrade[]>([]);
  const [myTrades, setMyTrades] = useState<P2PTrade[]>([]);
  const [tradeSolAmount, setTradeSolAmount] = useState('');
  const [tradeFiatAmount, setTradeFiatAmount] = useState('');
  const [tradeCurrency, setTradeCurrency] = useState('USD');
  const [tradePaymentMethod, setTradePaymentMethod] = useState('');
  const [loadingTrades, setLoadingTrades] = useState(false);
  const [processingTrade, setProcessingTrade] = useState(false);
  const [processingRepayment, setProcessingRepayment] = useState<string | null>(null);
  const [disputeReason, setDisputeReason] = useState('');
  const [showDisputeModal, setShowDisputeModal] = useState<string | null>(null);

  // Constants
  const LTV_RATIO = 0.5; // 50% LTV - loan is 50% of collateral value
  const BASE_INTEREST_RATE = 5; // 5% base daily interest

  // Calculate loan amount based on collateral
  const calculateLoanAmount = (collateral: number): number => {
    return collateral * LTV_RATIO;
  };

  // Calculate total repayment
  const calculateRepayment = (loanAmount: number, days: number): number => {
    const dailyRate = BASE_INTEREST_RATE / 100;
    const totalInterest = loanAmount * dailyRate * days;
    return loanAmount + totalInterest;
  };

  // Load loans
  const loadLoans = useCallback(async () => {
    setLoadingLoans(true);
    try {
      const { data, error } = await supabase
        .from('loans')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setLoans(data || []);
      
      if (walletAddress) {
        setMyLoans((data || []).filter(l => l.borrower_wallet === walletAddress));
      }
    } catch (error) {
      console.error('Error loading loans:', error);
    } finally {
      setLoadingLoans(false);
    }
  }, [walletAddress]);

  // Load P2P trades
  const loadTrades = useCallback(async () => {
    setLoadingTrades(true);
    try {
      const { data, error } = await supabase
        .from('p2p_trades')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setP2pTrades(data || []);
      
      if (walletAddress) {
        setMyTrades((data || []).filter(t => 
          t.seller_wallet === walletAddress || t.buyer_wallet === walletAddress
        ));
      }
    } catch (error) {
      console.error('Error loading trades:', error);
    } finally {
      setLoadingTrades(false);
    }
  }, [walletAddress]);

  useEffect(() => {
    loadLoans();
    loadTrades();
  }, [loadLoans, loadTrades]);

  // Create loan request with real SOL collateral
  const handleCreateLoan = async () => {
    if (!connected || !walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to request a loan",
        variant: "destructive",
      });
      return;
    }

    const collateral = parseFloat(loanCollateral);
    if (isNaN(collateral) || collateral <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid collateral amount",
        variant: "destructive",
      });
      return;
    }

    if (collateral < 0.1) {
      toast({
        title: "Minimum Collateral",
        description: "Minimum collateral is 0.1 SOL",
        variant: "destructive",
      });
      return;
    }

    setProcessingLoan(true);

    try {
      // Send collateral SOL to escrow wallet
      const txSignature = await sendSOLToEscrow(collateral);
      
      if (!txSignature) {
        setProcessingLoan(false);
        return; // Error already shown by hook
      }

      const loanAmount = calculateLoanAmount(collateral);
      const dueDate = new Date();
      dueDate.setDate(dueDate.getDate() + loanDuration[0]);

      const { error } = await supabase
        .from('loans')
        .insert({
          borrower_wallet: walletAddress,
          borrower_username: username,
          collateral_sol: collateral,
          loan_amount_sol: loanAmount,
          interest_rate: BASE_INTEREST_RATE,
          duration_days: loanDuration[0],
          ltv_ratio: LTV_RATIO * 100,
          due_at: dueDate.toISOString(),
          status: 'active'
        });

      if (error) throw error;

      toast({
        title: "Loan Created Successfully! 🎉",
        description: `${collateral} SOL collateral sent to escrow. You will receive ${loanAmount.toFixed(4)} SOL loan.`,
      });

      setLoanCollateral('');
      loadLoans();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create loan request",
        variant: "destructive",
      });
    } finally {
      setProcessingLoan(false);
    }
  };

  // Create P2P trade
  const handleCreateTrade = async () => {
    if (!connected || !walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to create a trade",
        variant: "destructive",
      });
      return;
    }

    const solAmount = parseFloat(tradeSolAmount);
    const fiatAmount = parseFloat(tradeFiatAmount);

    if (isNaN(solAmount) || solAmount <= 0 || isNaN(fiatAmount) || fiatAmount <= 0) {
      toast({
        title: "Invalid Amounts",
        description: "Please enter valid SOL and fiat amounts",
        variant: "destructive",
      });
      return;
    }

    if (!tradePaymentMethod) {
      toast({
        title: "Payment Method Required",
        description: "Please specify a payment method",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('p2p_trades')
        .insert({
          seller_wallet: walletAddress,
          seller_username: username,
          sol_amount: solAmount,
          fiat_amount: fiatAmount,
          fiat_currency: tradeCurrency,
          payment_method: tradePaymentMethod,
          escrow_status: 'open'
        });

      if (error) throw error;

      toast({
        title: "Trade Created",
        description: `Selling ${solAmount} SOL for ${fiatAmount} ${tradeCurrency}`,
      });

      setTradeSolAmount('');
      setTradeFiatAmount('');
      setTradePaymentMethod('');
      loadTrades();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create trade",
        variant: "destructive",
      });
    }
  };

  // Accept a P2P trade - Buyer sends SOL to escrow
  const handleAcceptTrade = async (tradeId: string) => {
    if (!connected || !walletAddress || !username) return;

    const trade = p2pTrades.find(t => t.id === tradeId);
    if (!trade) return;

    setProcessingTrade(true);

    try {
      // Buyer sends SOL amount to escrow
      const txSignature = await sendSOLToEscrow(trade.sol_amount);
      
      if (!txSignature) {
        setProcessingTrade(false);
        return; // Error already shown by hook
      }

      const { error } = await supabase
        .from('p2p_trades')
        .update({
          buyer_wallet: walletAddress,
          buyer_username: username,
          escrow_status: 'locked',
          locked_at: new Date().toISOString()
        })
        .eq('id', tradeId);

      if (error) throw error;

      toast({
        title: "Trade Accepted! 🔒",
        description: `${trade.sol_amount} SOL sent to escrow. Complete the fiat payment and confirm.`,
      });

      loadTrades();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to accept trade",
        variant: "destructive",
      });
    } finally {
      setProcessingTrade(false);
    }
  };

  // Confirm trade completion
  const handleConfirmTrade = async (tradeId: string, isSeller: boolean) => {
    if (!connected || !walletAddress) return;

    const trade = p2pTrades.find(t => t.id === tradeId);
    if (!trade) return;

    const updateField = isSeller ? 'seller_confirmed' : 'buyer_confirmed';
    const otherConfirmed = isSeller ? trade.buyer_confirmed : trade.seller_confirmed;

    try {
      const updates: any = { [updateField]: true };
      
      if (otherConfirmed) {
        updates.escrow_status = 'completed';
        updates.completed_at = new Date().toISOString();
      } else {
        updates.escrow_status = isSeller ? 'seller_confirmed' : 'buyer_confirmed';
      }

      const { error } = await supabase
        .from('p2p_trades')
        .update(updates)
        .eq('id', tradeId);

      if (error) throw error;

      toast({
        title: otherConfirmed ? "Trade Completed!" : "Confirmation Recorded",
        description: otherConfirmed 
          ? "Both parties confirmed. Trade is complete!" 
          : "Waiting for other party to confirm.",
      });

      loadTrades();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to confirm trade",
        variant: "destructive",
      });
    }
  };

  // Repay loan with real SOL
  const handleRepayLoan = async (loanId: string) => {
    if (!connected || !walletAddress) return;

    const loan = myLoans.find(l => l.id === loanId);
    if (!loan) return;

    const repaymentAmount = calculateRepayment(loan.loan_amount_sol, loan.duration_days);

    setProcessingRepayment(loanId);

    try {
      // Send repayment SOL to escrow
      const txSignature = await sendSOLToEscrow(repaymentAmount);
      
      if (!txSignature) {
        setProcessingRepayment(null);
        return; // Error already shown by hook
      }

      const { error } = await supabase
        .from('loans')
        .update({
          status: 'repaid',
          repaid_at: new Date().toISOString(),
          repayment_tx_signature: txSignature
        })
        .eq('id', loanId);

      if (error) throw error;

      toast({
        title: "Loan Repaid Successfully! 🎉",
        description: `Paid ${repaymentAmount.toFixed(4)} SOL. Your ${loan.collateral_sol} SOL collateral has been released.`,
      });

      loadLoans();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to repay loan",
        variant: "destructive",
      });
    } finally {
      setProcessingRepayment(null);
    }
  };

  // Raise dispute for P2P trade
  const handleRaiseDispute = async (tradeId: string) => {
    if (!connected || !walletAddress || !disputeReason.trim()) {
      toast({
        title: "Dispute Reason Required",
        description: "Please provide a reason for the dispute",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('p2p_trades')
        .update({
          escrow_status: 'disputed',
          disputed_by: walletAddress,
          dispute_reason: disputeReason.trim(),
          dispute_raised_at: new Date().toISOString()
        })
        .eq('id', tradeId);

      if (error) throw error;

      toast({
        title: "Dispute Raised",
        description: "Your dispute has been submitted. An admin will review it.",
      });

      setShowDisputeModal(null);
      setDisputeReason('');
      loadTrades();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to raise dispute",
        variant: "destructive",
      });
    }
  };

  // Cancel P2P trade (seller only, when open)
  const handleCancelTrade = async (tradeId: string) => {
    if (!connected || !walletAddress) return;

    try {
      const { error } = await supabase
        .from('p2p_trades')
        .update({
          escrow_status: 'cancelled'
        })
        .eq('id', tradeId)
        .eq('seller_wallet', walletAddress)
        .eq('escrow_status', 'open');

      if (error) throw error;

      toast({
        title: "Trade Cancelled",
        description: "Your trade offer has been cancelled.",
      });

      loadTrades();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel trade",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" /> Pending</Badge>;
      case 'active':
        return <Badge variant="default"><TrendingUp className="h-3 w-3 mr-1" /> Active</Badge>;
      case 'repaid':
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" /> Repaid</Badge>;
      case 'defaulted':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Defaulted</Badge>;
      case 'open':
        return <Badge variant="secondary"><AlertCircle className="h-3 w-3 mr-1" /> Open</Badge>;
      case 'locked':
        return <Badge variant="default"><Shield className="h-3 w-3 mr-1" /> In Escrow</Badge>;
      case 'completed':
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" /> Completed</Badge>;
      case 'seller_confirmed':
      case 'buyer_confirmed':
        return <Badge variant="outline"><Clock className="h-3 w-3 mr-1" /> Awaiting Confirmation</Badge>;
      case 'disputed':
        return <Badge variant="destructive"><AlertCircle className="h-3 w-3 mr-1" /> Disputed</Badge>;
      case 'cancelled':
        return <Badge variant="outline"><XCircle className="h-3 w-3 mr-1" /> Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 pt-24 pb-16">
          <WalletConnectionPrompt 
            title="Connect Wallet for P2P & Loans"
            description="Connect your wallet to access collateral loans and P2P trading"
          />
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10">
      <UnifiedNavigation />
      
      <div className="container mx-auto px-4 pt-24 pb-16">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            P2P / Loan Platform
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Secure collateral loans and peer-to-peer SOL trading with escrow protection
          </p>
        </motion.div>

        <Tabs defaultValue="loans" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="loans" className="flex items-center gap-2">
              <Coins className="h-4 w-4" />
              Collateral Loans
            </TabsTrigger>
            <TabsTrigger value="p2p" className="flex items-center gap-2">
              <Handshake className="h-4 w-4" />
              P2P Trading
            </TabsTrigger>
          </TabsList>

          <TabsContent value="loans" className="space-y-8">
            {/* Create Loan */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Request a Loan
                </CardTitle>
                <CardDescription>
                  Deposit SOL as collateral and receive a loan at 50% LTV
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label>Collateral Amount (SOL)</Label>
                      <Input
                        type="number"
                        placeholder="0.0"
                        value={loanCollateral}
                        onChange={(e) => setLoanCollateral(e.target.value)}
                        min="0.1"
                        step="0.1"
                      />
                      <p className="text-xs text-muted-foreground mt-1">Minimum: 0.1 SOL</p>
                    </div>
                    
                    <div>
                      <Label>Loan Duration: {loanDuration[0]} days</Label>
                      <Slider
                        value={loanDuration}
                        onValueChange={setLoanDuration}
                        min={1}
                        max={14}
                        step={1}
                        className="mt-2"
                      />
                      <p className="text-xs text-muted-foreground mt-1">1-14 days</p>
                    </div>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                    <h4 className="font-semibold">Loan Summary</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Collateral:</span>
                        <span className="font-medium">{parseFloat(loanCollateral) || 0} SOL</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">LTV Ratio:</span>
                        <span className="font-medium">50%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Loan Amount:</span>
                        <span className="font-medium text-primary">
                          {calculateLoanAmount(parseFloat(loanCollateral) || 0).toFixed(4)} SOL
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Interest Rate:</span>
                        <span className="font-medium">{BASE_INTEREST_RATE}% / day</span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span className="text-muted-foreground">Total Repayment:</span>
                        <span className="font-bold text-lg">
                          {calculateRepayment(
                            calculateLoanAmount(parseFloat(loanCollateral) || 0),
                            loanDuration[0]
                          ).toFixed(4)} SOL
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleCreateLoan} 
                  className="w-full" 
                  size="lg"
                  disabled={processingLoan || escrowLoading}
                >
                  {(processingLoan || escrowLoading) && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  {processingLoan ? 'Sending Collateral to Escrow...' : 'Request Loan'}
                </Button>
              </CardContent>
            </Card>

            {/* My Loans */}
            {myLoans.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>My Loans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {myLoans.map((loan) => {
                      const repaymentAmount = calculateRepayment(loan.loan_amount_sol, loan.duration_days);
                      const isProcessing = processingRepayment === loan.id;
                      
                      return (
                        <div key={loan.id} className="p-4 bg-muted/50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="font-medium">
                              {loan.loan_amount_sol.toFixed(4)} SOL Loan
                            </div>
                            {getStatusBadge(loan.status)}
                          </div>
                          <div className="text-sm text-muted-foreground mb-2">
                            Collateral: {loan.collateral_sol} SOL • {loan.duration_days} days • {loan.interest_rate}%/day
                          </div>
                          {loan.due_at && (
                            <div className="text-xs text-muted-foreground mb-2">
                              Due: {new Date(loan.due_at).toLocaleDateString()}
                            </div>
                          )}
                          {loan.status === 'active' && (
                            <div className="flex items-center justify-between mt-3 pt-3 border-t">
                              <div className="text-sm">
                                <span className="text-muted-foreground">Repayment Amount: </span>
                                <span className="font-bold text-primary">{repaymentAmount.toFixed(4)} SOL</span>
                              </div>
                              <Button 
                                size="sm" 
                                onClick={() => handleRepayLoan(loan.id)}
                                disabled={isProcessing || escrowLoading}
                              >
                                {isProcessing && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                                {isProcessing ? 'Repaying...' : 'Repay Loan'}
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="p2p" className="space-y-8">
            {/* Create Trade */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5" />
                  Create P2P Trade
                </CardTitle>
                <CardDescription>
                  Sell SOL for fiat with secure escrow protection
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>SOL Amount to Sell</Label>
                    <Input
                      type="number"
                      placeholder="0.0"
                      value={tradeSolAmount}
                      onChange={(e) => setTradeSolAmount(e.target.value)}
                      min="0.01"
                      step="0.01"
                    />
                  </div>
                  <div>
                    <Label>Fiat Amount</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={tradeFiatAmount}
                        onChange={(e) => setTradeFiatAmount(e.target.value)}
                        min="1"
                      />
                      <Select value={tradeCurrency} onValueChange={setTradeCurrency}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD</SelectItem>
                          <SelectItem value="EUR">EUR</SelectItem>
                          <SelectItem value="GBP">GBP</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <div>
                  <Label>Payment Method</Label>
                  <Input
                    placeholder="e.g., PayPal, Bank Transfer, Wise"
                    value={tradePaymentMethod}
                    onChange={(e) => setTradePaymentMethod(e.target.value)}
                  />
                </div>
                <Button onClick={handleCreateTrade} className="w-full">
                  Create Trade Offer
                </Button>
              </CardContent>
            </Card>

            {/* Open Trades */}
            <Card>
              <CardHeader>
                <CardTitle>Available Trades</CardTitle>
                <CardDescription>Browse and accept P2P trade offers</CardDescription>
              </CardHeader>
              <CardContent>
                {loadingTrades ? (
                  <div className="text-center py-8 text-muted-foreground">Loading...</div>
                ) : p2pTrades.filter(t => t.escrow_status === 'open' && t.seller_wallet !== walletAddress).length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Handshake className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No open trades available</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {p2pTrades
                      .filter(t => t.escrow_status === 'open' && t.seller_wallet !== walletAddress)
                      .map((trade) => (
                        <div key={trade.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                          <div>
                            <div className="font-medium flex items-center gap-2">
                              <Coins className="h-4 w-4 text-primary" />
                              {trade.sol_amount} SOL
                              <ArrowRightLeft className="h-4 w-4" />
                              <DollarSign className="h-4 w-4 text-green-500" />
                              {trade.fiat_amount} {trade.fiat_currency}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Seller: {trade.seller_username || trade.seller_wallet.slice(0, 8)}...
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Payment: {trade.payment_method}
                            </div>
                          </div>
                          <Button 
                            onClick={() => handleAcceptTrade(trade.id)}
                            disabled={processingTrade || escrowLoading}
                          >
                            {processingTrade && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                            {processingTrade ? 'Sending to Escrow...' : 'Accept Trade'}
                          </Button>
                        </div>
                      ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* My Trades */}
            {myTrades.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>My Trades</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {myTrades.map((trade) => {
                      const isSeller = trade.seller_wallet === walletAddress;
                      const canConfirm = trade.escrow_status === 'locked' || 
                        trade.escrow_status === 'seller_confirmed' || 
                        trade.escrow_status === 'buyer_confirmed';
                      const alreadyConfirmed = isSeller ? trade.seller_confirmed : trade.buyer_confirmed;

                      return (
                        <div key={trade.id} className="p-4 bg-muted/50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="font-medium">
                              {trade.sol_amount} SOL ↔ {trade.fiat_amount} {trade.fiat_currency}
                            </div>
                            {getStatusBadge(trade.escrow_status)}
                          </div>
                          <div className="text-sm text-muted-foreground mb-2">
                            You are the {isSeller ? 'Seller' : 'Buyer'} • {trade.payment_method}
                          </div>
                          
                          {/* Disputed status info */}
                          {trade.escrow_status === 'disputed' && trade.dispute_reason && (
                            <div className="bg-destructive/10 rounded p-3 mb-3">
                              <p className="text-sm font-medium text-destructive">
                                Dispute Reason: {trade.dispute_reason}
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                An admin will review and resolve this dispute.
                              </p>
                            </div>
                          )}
                          
                          {trade.escrow_status === 'locked' && (
                            <div className="bg-primary/10 rounded p-3 mb-3">
                              <p className="text-sm font-medium text-primary">
                                {isSeller 
                                  ? "SOL is in escrow. Wait for buyer to pay, then confirm."
                                  : "SOL is in escrow. Complete payment via the specified method, then confirm."}
                              </p>
                            </div>
                          )}
                          
                          <div className="flex flex-wrap gap-2 mt-3">
                            {/* Cancel button for seller's open trades */}
                            {isSeller && trade.escrow_status === 'open' && (
                              <Button 
                                variant="outline"
                                size="sm"
                                onClick={() => handleCancelTrade(trade.id)}
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Cancel Trade
                              </Button>
                            )}
                            
                            {/* Confirm button */}
                            {canConfirm && !alreadyConfirmed && trade.escrow_status !== 'completed' && trade.escrow_status !== 'disputed' && (
                              <Button 
                                onClick={() => handleConfirmTrade(trade.id, isSeller)}
                                size="sm"
                              >
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Confirm {isSeller ? 'Payment Received' : 'Payment Sent'}
                              </Button>
                            )}
                            
                            {/* Raise Dispute button for locked/partially confirmed trades */}
                            {(trade.escrow_status === 'locked' || trade.escrow_status === 'seller_confirmed' || trade.escrow_status === 'buyer_confirmed') && (
                              <>
                                {showDisputeModal === trade.id ? (
                                  <div className="w-full mt-2 p-3 bg-muted rounded-lg">
                                    <Label className="text-sm">Dispute Reason</Label>
                                    <Input
                                      placeholder="Describe the issue..."
                                      value={disputeReason}
                                      onChange={(e) => setDisputeReason(e.target.value)}
                                      className="mt-1"
                                    />
                                    <div className="flex gap-2 mt-2">
                                      <Button 
                                        size="sm" 
                                        variant="destructive"
                                        onClick={() => handleRaiseDispute(trade.id)}
                                      >
                                        Submit Dispute
                                      </Button>
                                      <Button 
                                        size="sm" 
                                        variant="outline"
                                        onClick={() => {
                                          setShowDisputeModal(null);
                                          setDisputeReason('');
                                        }}
                                      >
                                        Cancel
                                      </Button>
                                    </div>
                                  </div>
                                ) : (
                                  <Button 
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setShowDisputeModal(trade.id)}
                                  >
                                    <AlertCircle className="h-4 w-4 mr-2" />
                                    Raise Dispute
                                  </Button>
                                )}
                              </>
                            )}
                          </div>
                          
                          {alreadyConfirmed && trade.escrow_status !== 'completed' && trade.escrow_status !== 'disputed' && (
                            <p className="text-sm text-muted-foreground mt-2">
                              ✓ You confirmed. Waiting for other party...
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* How It Works */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  How P2P Escrow Works
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="text-center p-4">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-2">
                      <span className="font-bold text-primary">1</span>
                    </div>
                    <p className="text-sm">Seller creates trade offer</p>
                  </div>
                  <div className="text-center p-4">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-2">
                      <span className="font-bold text-primary">2</span>
                    </div>
                    <p className="text-sm">Buyer accepts, SOL goes to escrow</p>
                  </div>
                  <div className="text-center p-4">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-2">
                      <span className="font-bold text-primary">3</span>
                    </div>
                    <p className="text-sm">Buyer sends fiat payment</p>
                  </div>
                  <div className="text-center p-4">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-2">
                      <span className="font-bold text-primary">4</span>
                    </div>
                    <p className="text-sm">Both confirm, SOL released</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  );
};

export default P2PLoan;