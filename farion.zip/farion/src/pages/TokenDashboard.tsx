import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Flame, Lock, TrendingUp, Users, ArrowLeft, Activity } from 'lucide-react';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useTokenData, CreatedToken } from '@/hooks/useTokenData';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

const TokenDashboard: React.FC = () => {
  const { tokenId } = useParams<{ tokenId: string }>();
  const navigate = useNavigate();
  const { walletAddress, username } = useMultiWallet();
  const { getTokenById } = useTokenData();
  const { toast } = useToast();
  
  const [token, setToken] = useState<CreatedToken | null>(null);
  const [loading, setLoading] = useState(true);
  const [burnAmount, setBurnAmount] = useState('');
  const [lockAmount, setLockAmount] = useState('');
  const [burnReason, setBurnReason] = useState('');
  const [lockReason, setLockReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const fetchToken = async () => {
      if (!tokenId) return;
      
      const tokenData = await getTokenById(tokenId);
      setToken(tokenData);
      setLoading(false);
    };

    fetchToken();
  }, [tokenId, getTokenById]);

  const handleBurnTokens = async () => {
    if (!token || !walletAddress || !username || !burnAmount) return;
    
    const amount = parseFloat(burnAmount);
    if (amount <= 0 || amount > token.current_supply) {
      toast({
        title: "Invalid burn amount",
        description: "Please enter a valid amount to burn",
        variant: "destructive"
      });
      return;
    }

    setActionLoading(true);
    try {
      // Record burn action
      const { error: actionError } = await supabase
        .from('token_dashboard_actions')
        .insert({
          token_id: token.id,
          wallet_address: walletAddress,
          username: username,
          action_type: 'burn',
          token_amount: amount,
          reason: burnReason
        });

      if (actionError) throw actionError;

      // Update token supply
      const newSupply = token.current_supply - amount;
      const { error: updateError } = await supabase
        .from('created_tokens')
        .update({ 
          current_supply: newSupply,
          updated_at: new Date().toISOString()
        })
        .eq('id', token.id);

      if (updateError) throw updateError;

      setToken(prev => prev ? { ...prev, current_supply: newSupply } : null);
      setBurnAmount('');
      setBurnReason('');
      
      toast({
        title: "Tokens burned successfully",
        description: `${amount} ${token.symbol} tokens have been burned`,
      });
    } catch (error) {
      console.error('Error burning tokens:', error);
      toast({
        title: "Failed to burn tokens",
        description: "There was an error burning the tokens",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleLockTokens = async () => {
    if (!token || !walletAddress || !username || !lockAmount) return;
    
    const amount = parseFloat(lockAmount);
    if (amount <= 0 || amount > token.current_supply) {
      toast({
        title: "Invalid lock amount",
        description: "Please enter a valid amount to lock",
        variant: "destructive"
      });
      return;
    }

    setActionLoading(true);
    try {
      // Record lock action
      const { error: actionError } = await supabase
        .from('token_dashboard_actions')
        .insert({
          token_id: token.id,
          wallet_address: walletAddress,
          username: username,
          action_type: 'lock',
          token_amount: amount,
          reason: lockReason
        });

      if (actionError) throw actionError;

      setLockAmount('');
      setLockReason('');
      
      toast({
        title: "Tokens locked successfully",
        description: `${amount} ${token.symbol} tokens have been locked`,
      });
    } catch (error) {
      console.error('Error locking tokens:', error);
      toast({
        title: "Failed to lock tokens",
        description: "There was an error locking the tokens",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="text-center">Loading token dashboard...</div>
        </div>
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-20">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Token not found</h1>
            <Button onClick={() => navigate('/launchpad')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Launchpad
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const isOwner = walletAddress === token.creator_wallet_address;
  const currentPrice = token.market_cap / token.current_supply;

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/launchpad')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-4">
              {token.logo_url && (
                <img
                  src={token.logo_url}
                  alt={token.name}
                  className="w-12 h-12 rounded-full"
                />
              )}
              <div>
                <h1 className="text-2xl font-bold">{token.name}</h1>
                <p className="text-muted-foreground">{token.symbol}</p>
              </div>
              {isOwner && (
                <Badge variant="secondary">Owner</Badge>
              )}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Market Cap
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${token.market_cap.toLocaleString()}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  Token Price
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${currentPrice.toFixed(6)}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Holders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{token.holders_count}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">
                  Tax Rate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{token.tax_percentage}%</div>
              </CardContent>
            </Card>
          </div>

          {/* Owner Controls */}
          {isOwner && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              {/* Burn Tokens */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Flame className="h-5 w-5" />
                    Burn Tokens
                  </CardTitle>
                  <CardDescription>
                    Permanently remove tokens from circulation
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Amount to burn</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={burnAmount}
                      onChange={(e) => setBurnAmount(e.target.value)}
                      max={token.current_supply}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Max: {token.current_supply.toLocaleString()} {token.symbol}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Reason (optional)</label>
                    <Textarea
                      placeholder="Why are you burning these tokens?"
                      value={burnReason}
                      onChange={(e) => setBurnReason(e.target.value)}
                      rows={2}
                    />
                  </div>
                  <Button
                    onClick={handleBurnTokens}
                    disabled={!burnAmount || actionLoading}
                    className="w-full"
                    variant="destructive"
                  >
                    <Flame className="h-4 w-4 mr-2" />
                    {actionLoading ? 'Burning...' : 'Burn Tokens'}
                  </Button>
                </CardContent>
              </Card>

              {/* Lock Tokens */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lock className="h-5 w-5" />
                    Lock Tokens
                  </CardTitle>
                  <CardDescription>
                    Temporarily lock tokens from circulation
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Amount to lock</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={lockAmount}
                      onChange={(e) => setLockAmount(e.target.value)}
                      max={token.current_supply}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Max: {token.current_supply.toLocaleString()} {token.symbol}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Reason (optional)</label>
                    <Textarea
                      placeholder="Why are you locking these tokens?"
                      value={lockReason}
                      onChange={(e) => setLockReason(e.target.value)}
                      rows={2}
                    />
                  </div>
                  <Button
                    onClick={handleLockTokens}
                    disabled={!lockAmount || actionLoading}
                    className="w-full"
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    {actionLoading ? 'Locking...' : 'Lock Tokens'}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Token Info */}
          <Card>
            <CardHeader>
              <CardTitle>Token Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Total Supply:</span>
                  <div className="font-mono">{token.total_supply.toLocaleString()} {token.symbol}</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Current Supply:</span>
                  <div className="font-mono">{token.current_supply.toLocaleString()} {token.symbol}</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Creator:</span>
                  <div className="font-mono text-sm">{token.creator_username}</div>
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Created:</span>
                  <div>{new Date(token.created_at).toLocaleDateString()}</div>
                </div>
              </div>
              {token.description && (
                <div>
                  <span className="text-sm font-medium text-muted-foreground">Description:</span>
                  <p className="mt-1">{token.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TokenDashboard;