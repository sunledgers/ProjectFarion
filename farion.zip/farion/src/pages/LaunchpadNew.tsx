import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useMeteoraLaunchpad, MeteoraToken } from '@/hooks/useMeteoraLaunchpad';
import { TOKEN_CREATION_FEE } from '@/config/meteora';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import Footer from '@/components/Footer';
import WalletConnector from '@/components/chat/WalletConnector';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Rocket, 
  TrendingUp, 
  Users, 
  Coins, 
  Plus, 
  Zap,
  Clock,
  Crown,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Search,
  Trophy,
  Upload,
  X,
  Wallet,
  Star,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

const LaunchpadNew = () => {
  const navigate = useNavigate();
  const { connected, walletAddress, username } = useMultiWallet();
  const { 
    tokens, 
    loading, 
    creating, 
    trading, 
    createToken, 
    buyTokens, 
    sellTokens,
    uploadLogo, 
    getUserHoldings,
    getAllUserHoldings,
    getBuyQuote,
    getSellQuote
  } = useMeteoraLaunchpad();
  
  const [userHoldings, setUserHoldings] = useState<Map<string, number>>(new Map());
  const [watchlist, setWatchlist] = useState<string[]>([]);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [tradeDialogOpen, setTradeDialogOpen] = useState(false);
  const [sellDialogOpen, setSellDialogOpen] = useState(false);
  const [selectedToken, setSelectedToken] = useState<MeteoraToken | null>(null);
  const [buyAmount, setBuyAmount] = useState('0.01');
  const [sellAmount, setSellAmount] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'marketcap' | 'progress'>('newest');
  
  // Create token form
  const [tokenName, setTokenName] = useState('');
  const [tokenSymbol, setTokenSymbol] = useState('');
  const [tokenDescription, setTokenDescription] = useState('');
  const [tokenLogo, setTokenLogo] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [creatorFee, setCreatorFee] = useState(1); // Default 1% creator fee

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Logo must be less than 5MB');
        return;
      }
      if (!file.type.startsWith('image/')) {
        toast.error('Please select an image file');
        return;
      }
      setTokenLogo(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearLogo = () => {
    setTokenLogo(null);
    setLogoPreview(null);
  };

  const handleCreateToken = async () => {
    if (!tokenName || !tokenSymbol) {
      toast.error('Please fill in all required fields');
      return;
    }

    let logoUrl: string | null = null;
    
    if (tokenLogo) {
      setUploadingLogo(true);
      logoUrl = await uploadLogo(tokenLogo);
      setUploadingLogo(false);
    }

    const result = await createToken(tokenName, tokenSymbol, tokenDescription, logoUrl, undefined, creatorFee);
    if (result) {
      setCreateDialogOpen(false);
      setTokenName('');
      setTokenSymbol('');
      setTokenDescription('');
      setTokenLogo(null);
      setLogoPreview(null);
      setCreatorFee(1); // Reset to default
    }
  };

  const handleBuyToken = async () => {
    if (!selectedToken) return;
    const amount = parseFloat(buyAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    const result = await buyTokens(selectedToken.id, amount);
    if (result.success) {
      setTradeDialogOpen(false);
      setBuyAmount('0.01');
      // Refresh holdings
      loadUserHoldings();
    }
  };

  const handleSellToken = async () => {
    if (!selectedToken) return;
    const amount = parseFloat(sellAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    
    const result = await sellTokens(selectedToken.id, amount);
    if (result.success) {
      setSellDialogOpen(false);
      setSellAmount('');
      // Refresh holdings
      loadUserHoldings();
    }
  };

  const openTradeDialog = (token: MeteoraToken) => {
    setSelectedToken(token);
    setTradeDialogOpen(true);
  };

  const openSellDialog = async (token: MeteoraToken) => {
    setSelectedToken(token);
    const balance = await getUserHoldings(token.id);
    setSellAmount(balance > 0 ? Math.floor(balance / 2).toString() : '');
    setSellDialogOpen(true);
  };

  // Load user holdings
  const loadUserHoldings = async () => {
    if (connected && walletAddress) {
      const holdings = await getAllUserHoldings();
      setUserHoldings(holdings);
    } else {
      setUserHoldings(new Map());
    }
  };

  React.useEffect(() => {
    loadUserHoldings();
  }, [connected, walletAddress, tokens]);

  // Load watchlist from localStorage
  React.useEffect(() => {
    if (walletAddress) {
      const saved = localStorage.getItem(`watchlist_${walletAddress}`);
      if (saved) {
        setWatchlist(JSON.parse(saved));
      }
    }
  }, [walletAddress]);

  const toggleWatchlist = (tokenId: string) => {
    let newWatchlist: string[];
    if (watchlist.includes(tokenId)) {
      newWatchlist = watchlist.filter(id => id !== tokenId);
    } else {
      newWatchlist = [...watchlist, tokenId];
    }
    setWatchlist(newWatchlist);
    if (walletAddress) {
      localStorage.setItem(`watchlist_${walletAddress}`, JSON.stringify(newWatchlist));
    }
  };

  // Filter and sort tokens
  const filteredTokens = tokens
    .filter(token => 
      token.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      token.symbol.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      switch (sortBy) {
        case 'marketcap': return b.marketCap - a.marketCap;
        case 'progress': return b.bondingCurveProgress - a.bondingCurveProgress;
        default: return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

  const graduatedTokens = filteredTokens.filter(t => t.isGraduated);
  const activeTokens = filteredTokens.filter(t => !t.isGraduated);
  const watchlistTokens = tokens.filter(t => watchlist.includes(t.id));
  
  // My tokens: created by user or held by user
  const createdTokens = tokens.filter(t => t.creatorWallet === walletAddress);
  const heldTokens = tokens.filter(t => 
    userHoldings.has(t.id) && 
    (userHoldings.get(t.id) || 0) > 0 && 
    t.creatorWallet !== walletAddress
  );
  const myTokensCount = createdTokens.length + heldTokens.length;


  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(2)}K`;
    return num.toFixed(2);
  };

  const formatPrice = (price: number): string => {
    if (price < 0.000001) return price.toExponential(2);
    if (price < 0.001) return price.toFixed(8);
    return price.toFixed(6);
  };

  const getTimeAgo = (dateString: string): string => {
    const seconds = Math.floor((Date.now() - new Date(dateString).getTime()) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="flex items-center justify-center pt-20 px-4">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mb-4">
                <Rocket className="h-8 w-8 text-white" />
              </div>
              <CardTitle>Farion Launchpad</CardTitle>
              <CardDescription>
                Connect your wallet to create and trade tokens
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WalletConnector />
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      <main className="container mx-auto px-4 py-8 pt-20 sm:pt-8 sm:ml-64 lg:ml-72">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-500 to-emerald-500 bg-clip-text text-transparent flex items-center gap-2">
                <Rocket className="h-8 w-8 text-green-500" />
                Farion Launchpad
              </h1>
              <p className="text-muted-foreground mt-1">
                Create and trade tokens with bonding curves • Powered by Meteora DBC
              </p>
            </div>
            
            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Token
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-green-500" />
                    Create New Token
                  </DialogTitle>
                  <DialogDescription>
                    Launch your token with a bonding curve. Symbol will end with FAR.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Creation Fee Notice */}
                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <p className="font-medium text-yellow-500">Platform Fee: {TOKEN_CREATION_FEE} SOL</p>
                      <p className="text-muted-foreground text-xs mt-0.5">
                        A one-time fee is required to create your token on-chain
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Token Name *</label>
                    <Input
                      placeholder="e.g., Moon Rocket"
                      value={tokenName}
                      onChange={(e) => setTokenName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Symbol *</label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="e.g., MOON"
                        value={tokenSymbol}
                        onChange={(e) => setTokenSymbol(e.target.value.toUpperCase())}
                        className="flex-1"
                      />
                      <Badge variant="outline" className="px-3 flex items-center">
                        {tokenSymbol || 'TOKEN'}FAR
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Description</label>
                    <Textarea
                      placeholder="Tell us about your token..."
                      value={tokenDescription}
                      onChange={(e) => setTokenDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Token Logo</label>
                    <div className="mt-2">
                      {logoPreview ? (
                        <div className="relative inline-block">
                          <img 
                            src={logoPreview} 
                            alt="Token logo preview" 
                            className="w-20 h-20 rounded-full object-cover border-2 border-green-500/30"
                          />
                          <button
                            type="button"
                            onClick={clearLogo}
                            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 hover:bg-destructive/80"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ) : (
                        <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-muted-foreground/30 rounded-lg cursor-pointer hover:border-green-500/50 transition-colors">
                          <div className="flex flex-col items-center justify-center pt-2 pb-2">
                            <Upload className="h-6 w-6 text-muted-foreground mb-1" />
                            <p className="text-xs text-muted-foreground">Click to upload logo</p>
                            <p className="text-xs text-muted-foreground/70">PNG, JPG up to 5MB</p>
                          </div>
                          <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*"
                            onChange={handleLogoChange}
                          />
                        </label>
                      )}
                    </div>
                  </div>
                  
                  {/* Creator Fee Slider */}
                  <div>
                    <label className="text-sm font-medium flex items-center justify-between">
                      <span>Creator Fee</span>
                      <span className="text-green-500 font-bold">{creatorFee}%</span>
                    </label>
                    <p className="text-xs text-muted-foreground mb-2">
                      Earn {creatorFee}% from every trade on your token
                    </p>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min="0"
                        max="5"
                        step="0.5"
                        value={creatorFee}
                        onChange={(e) => setCreatorFee(parseFloat(e.target.value))}
                        className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-green-500"
                      />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>0%</span>
                      <span>5%</span>
                    </div>
                    {creatorFee > 0 && (
                      <div className="mt-2 p-2 bg-green-500/10 rounded text-xs text-green-500">
                        💰 Example: On 1 SOL trade volume, you earn {(1 * creatorFee / 100).toFixed(4)} SOL
                      </div>
                    )}
                  </div>

                  <div className="p-3 bg-muted/50 rounded-lg text-sm space-y-1">
                    <p className="font-medium">Token Economics:</p>
                    <p className="text-muted-foreground">• Total Supply: 1,000,000,000</p>
                    <p className="text-muted-foreground">• Starting Price: 0.000001 SOL</p>
                    <p className="text-muted-foreground">• Graduation: 85% bonding curve filled</p>
                    <p className="text-muted-foreground">• Platform Fee: 1% + Creator Fee: {creatorFee}%</p>
                  </div>
                  <Button 
                    onClick={handleCreateToken}
                    disabled={creating || uploadingLogo || !tokenName || !tokenSymbol}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-500"
                  >
                    {creating || uploadingLogo ? (
                      <>
                        <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        {uploadingLogo ? 'Uploading Logo...' : 'Creating...'}
                      </>
                    ) : (
                      <>
                        <Rocket className="h-4 w-4 mr-2" />
                        Launch Token ({TOKEN_CREATION_FEE} SOL)
                      </>
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Coins className="h-4 w-4" />
                  Total Tokens
                </div>
                <p className="text-2xl font-bold">{tokens.length}</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Trophy className="h-4 w-4" />
                  Graduated
                </div>
                <p className="text-2xl font-bold">{graduatedTokens.length}</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <TrendingUp className="h-4 w-4" />
                  Active
                </div>
                <p className="text-2xl font-bold">{activeTokens.length}</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-pink-500/10 to-red-500/10 border-pink-500/20">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Users className="h-4 w-4" />
                  Total Holders
                </div>
                <p className="text-2xl font-bold">
                  {tokens.reduce((sum, t) => sum + t.holderCount, 0)}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tokens..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={sortBy === 'newest' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortBy('newest')}
              >
                <Clock className="h-4 w-4 mr-1" />
                Newest
              </Button>
              <Button
                variant={sortBy === 'marketcap' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortBy('marketcap')}
              >
                <Coins className="h-4 w-4 mr-1" />
                Market Cap
              </Button>
              <Button
                variant={sortBy === 'progress' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortBy('progress')}
              >
                <Zap className="h-4 w-4 mr-1" />
                Progress
              </Button>
            </div>
          </div>

          {/* Token Tabs */}
          <Tabs defaultValue="active" className="space-y-4">
            <TabsList>
              <TabsTrigger value="active" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Active ({activeTokens.length})
              </TabsTrigger>
              <TabsTrigger value="graduated" className="flex items-center gap-2">
                <Crown className="h-4 w-4" />
                Graduated ({graduatedTokens.length})
              </TabsTrigger>
              {connected && (
                <TabsTrigger value="my-tokens" className="flex items-center gap-2">
                  <Wallet className="h-4 w-4" />
                  My Tokens ({myTokensCount})
                </TabsTrigger>
              )}
              {connected && (
                <TabsTrigger value="watchlist" className="flex items-center gap-2">
                  <Star className="h-4 w-4" />
                  Watchlist ({watchlistTokens.length})
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="active">
              {loading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[1, 2, 3].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="pt-6">
                        <div className="h-12 bg-muted rounded mb-4" />
                        <div className="h-4 bg-muted rounded mb-2" />
                        <div className="h-4 bg-muted rounded w-2/3" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : activeTokens.length === 0 ? (
                <Card className="p-12 text-center">
                  <Rocket className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No Active Tokens</h3>
                  <p className="text-muted-foreground mb-4">Be the first to create a token!</p>
                  <Button onClick={() => setCreateDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Token
                  </Button>
                </Card>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <AnimatePresence>
                    {activeTokens.map((token, index) => (
                      <motion.div
                        key={token.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Card className="overflow-hidden hover:shadow-lg transition-all border-green-500/20 hover:border-green-500/40">
                          <CardContent className="pt-6 space-y-4">
                            {/* Token Header */}
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                {token.logoUrl ? (
                                  <img 
                                    src={token.logoUrl} 
                                    alt={token.name} 
                                    className="w-12 h-12 rounded-full object-cover border border-green-500/30"
                                  />
                                ) : (
                                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white font-bold text-lg">
                                    {token.symbol.charAt(0)}
                                  </div>
                                )}
                                <div>
                                  <h3 className="font-bold">{token.name}</h3>
                                  <p className="text-sm text-muted-foreground">${token.symbol}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {connected && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleWatchlist(token.id);
                                    }}
                                    className={`p-1 rounded-full transition-colors ${
                                      watchlist.includes(token.id)
                                        ? 'text-yellow-500 hover:text-yellow-600'
                                        : 'text-muted-foreground hover:text-yellow-500'
                                    }`}
                                  >
                                    <Star className={`h-4 w-4 ${watchlist.includes(token.id) ? 'fill-current' : ''}`} />
                                  </button>
                                )}
                                <Badge variant="outline" className="text-xs">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {getTimeAgo(token.createdAt)}
                                </Badge>
                              </div>
                            </div>

                            {/* Bonding Curve Progress */}
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Bonding Curve</span>
                                <span className="font-medium text-green-500">
                                  {token.bondingCurveProgress.toFixed(1)}%
                                </span>
                              </div>
                              <Progress value={token.bondingCurveProgress} className="h-2" />
                            </div>

                            {/* Stats */}
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <p className="text-muted-foreground">Price</p>
                                <p className="font-mono font-medium">{formatPrice(token.currentPrice)} SOL</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Market Cap</p>
                                <p className="font-medium">{formatNumber(token.marketCap)} SOL</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Holders</p>
                                <p className="font-medium">{token.holderCount}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">24h Volume</p>
                                <p className="font-medium">{formatNumber(token.volume24h)} SOL</p>
                              </div>
                            </div>

                            {/* User Holdings */}
                            {userHoldings.has(token.id) && (userHoldings.get(token.id) || 0) > 0 && (
                              <div className="p-2 bg-green-500/10 rounded-lg text-sm">
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Your Balance</span>
                                  <span className="font-medium text-green-500">
                                    {formatNumber(userHoldings.get(token.id) || 0)} {token.symbol}
                                  </span>
                                </div>
                              </div>
                            )}

                            <Separator />

                            {/* Actions */}
                            <div className="flex gap-2">
                              <Button 
                                variant="outline"
                                className="flex-1"
                                onClick={() => navigate(`/launchpad/token/${token.id}`)}
                              >
                                View
                              </Button>
                              <Button 
                                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                                onClick={() => openTradeDialog(token)}
                              >
                                <ArrowUpRight className="h-4 w-4 mr-1" />
                                Buy
                              </Button>
                              {userHoldings.has(token.id) && (userHoldings.get(token.id) || 0) > 0 && (
                                <Button 
                                  variant="outline"
                                  className="flex-1 border-red-500/30 text-red-500 hover:bg-red-500/10"
                                  onClick={() => openSellDialog(token)}
                                >
                                  <ArrowDownRight className="h-4 w-4 mr-1" />
                                  Sell
                                </Button>
                              )}
                            </div>

                            {/* Creator */}
                            <div className="text-xs text-muted-foreground text-center">
                              Created by {token.creatorUsername || token.creatorWallet.slice(0, 8) + '...'}
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </TabsContent>

            <TabsContent value="graduated">
              {graduatedTokens.length === 0 ? (
                <Card className="p-12 text-center">
                  <Crown className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No Graduated Tokens Yet</h3>
                  <p className="text-muted-foreground">
                    Tokens graduate when their bonding curve reaches 85%
                  </p>
                </Card>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {graduatedTokens.map((token) => (
                    <Card 
                      key={token.id} 
                      className="overflow-hidden border-yellow-500/30 cursor-pointer hover:shadow-lg transition-all"
                      onClick={() => navigate(`/launchpad/token/${token.id}`)}
                    >
                      <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-2 text-center text-white text-sm font-medium">
                        <Crown className="h-4 w-4 inline mr-1" />
                        Graduated
                      </div>
                      <CardContent className="pt-4 space-y-4">
                        <div className="flex items-center gap-3">
                          {token.logoUrl ? (
                            <img 
                              src={token.logoUrl} 
                              alt={token.name} 
                              className="w-10 h-10 rounded-full object-cover border border-yellow-500/30"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center text-white font-bold">
                              {token.symbol.charAt(0)}
                            </div>
                          )}
                          <div>
                            <h3 className="font-bold">{token.name}</h3>
                            <p className="text-sm text-muted-foreground">${token.symbol}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <p className="text-muted-foreground">Market Cap</p>
                            <p className="font-medium">{formatNumber(token.marketCap)} SOL</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Holders</p>
                            <p className="font-medium">{token.holderCount}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* My Tokens Tab */}
            {connected && (
              <TabsContent value="my-tokens">
                {myTokensCount === 0 ? (
                  <Card className="p-12 text-center">
                    <Wallet className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-xl font-semibold mb-2">No Tokens Yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Create a token or buy some to see them here
                    </p>
                    <Button onClick={() => setCreateDialogOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Token
                    </Button>
                  </Card>
                ) : (
                  <div className="space-y-6">
                    {/* Created Tokens Section */}
                    {createdTokens.length > 0 && (
                      <div>
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          <Sparkles className="h-5 w-5 text-green-500" />
                          Tokens You Created ({createdTokens.length})
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                          {createdTokens.map((token) => (
                            <Card 
                              key={token.id}
                              className="overflow-hidden hover:shadow-lg transition-all border-green-500/20 hover:border-green-500/40 cursor-pointer"
                              onClick={() => navigate(`/launchpad/token/${token.id}`)}
                            >
                              <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-2 text-center text-white text-sm font-medium">
                                <Sparkles className="h-4 w-4 inline mr-1" />
                                Your Creation
                              </div>
                              <CardContent className="pt-4 space-y-4">
                                <div className="flex items-center gap-3">
                                  {token.logoUrl ? (
                                    <img 
                                      src={token.logoUrl} 
                                      alt={token.name} 
                                      className="w-10 h-10 rounded-full object-cover border border-green-500/30"
                                    />
                                  ) : (
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white font-bold">
                                      {token.symbol.charAt(0)}
                                    </div>
                                  )}
                                  <div>
                                    <h3 className="font-bold">{token.name}</h3>
                                    <p className="text-sm text-muted-foreground">${token.symbol}</p>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Bonding Curve</span>
                                    <span className="font-medium text-green-500">
                                      {token.bondingCurveProgress.toFixed(1)}%
                                    </span>
                                  </div>
                                  <Progress value={token.bondingCurveProgress} className="h-2" />
                                </div>
                                <div className="grid grid-cols-2 gap-2 text-sm">
                                  <div>
                                    <p className="text-muted-foreground">Market Cap</p>
                                    <p className="font-medium">{formatNumber(token.marketCap)} SOL</p>
                                  </div>
                                  <div>
                                    <p className="text-muted-foreground">Holders</p>
                                    <p className="font-medium">{token.holderCount}</p>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Held Tokens Section */}
                    {heldTokens.length > 0 && (
                      <div>
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          <Coins className="h-5 w-5 text-blue-500" />
                          Tokens You Hold ({heldTokens.length})
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                          {heldTokens.map((token) => {
                            const balance = userHoldings.get(token.id) || 0;
                            return (
                              <Card 
                                key={token.id}
                                className="overflow-hidden hover:shadow-lg transition-all border-blue-500/20 hover:border-blue-500/40"
                              >
                                <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 text-center text-white text-sm font-medium">
                                  <Wallet className="h-4 w-4 inline mr-1" />
                                  Holding: {formatNumber(balance)} {token.symbol}
                                </div>
                                <CardContent className="pt-4 space-y-4">
                                  <div className="flex items-center gap-3">
                                    {token.logoUrl ? (
                                      <img 
                                        src={token.logoUrl} 
                                        alt={token.name} 
                                        className="w-10 h-10 rounded-full object-cover border border-blue-500/30"
                                      />
                                    ) : (
                                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold">
                                        {token.symbol.charAt(0)}
                                      </div>
                                    )}
                                    <div>
                                      <h3 className="font-bold">{token.name}</h3>
                                      <p className="text-sm text-muted-foreground">${token.symbol}</p>
                                    </div>
                                  </div>
                                  <div className="grid grid-cols-2 gap-2 text-sm">
                                    <div>
                                      <p className="text-muted-foreground">Your Value</p>
                                      <p className="font-medium">
                                        {formatPrice(balance * token.currentPrice)} SOL
                                      </p>
                                    </div>
                                    <div>
                                      <p className="text-muted-foreground">Price</p>
                                      <p className="font-mono font-medium">{formatPrice(token.currentPrice)}</p>
                                    </div>
                                  </div>
                                  <div className="flex gap-2">
                                    <Button 
                                      className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500"
                                      size="sm"
                                      onClick={() => openTradeDialog(token)}
                                    >
                                      Buy More
                                    </Button>
                                    <Button 
                                      variant="outline"
                                      className="flex-1 border-red-500/30 text-red-500 hover:bg-red-500/10"
                                      size="sm"
                                      onClick={() => openSellDialog(token)}
                                    >
                                      Sell
                                    </Button>
                                  </div>
                                </CardContent>
                              </Card>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </TabsContent>
            )}

            {/* Watchlist Tab */}
            {connected && (
              <TabsContent value="watchlist">
                {watchlistTokens.length === 0 ? (
                  <Card className="p-12 text-center">
                    <Star className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-xl font-semibold mb-2">Your Watchlist is Empty</h3>
                    <p className="text-muted-foreground">
                      Click the star icon on any token to add it to your watchlist
                    </p>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {watchlistTokens.map((token) => (
                      <Card 
                        key={token.id} 
                        className="overflow-hidden border-yellow-500/20 hover:border-yellow-500/40 cursor-pointer hover:shadow-lg transition-all"
                        onClick={() => navigate(`/launchpad/token/${token.id}`)}
                      >
                        <CardContent className="pt-6 space-y-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              {token.logoUrl ? (
                                <img 
                                  src={token.logoUrl} 
                                  alt={token.name} 
                                  className="w-12 h-12 rounded-full object-cover border border-yellow-500/30"
                                />
                              ) : (
                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center text-white font-bold text-lg">
                                  {token.symbol.charAt(0)}
                                </div>
                              )}
                              <div>
                                <h3 className="font-bold">{token.name}</h3>
                                <p className="text-sm text-muted-foreground">${token.symbol}</p>
                              </div>
                            </div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleWatchlist(token.id);
                              }}
                              className="text-yellow-500 hover:text-yellow-600 p-1"
                            >
                              <Star className="h-5 w-5 fill-current" />
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-muted-foreground">Price</p>
                              <p className="font-mono font-medium">{formatPrice(token.currentPrice)} SOL</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Market Cap</p>
                              <p className="font-medium">{formatNumber(token.marketCap)} SOL</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Progress</p>
                              <p className="font-medium text-green-500">{token.bondingCurveProgress.toFixed(1)}%</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Holders</p>
                              <p className="font-medium">{token.holderCount}</p>
                            </div>
                          </div>
                          <Button 
                            className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                            onClick={(e) => {
                              e.stopPropagation();
                              openTradeDialog(token);
                            }}
                          >
                            <ArrowUpRight className="h-4 w-4 mr-1" />
                            Quick Buy
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            )}
          </Tabs>
        </motion.div>
      </main>

      {/* Buy Dialog */}
      <Dialog open={tradeDialogOpen} onOpenChange={setTradeDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowUpRight className="h-5 w-5 text-green-500" />
              Buy {selectedToken?.symbol}
            </DialogTitle>
            <DialogDescription>
              Current price: {selectedToken ? formatPrice(selectedToken.currentPrice) : '0'} SOL
            </DialogDescription>
          </DialogHeader>
          {selectedToken && (
            <div className="space-y-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <Progress value={selectedToken.bondingCurveProgress} className="h-2 mb-2" />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Bonding Curve Progress</span>
                  <span className="font-medium">{selectedToken.bondingCurveProgress.toFixed(1)}%</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Amount (SOL)</label>
                <Input
                  type="number"
                  placeholder="0.01"
                  value={buyAmount}
                  onChange={(e) => setBuyAmount(e.target.value)}
                  min="0.001"
                  step="0.001"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  You'll receive ~{((parseFloat(buyAmount) || 0) / selectedToken.currentPrice).toLocaleString()} {selectedToken.symbol}
                </p>
              </div>

              <div className="flex gap-2">
                {[0.01, 0.05, 0.1, 0.5].map((amount) => (
                  <Button
                    key={amount}
                    variant="outline"
                    size="sm"
                    onClick={() => setBuyAmount(amount.toString())}
                    className="flex-1"
                  >
                    {amount} SOL
                  </Button>
                ))}
              </div>

              <Button
                onClick={handleBuyToken}
                disabled={trading}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500"
              >
                {trading ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <ArrowUpRight className="h-4 w-4 mr-2" />
                    Buy {selectedToken.symbol}
                  </>
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Sell Dialog */}
      <Dialog open={sellDialogOpen} onOpenChange={setSellDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowDownRight className="h-5 w-5 text-red-500" />
              Sell {selectedToken?.symbol}
            </DialogTitle>
            <DialogDescription>
              Current price: {selectedToken ? formatPrice(selectedToken.currentPrice) : '0'} SOL
            </DialogDescription>
          </DialogHeader>
          {selectedToken && (
            <div className="space-y-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Your Balance</span>
                  <span className="font-medium">{formatNumber(userHoldings.get(selectedToken.id) || 0)} {selectedToken.symbol}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Estimated Value</span>
                  <span className="font-medium">{formatPrice((userHoldings.get(selectedToken.id) || 0) * selectedToken.currentPrice)} SOL</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Amount to Sell</label>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={sellAmount}
                  onChange={(e) => setSellAmount(e.target.value)}
                  min="1"
                  step="1"
                />
                {parseFloat(sellAmount) > 0 && (
                  <div className="text-xs mt-2 space-y-1">
                    <p className="text-muted-foreground">
                      You'll receive ~{formatPrice((parseFloat(sellAmount) || 0) * selectedToken.currentPrice * 0.99)} SOL
                    </p>
                    <p className="text-yellow-500">
                      Fee (1%): {formatPrice((parseFloat(sellAmount) || 0) * selectedToken.currentPrice * 0.01)} SOL
                    </p>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                {[25, 50, 75, 100].map((pct) => {
                  const balance = userHoldings.get(selectedToken.id) || 0;
                  const amount = Math.floor(balance * (pct / 100));
                  return (
                    <Button
                      key={pct}
                      variant="outline"
                      size="sm"
                      onClick={() => setSellAmount(amount.toString())}
                      className="flex-1"
                    >
                      {pct}%
                    </Button>
                  );
                })}
              </div>

              <Button
                onClick={handleSellToken}
                disabled={trading || !sellAmount || parseFloat(sellAmount) <= 0}
                className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600"
              >
                {trading ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <ArrowDownRight className="h-4 w-4 mr-2" />
                    Sell {selectedToken.symbol}
                  </>
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default LaunchpadNew;
