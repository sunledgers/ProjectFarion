import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MessageSquare, Clock, User } from 'lucide-react';
import { motion } from 'framer-motion';

import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';
import UnifiedNavigation from '@/components/UnifiedNavigation';

interface Thread {
  id: string;
  title: string;
  content: string;
  image_path: string;
  username: string;
  wallet_address: string;
  supply_percentage: number | null;
  reply_count: number;
  created_at: string;
}

interface Post {
  id: string;
  content: string;
  image_path?: string;
  username: string;
  wallet_address: string;
  supply_percentage: number | null;
  created_at: string;
}

const ThreadView = () => {
  const { board, threadId } = useParams<{ board: string; threadId: string }>();
  const { connected, walletAddress, username } = useMultiWallet();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [thread, setThread] = useState<Thread | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyContent, setReplyContent] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (threadId) {
      loadThread();
      loadPosts();
    }
  }, [threadId]);

  const loadThread = async () => {
    try {
      const { data, error } = await supabase
        .from('forum_threads')
        .select('*')
        .eq('id', threadId)
        .single();

      if (error) throw error;
      setThread(data);
    } catch (error) {
      console.error('Error loading thread:', error);
    }
  };

  const loadPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('forum_posts')
        .select('*')
        .eq('thread_id', threadId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive"
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image under 10MB",
        variant: "destructive"
      });
      return;
    }

    setSelectedFile(file);
  };

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!connected || !walletAddress || !username) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to reply",
        variant: "destructive"
      });
      return;
    }


    if (!replyContent.trim()) {
      toast({
        title: "Missing content",
        description: "Please write a reply",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);

    try {
      let imagePath = null;

      // Upload image if selected
      if (selectedFile) {
        const fileExt = selectedFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('forum-images')
          .upload(fileName, selectedFile);

        if (uploadError) throw uploadError;
        imagePath = fileName;
      }

      // Verify token holdings
      const { data: verificationData } = await supabase.functions.invoke('verify-token-holdings', {
        body: { walletAddress }
      });

      // Create post
      const { error: postError } = await supabase
        .from('forum_posts')
        .insert({
          thread_id: threadId,
          content: replyContent.trim(),
          image_path: imagePath,
          wallet_address: walletAddress,
          username,
          token_balance: verificationData?.tokenBalance || 0,
          supply_percentage: verificationData?.supplyPercentage || 0,
          verification_status: verificationData?.verificationStatus || 'no_tokens'
        });

      if (postError) throw postError;

      toast({
        title: "Reply posted!",
        description: "Your reply has been added successfully"
      });

      // Reset form
      setReplyContent('');
      setSelectedFile(null);
      
      // Reload posts
      loadPosts();
      loadThread(); // Refresh reply count

    } catch (error) {
      console.error('Error posting reply:', error);
      toast({
        title: "Error posting reply",
        description: "Please try again later",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getVerificationBadge = (percentage: number | null) => {
    if (!percentage) return <Badge variant="secondary">Not Verified</Badge>;
    
    if (percentage >= 1) return <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black">Whale 🐋</Badge>;
    if (percentage >= 0.1) return <Badge className="bg-gradient-to-r from-purple-500 to-purple-700">Big Holder 💎</Badge>;
    if (percentage >= 0.01) return <Badge className="bg-gradient-to-r from-blue-500 to-blue-700">Holder 📈</Badge>;
    return <Badge variant="outline">Small Bag 💼</Badge>;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getImageUrl = (path: string) => {
    return `https://qkbivmakdasuupmiigbp.supabase.co/storage/v1/object/public/forum-images/${path}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 pt-20">
          <div className="text-center py-8">Loading thread...</div>
        </div>
      </div>
    );
  }

  if (!thread) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 pt-20">
          <Card>
            <CardContent className="pt-6 text-center">
              <p>Thread not found</p>
              <Link to={`/forum/${board}`}>
                <Button className="mt-4">Back to Board</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="container mx-auto px-4 pt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="mb-6">
            <Link to={`/forum/${board}`}>
              <Button variant="outline" className="mb-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to /{board}/
              </Button>
            </Link>
          </div>

          {/* Original Thread */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-2xl">{thread.title}</CardTitle>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span className="font-medium">{thread.username}</span>
                  {getVerificationBadge(thread.supply_percentage)}
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {formatDate(thread.created_at)}
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <MessageSquare className="h-4 w-4" />
                  {thread.reply_count} replies
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <p className="whitespace-pre-wrap">{thread.content}</p>
              </div>
              {thread.image_path && (
                <img
                  src={getImageUrl(thread.image_path)}
                  alt="Thread image"
                  className="max-w-full rounded-lg"
                />
              )}
            </CardContent>
          </Card>

          {/* Replies */}
          <div className="space-y-4 mb-8">
            {posts.map((post) => (
              <Card key={post.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 text-sm mb-4">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      <span className="font-medium">{post.username}</span>
                      {getVerificationBadge(post.supply_percentage)}
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      {formatDate(post.created_at)}
                    </div>
                  </div>
                  <div className="mb-4">
                    <p className="whitespace-pre-wrap">{post.content}</p>
                  </div>
                  {post.image_path && (
                    <img
                      src={getImageUrl(post.image_path)}
                      alt="Post image"
                      className="max-w-full rounded-lg"
                    />
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Reply Form */}
          {connected ? (
            <Card>
              <CardHeader>
                <CardTitle>Post Reply</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleReply} className="space-y-4">
                  <Textarea
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    placeholder="Write your reply..."
                    rows={6}
                    required
                  />

                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Optional Image
                    </label>
                    <div className="flex items-center gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        Choose Image
                      </Button>
                      {selectedFile && (
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{selectedFile.name}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedFile(null)}
                          >
                            Remove
                          </Button>
                        </div>
                      )}
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                      className="hidden"
                    />
                  </div>


                  <Button
                    type="submit"
                    disabled={submitting}
                    className="w-full"
                  >
                    {submitting ? 'Posting...' : 'Post Reply'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">
                  Connect your wallet to post a reply
                </p>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default ThreadView;