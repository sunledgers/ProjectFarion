import React, { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Upload, Image as ImageIcon, Wallet, Trophy, Clock, Shield, Gift, Coins, MessageCircle, Heart, Crown, Medal } from 'lucide-react';
import WalletConnector from '@/components/chat/WalletConnector';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { PROJECT_WALLET } from '@/config/wallets';


interface MemeUpload {
  id: string;
  wallet_address: string;
  username: string;
  filename: string;
  file_path: string;
  file_size: number;
  content_type: string;
  token_balance: number | null;
  supply_percentage: number | null;
  verification_status: string;
  created_at: string;
  donation_amount?: number;
}

interface MemeStats {
  [key: string]: { donations: number; comments: number };
}

interface CreatorLeaderboard {
  wallet_address: string;
  username: string;
  total_donations: number;
  meme_count: number;
  total_comments: number;
}

const Memes: React.FC = () => {
  const navigate = useNavigate();
  const { connected, walletAddress, username, selectedWallet } = useMultiWallet();
  const [uploads, setUploads] = useState<MemeUpload[]>([]);
  const [memeStats, setMemeStats] = useState<MemeStats>({});
  const [leaderboard, setLeaderboard] = useState<CreatorLeaderboard[]>([]);
  const [loading, setLoading] = useState(false);
  const [leaderboardLoading, setLeaderboardLoading] = useState(false);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [donationAmount, setDonationAmount] = useState([0]);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [activeTab, setActiveTab] = useState('gallery');

  // Load uploaded memes with stats
  const loadMemes = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('meme_uploads')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUploads(data || []);

      // Load donation and comment counts
      if (data && data.length > 0) {
        const memeIds = data.map(m => m.id);
        
        const [donationsRes, commentsRes] = await Promise.all([
          supabase.from('meme_donations').select('meme_id, amount').in('meme_id', memeIds),
          supabase.from('meme_comments').select('meme_id').in('meme_id', memeIds)
        ]);

        const stats: MemeStats = {};
        memeIds.forEach(id => {
          stats[id] = { donations: 0, comments: 0 };
        });

        donationsRes.data?.forEach(d => {
          if (stats[d.meme_id]) {
            stats[d.meme_id].donations += Number(d.amount);
          }
        });

        commentsRes.data?.forEach(c => {
          if (stats[c.meme_id]) {
            stats[c.meme_id].comments += 1;
          }
        });

        setMemeStats(stats);
      }
    } catch (error) {
      console.error('Error loading memes:', error);
      toast.error('Failed to load memes');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMemes();
  }, [loadMemes]);

  // Load leaderboard
  const loadLeaderboard = useCallback(async () => {
    setLeaderboardLoading(true);
    try {
      // Get all meme uploads
      const { data: memes, error: memesError } = await supabase
        .from('meme_uploads')
        .select('id, wallet_address, username');

      if (memesError) throw memesError;
      if (!memes || memes.length === 0) {
        setLeaderboard([]);
        return;
      }

      // Get all donations
      const { data: donations, error: donationsError } = await supabase
        .from('meme_donations')
        .select('meme_id, amount');

      if (donationsError) throw donationsError;

      // Get all comments
      const { data: comments, error: commentsError } = await supabase
        .from('meme_comments')
        .select('meme_id');

      if (commentsError) throw commentsError;

      // Build meme to creator mapping
      const memeToCreator: { [memeId: string]: { wallet: string; username: string } } = {};
      memes.forEach(m => {
        memeToCreator[m.id] = { wallet: m.wallet_address, username: m.username };
      });

      // Aggregate by creator
      const creatorStats: { [wallet: string]: CreatorLeaderboard } = {};

      memes.forEach(m => {
        if (!creatorStats[m.wallet_address]) {
          creatorStats[m.wallet_address] = {
            wallet_address: m.wallet_address,
            username: m.username,
            total_donations: 0,
            meme_count: 0,
            total_comments: 0
          };
        }
        creatorStats[m.wallet_address].meme_count += 1;
      });

      donations?.forEach(d => {
        const creator = memeToCreator[d.meme_id];
        if (creator && creatorStats[creator.wallet]) {
          creatorStats[creator.wallet].total_donations += Number(d.amount);
        }
      });

      comments?.forEach(c => {
        const creator = memeToCreator[c.meme_id];
        if (creator && creatorStats[creator.wallet]) {
          creatorStats[creator.wallet].total_comments += 1;
        }
      });

      // Sort by total donations
      const sorted = Object.values(creatorStats)
        .sort((a, b) => b.total_donations - a.total_donations)
        .slice(0, 20);

      setLeaderboard(sorted);
    } catch (error) {
      console.error('Error loading leaderboard:', error);
    } finally {
      setLeaderboardLoading(false);
    }
  }, []);

  useEffect(() => {
    if (activeTab === 'leaderboard') {
      loadLeaderboard();
    }
  }, [activeTab, loadLeaderboard]);

  // Process SOL donation
  const processDonation = async (amount: number): Promise<string | null> => {
    if (amount <= 0 || !selectedWallet?.adapter || !walletAddress) return null;

    try {
      const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=848e04fa-8f26-4116-baca-c2cef9d75186', 'confirmed');
      const fromPubkey = new PublicKey(walletAddress);
      const toPubkey = new PublicKey(PROJECT_WALLET);
      const lamports = Math.floor(amount * LAMPORTS_PER_SOL);

      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey,
          toPubkey,
          lamports,
        })
      );

      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
      transaction.recentBlockhash = blockhash;
      transaction.feePayer = fromPubkey;

      let signature: string;
      if ('sendTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.sendTransaction === 'function') {
        signature = await selectedWallet.adapter.sendTransaction(transaction, connection);
      } else if ('signTransaction' in selectedWallet.adapter && typeof selectedWallet.adapter.signTransaction === 'function') {
        const signedTx = await selectedWallet.adapter.signTransaction(transaction);
        signature = await connection.sendRawTransaction(signedTx.serialize());
      } else {
        throw new Error('Wallet does not support transaction signing');
      }

      await connection.confirmTransaction({ signature, blockhash, lastValidBlockHeight }, 'confirmed');
      return signature;
    } catch (error) {
      console.error('Donation error:', error);
      throw error;
    }
  };

  // Handle file upload with optional donation
  const handleFileUpload = async (file: File, donation: number = 0) => {
    if (!connected || !walletAddress || !username) {
      toast.error('Please connect your wallet first');
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size must be less than 5MB');
      return;
    }

    setUploadLoading(true);
    let donationTxSignature: string | null = null;

    try {
      // Process donation first if any
      if (donation > 0) {
        toast.info(`Processing ${donation} SOL tip...`);
        donationTxSignature = await processDonation(donation);
        if (donationTxSignature) {
          toast.success(`Tip of ${donation} SOL sent! Thank you!`);
        }
      }

      // Generate unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `${walletAddress}/${fileName}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('memes')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Verify token holdings
      const { data: tokenData, error: tokenError } = await supabase.functions
        .invoke('verify-token-holdings', {
          body: { walletAddress }
        });

      if (tokenError) {
        console.error('Token verification error:', tokenError);
      }

      // Save upload record with donation info
      const { error: dbError } = await supabase
        .from('meme_uploads')
        .insert({
          wallet_address: walletAddress,
          username: username,
          filename: file.name,
          file_path: filePath,
          file_size: file.size,
          content_type: file.type,
          token_balance: tokenData?.tokenBalance || null,
          supply_percentage: tokenData?.supplyPercentage || null,
          verification_status: tokenData?.verificationStatus || 'pending',
          donation_amount: donation,
          donation_tx_signature: donationTxSignature
        } as any);

      if (dbError) throw dbError;

      toast.success('Meme uploaded successfully!');
      setPendingFile(null);
      setDonationAmount([0]);
      loadMemes();
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload meme');
    } finally {
      setUploadLoading(false);
    }
  };

  // Drag and drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  const getImageUrl = (filePath: string) => {
    try {
      const { data } = supabase.storage.from('memes').getPublicUrl(filePath);
      console.log('Generated image URL:', data.publicUrl);
      return data.publicUrl;
    } catch (error) {
      console.error('Error generating image URL:', error);
      return '/placeholder.svg';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getVerificationBadge = (status: string, percentage: number | null) => {
    if (!percentage || percentage === 0) {
      return <Badge variant="outline">No Tokens</Badge>;
    }
    
    if (percentage > 1) {
      return <Badge className="bg-gold text-black">Whale 🐋</Badge>;
    }
    
    if (percentage > 0.1) {
      return <Badge variant="default">Diamond Hands 💎</Badge>;
    }
    
    return <Badge variant="secondary">Holder 🚀</Badge>;
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="flex items-center justify-center pt-20">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ImageIcon className="h-5 w-5" />
                Meme Gallery
              </CardTitle>
              <CardDescription>
                Connect your wallet to upload and view memes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WalletConnector />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      <div className="p-4 md:p-8 pt-20">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6 text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              Farion Meme Gallery
            </h1>
            <p className="text-muted-foreground">
              Share your best memes and show off your FARION holdings
            </p>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-6">
              <TabsTrigger value="gallery" className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4" />
                Gallery
              </TabsTrigger>
              <TabsTrigger value="leaderboard" className="flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Top Creators
              </TabsTrigger>
            </TabsList>

            <TabsContent value="gallery">

          {/* Upload Section with Donation */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload Meme
              </CardTitle>
              <CardDescription>
                Upload images to share with the community. Optionally tip the project with SOL!
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* File Drop Zone */}
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive 
                    ? 'border-primary bg-primary/5' 
                    : pendingFile
                    ? 'border-green-500 bg-green-500/5'
                    : 'border-border hover:border-primary/50'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                {pendingFile ? (
                  <div className="space-y-2">
                    <ImageIcon className="h-12 w-12 mx-auto text-green-500" />
                    <p className="text-lg font-medium text-green-600">{pendingFile.name}</p>
                    <p className="text-sm text-muted-foreground">Ready to upload</p>
                  </div>
                ) : (
                  <>
                    <ImageIcon className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-lg font-medium mb-2">
                      {dragActive ? 'Drop your meme here!' : 'Drag & drop your meme here'}
                    </p>
                    <p className="text-muted-foreground mb-4">
                      Supports JPG, PNG, GIF (max 5MB)
                    </p>
                  </>
                )}
                <div className="space-y-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setPendingFile(e.target.files[0]);
                      }
                    }}
                    className="hidden"
                    id="file-upload"
                    disabled={uploadLoading}
                  />
                  <label htmlFor="file-upload">
                    <Button asChild variant={pendingFile ? "outline" : "default"} disabled={uploadLoading}>
                      <span className="cursor-pointer">
                        {pendingFile ? 'Change File' : 'Choose File'}
                      </span>
                    </Button>
                  </label>
                </div>
              </div>

              {/* Donation Slider - Show when file is selected */}
              {pendingFile && (
                <div className="p-4 bg-gradient-to-r from-pink-500/10 to-orange-500/10 rounded-lg border border-pink-500/20 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Gift className="h-5 w-5 text-pink-500" />
                      <span className="font-medium">Tip the Project (Optional)</span>
                    </div>
                    <Badge variant="outline" className="font-mono">
                      <Coins className="h-3 w-3 mr-1" />
                      {donationAmount[0].toFixed(2)} SOL
                    </Badge>
                  </div>
                  <Slider
                    value={donationAmount}
                    onValueChange={setDonationAmount}
                    min={0}
                    max={1}
                    step={0.01}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Free</span>
                    <span>0.25 SOL</span>
                    <span>0.5 SOL</span>
                    <span>1 SOL</span>
                  </div>
                  {donationAmount[0] > 0 && (
                    <p className="text-sm text-center text-pink-600">
                      Thank you for supporting Farion development! 💖
                    </p>
                  )}
                </div>
              )}

              {/* Upload Button */}
              {pendingFile && (
                <Button
                  onClick={() => handleFileUpload(pendingFile, donationAmount[0])}
                  disabled={uploadLoading}
                  className="w-full h-12 text-lg bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600"
                >
                  {uploadLoading ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      {donationAmount[0] > 0 ? 'Processing...' : 'Uploading...'}
                    </>
                  ) : (
                    <>
                      <Upload className="h-5 w-5 mr-2" />
                      Upload Meme {donationAmount[0] > 0 && `+ Tip ${donationAmount[0]} SOL`}
                    </>
                  )}
                </Button>
              )}

              <div className="flex items-center gap-2 text-xs text-muted-foreground justify-center">
                <Wallet className="h-3 w-3" />
                Connected: {username}
              </div>
            </CardContent>
          </Card>

          {/* Memes Gallery */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {loading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="aspect-square bg-muted rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <div className="h-4 bg-muted rounded mb-2"></div>
                    <div className="h-3 bg-muted rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))
            ) : uploads.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <ImageIcon className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No memes uploaded yet</h3>
                <p className="text-muted-foreground">Be the first to share a meme!</p>
              </div>
            ) : (
              uploads.map((upload) => {
                const stats = memeStats[upload.id] || { donations: 0, comments: 0 };
                return (
                  <Card 
                    key={upload.id} 
                    className="overflow-hidden hover:shadow-lg transition-all cursor-pointer hover:scale-[1.02] hover:border-primary/50"
                    onClick={() => navigate(`/memes/${upload.id}`)}
                  >
                    <div className="aspect-square overflow-hidden bg-muted">
                      <img
                        src={getImageUrl(upload.file_path)}
                        alt={upload.filename}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          console.error('Image failed to load:', upload.file_path);
                          e.currentTarget.src = '/placeholder.svg';
                        }}
                      />
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm truncate">
                          {upload.username}
                        </span>
                        {getVerificationBadge(upload.verification_status, upload.supply_percentage)}
                      </div>
                      
                      {/* Stats Row */}
                      <div className="flex items-center gap-3 mb-2 text-xs text-muted-foreground">
                        {stats.donations > 0 && (
                          <div className="flex items-center text-yellow-500">
                            <Heart className="h-3 w-3 mr-1 fill-current" />
                            {stats.donations.toFixed(2)} SOL
                          </div>
                        )}
                        <div className="flex items-center">
                          <MessageCircle className="h-3 w-3 mr-1" />
                          {stats.comments}
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatDate(upload.created_at)}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
            </TabsContent>

            {/* Leaderboard Tab */}
            <TabsContent value="leaderboard">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-yellow-500" />
                    Top Meme Creators
                  </CardTitle>
                  <CardDescription>
                    Ranked by total SOL donations received
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {leaderboardLoading ? (
                    <div className="space-y-3">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div key={i} className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 animate-pulse">
                          <div className="w-8 h-8 rounded-full bg-muted" />
                          <div className="flex-1">
                            <div className="h-4 bg-muted rounded w-1/3 mb-2" />
                            <div className="h-3 bg-muted rounded w-1/4" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : leaderboard.length === 0 ? (
                    <div className="text-center py-12">
                      <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground">No donations yet. Be the first to support a creator!</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {leaderboard.map((creator, index) => (
                        <div 
                          key={creator.wallet_address}
                          className={`flex items-center gap-4 p-4 rounded-lg transition-colors ${
                            index === 0 ? 'bg-yellow-500/10 border border-yellow-500/30' :
                            index === 1 ? 'bg-gray-300/10 border border-gray-400/30' :
                            index === 2 ? 'bg-orange-500/10 border border-orange-500/30' :
                            'bg-muted/50'
                          }`}
                        >
                          {/* Rank */}
                          <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg">
                            {index === 0 ? (
                              <Crown className="h-6 w-6 text-yellow-500" />
                            ) : index === 1 ? (
                              <Medal className="h-6 w-6 text-gray-400" />
                            ) : index === 2 ? (
                              <Medal className="h-6 w-6 text-orange-500" />
                            ) : (
                              <span className="text-muted-foreground">#{index + 1}</span>
                            )}
                          </div>

                          {/* Creator Info */}
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">{creator.username}</div>
                            <div className="text-xs text-muted-foreground">
                              {creator.meme_count} memes • {creator.total_comments} comments
                            </div>
                          </div>

                          {/* Stats */}
                          <div className="text-right flex-shrink-0">
                            <div className="font-bold text-yellow-500 flex items-center justify-end gap-1">
                              <Coins className="h-4 w-4" />
                              {creator.total_donations.toFixed(3)} SOL
                            </div>
                            <div className="text-xs text-muted-foreground">
                              received
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Memes;