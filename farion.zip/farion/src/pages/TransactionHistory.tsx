import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import WalletSelector from '@/components/WalletSelector';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  History, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle, 
  XCircle,
  AlertTriangle,
  ExternalLink,
  Wallet
} from 'lucide-react';

interface Loan {
  id: string;
  borrower_wallet: string;
  borrower_username: string | null;
  collateral_sol: number;
  loan_amount_sol: number;
  interest_rate: number;
  duration_days: number;
  status: string;
  created_at: string;
  repaid_at: string | null;
  collateral_tx_signature: string | null;
  repayment_tx_signature: string | null;
}

interface P2PTrade {
  id: string;
  seller_wallet: string;
  seller_username: string | null;
  buyer_wallet: string | null;
  buyer_username: string | null;
  sol_amount: number;
  fiat_amount: number;
  fiat_currency: string;
  escrow_status: string;
  created_at: string;
  completed_at: string | null;
  escrow_tx_signature: string | null;
}

const TransactionHistory = () => {
  const { walletAddress, connected } = useMultiWallet();
  const [loans, setLoans] = useState<Loan[]>([]);
  const [trades, setTrades] = useState<P2PTrade[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (connected && walletAddress) {
      loadTransactions();
    }
  }, [connected, walletAddress]);

  const loadTransactions = async () => {
    if (!walletAddress) return;
    setLoading(true);

    try {
      // Load user's loans
      const { data: loansData } = await supabase
        .from('loans')
        .select('*')
        .eq('borrower_wallet', walletAddress)
        .order('created_at', { ascending: false });

      // Load user's P2P trades (as seller or buyer)
      const { data: tradesData } = await supabase
        .from('p2p_trades')
        .select('*')
        .or(`seller_wallet.eq.${walletAddress},buyer_wallet.eq.${walletAddress}`)
        .order('created_at', { ascending: false });

      setLoans(loansData || []);
      setTrades(tradesData || []);
    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline', icon: React.ReactNode }> = {
      pending: { variant: 'secondary', icon: <Clock className="w-3 h-3" /> },
      active: { variant: 'default', icon: <CheckCircle className="w-3 h-3" /> },
      repaid: { variant: 'default', icon: <CheckCircle className="w-3 h-3" /> },
      defaulted: { variant: 'destructive', icon: <XCircle className="w-3 h-3" /> },
      open: { variant: 'secondary', icon: <Clock className="w-3 h-3" /> },
      locked: { variant: 'default', icon: <Wallet className="w-3 h-3" /> },
      completed: { variant: 'default', icon: <CheckCircle className="w-3 h-3" /> },
      disputed: { variant: 'destructive', icon: <AlertTriangle className="w-3 h-3" /> },
      cancelled: { variant: 'outline', icon: <XCircle className="w-3 h-3" /> },
    };

    const config = variants[status] || { variant: 'outline' as const, icon: null };
    
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        {config.icon}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const openExplorer = (signature: string) => {
    window.open(`https://solscan.io/tx/${signature}`, '_blank');
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 py-8">
          <WalletSelector />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UnifiedNavigation />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="flex items-center gap-3">
            <History className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Transaction History</h1>
          </div>

          <Tabs defaultValue="loans" className="w-full">
            <TabsList className="grid w-full grid-cols-2 max-w-md">
              <TabsTrigger value="loans">Loans ({loans.length})</TabsTrigger>
              <TabsTrigger value="trades">P2P Trades ({trades.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="loans" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wallet className="w-5 h-5" />
                    Loan Transactions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="text-center py-8 text-muted-foreground">Loading...</div>
                  ) : loans.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No loan transactions found
                    </div>
                  ) : (
                    <ScrollArea className="h-[500px]">
                      <div className="space-y-4">
                        {loans.map((loan) => (
                          <motion.div
                            key={loan.id}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="p-4 rounded-lg border bg-card"
                          >
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <ArrowUpRight className="w-4 h-4 text-orange-500" />
                                  <span className="font-medium">Collateral Deposit</span>
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {formatDate(loan.created_at)}
                                </p>
                              </div>
                              {getStatusBadge(loan.status)}
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                              <div>
                                <span className="text-muted-foreground">Collateral:</span>
                                <span className="ml-2 font-medium">{loan.collateral_sol} SOL</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Loan:</span>
                                <span className="ml-2 font-medium">{loan.loan_amount_sol} SOL</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Interest:</span>
                                <span className="ml-2">{loan.interest_rate}%</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Duration:</span>
                                <span className="ml-2">{loan.duration_days} days</span>
                              </div>
                            </div>

                            {loan.collateral_tx_signature && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openExplorer(loan.collateral_tx_signature!)}
                                className="mr-2"
                              >
                                <ExternalLink className="w-3 h-3 mr-1" />
                                Collateral TX
                              </Button>
                            )}
                            {loan.repayment_tx_signature && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openExplorer(loan.repayment_tx_signature!)}
                              >
                                <ExternalLink className="w-3 h-3 mr-1" />
                                Repayment TX
                              </Button>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="trades" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowDownLeft className="w-5 h-5" />
                    P2P Trade Transactions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="text-center py-8 text-muted-foreground">Loading...</div>
                  ) : trades.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No P2P trade transactions found
                    </div>
                  ) : (
                    <ScrollArea className="h-[500px]">
                      <div className="space-y-4">
                        {trades.map((trade) => {
                          const isSeller = trade.seller_wallet === walletAddress;
                          return (
                            <motion.div
                              key={trade.id}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="p-4 rounded-lg border bg-card"
                            >
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <div className="flex items-center gap-2 mb-1">
                                    {isSeller ? (
                                      <ArrowUpRight className="w-4 h-4 text-green-500" />
                                    ) : (
                                      <ArrowDownLeft className="w-4 h-4 text-blue-500" />
                                    )}
                                    <span className="font-medium">
                                      {isSeller ? 'Selling SOL' : 'Buying SOL'}
                                    </span>
                                  </div>
                                  <p className="text-sm text-muted-foreground">
                                    {formatDate(trade.created_at)}
                                  </p>
                                </div>
                                {getStatusBadge(trade.escrow_status)}
                              </div>

                              <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                                <div>
                                  <span className="text-muted-foreground">SOL Amount:</span>
                                  <span className="ml-2 font-medium">{trade.sol_amount} SOL</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Fiat Amount:</span>
                                  <span className="ml-2 font-medium">
                                    {trade.fiat_amount} {trade.fiat_currency}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">
                                    {isSeller ? 'Buyer:' : 'Seller:'}
                                  </span>
                                  <span className="ml-2">
                                    {isSeller 
                                      ? (trade.buyer_username || trade.buyer_wallet?.slice(0, 8) + '...' || 'Pending')
                                      : (trade.seller_username || trade.seller_wallet.slice(0, 8) + '...')
                                    }
                                  </span>
                                </div>
                                {trade.completed_at && (
                                  <div>
                                    <span className="text-muted-foreground">Completed:</span>
                                    <span className="ml-2">{formatDate(trade.completed_at)}</span>
                                  </div>
                                )}
                              </div>

                              {trade.escrow_tx_signature && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => openExplorer(trade.escrow_tx_signature!)}
                                >
                                  <ExternalLink className="w-3 h-3 mr-1" />
                                  View on Explorer
                                </Button>
                              )}
                            </motion.div>
                          );
                        })}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
};

export default TransactionHistory;
