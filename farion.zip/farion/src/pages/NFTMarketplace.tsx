import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Search, Filter, ShoppingBag, Zap, TrendingUp, Star, Clock, Shield, Coins, Sparkles } from 'lucide-react';
import { Connection, PublicKey, SystemProgram, Transaction, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom';
import { supabase } from '@/integrations/supabase/client';
import { useMultiWallet } from '@/contexts/MultiWalletContext';
import { useToast } from '@/hooks/use-toast';
import UnifiedNavigation from '@/components/UnifiedNavigation';
import NFTCard from '@/components/NFTCard';
import NFTOwnership from '@/components/NFTOwnership';
import WalletConnectionPrompt from '@/components/WalletConnectionPrompt';

interface NFTItem {
  id: string;
  name: string;
  description: string;
  boost_type: string;
  boost_value: number;
  price_sol: number;
  rarity: string;
  is_available: boolean;
  purchased_by_wallet?: string;
  purchased_at?: string;
}

interface UserNFT {
  id: string;
  nft_id: string;
  nft: NFTItem;
  is_active: boolean;
  activated_at: string | null;
}

const NFTMarketplace = () => {
  const [nftItems, setNftItems] = useState<NFTItem[]>([]);
  const [userNFTs, setUserNFTs] = useState<UserNFT[]>([]);
  const [filteredItems, setFilteredItems] = useState<NFTItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedRarity, setSelectedRarity] = useState('all');
  const [sortBy, setSortBy] = useState('price_asc');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('marketplace');
  const [purchasing, setPurchasing] = useState<string | null>(null);
  
  const { walletAddress, username, connected, selectedWallet } = useMultiWallet();
  const { toast } = useToast();

  // Farion treasury wallet address
  const TREASURY_WALLET = 'HuTQzoz9Zh4vM1MtcESj9PDs95hbPhoG2eJFh8fjNK96';
  
  // Use more reliable RPC endpoint with fallback
  const connection = new Connection('https://solana-mainnet.g.alchemy.com/v2/alch-demo', 'confirmed');

  const categories = [
    { value: 'all', label: 'All Boosts', icon: ShoppingBag },
    { value: 'staking_apy', label: 'APY Boost', icon: TrendingUp },
    { value: 'jackpot_luck', label: 'Jackpot Luck', icon: Star },
    { value: 'coin_multiplier', label: 'Coin Multiplier', icon: Coins },
  ];

  const rarities = [
    { value: 'all', label: 'All Rarities' },
    { value: 'common', label: 'Common' },
    { value: 'rare', label: 'Rare' },
    { value: 'epic', label: 'Epic' },
    { value: 'legendary', label: 'Legendary' },
  ];

  useEffect(() => {
    fetchNFTItems();
    if (connected && walletAddress) {
      fetchUserNFTs();
    }
  }, [connected, walletAddress]);

  useEffect(() => {
    filterAndSortItems();
  }, [nftItems, searchQuery, selectedCategory, selectedRarity, sortBy]);

  const fetchNFTItems = async () => {
    try {
      const { data, error } = await supabase
        .from('nft_collections')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;
      setNftItems(data || []);
    } catch (error) {
      console.error('Error fetching NFT items:', error);
      toast({
        title: "Error",
        description: "Failed to load NFT marketplace",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchUserNFTs = async () => {
    if (!walletAddress) return;
    
    try {
      const { data, error } = await supabase
        .from('nft_purchases')
        .select(`
          *,
          nft:nft_collections(*)
        `)
        .eq('wallet_address', walletAddress)
        .order('purchased_at', { ascending: false });

      if (error) throw error;
      setUserNFTs(data || []);
    } catch (error) {
      console.error('Error fetching user NFTs:', error);
    }
  };

  const filterAndSortItems = () => {
    let filtered = [...nftItems];

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item => item.boost_type === selectedCategory);
    }

    // Rarity filter
    if (selectedRarity !== 'all') {
      filtered = filtered.filter(item => item.rarity === selectedRarity);
    }

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price_asc':
          return a.price_sol - b.price_sol;
        case 'price_desc':
          return b.price_sol - a.price_sol;
        case 'rarity':
          const rarityOrder = { 'legendary': 4, 'epic': 3, 'rare': 2, 'common': 1 };
          return rarityOrder[b.rarity as keyof typeof rarityOrder] - rarityOrder[a.rarity as keyof typeof rarityOrder];
        case 'boost':
          return b.boost_value - a.boost_value;
        default:
          return 0;
      }
    });

    setFilteredItems(filtered);
  };

  const handlePurchase = async (nftId: string) => {
    if (!connected || !walletAddress || !username) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to purchase NFTs",
        variant: "destructive",
      });
      return;
    }

    const nft = nftItems.find(item => item.id === nftId);
    if (!nft) return;

    setPurchasing(nftId);

    try {
      // Use the selected wallet adapter from context
      if (!selectedWallet?.adapter) {
        throw new Error('Wallet not initialized');
      }

      if (!selectedWallet.adapter.publicKey) {
        throw new Error('Wallet not connected properly');
      }

      // Check SOL balance
      const balance = await connection.getBalance(selectedWallet.adapter.publicKey);
      const balanceInSol = balance / LAMPORTS_PER_SOL;
      
      if (balanceInSol < nft.price_sol) {
        toast({
          title: "Insufficient Balance",
          description: `You need ${nft.price_sol} SOL but only have ${balanceInSol.toFixed(4)} SOL`,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Creating Transaction",
        description: `Preparing transfer of ${nft.price_sol} SOL to purchase ${nft.name}`,
      });

      // Create transfer instruction
      const treasuryPubkey = new PublicKey(TREASURY_WALLET);
      const lamports = Math.floor(nft.price_sol * LAMPORTS_PER_SOL);
      
      const transferInstruction = SystemProgram.transfer({
        fromPubkey: selectedWallet.adapter.publicKey,
        toPubkey: treasuryPubkey,
        lamports: lamports,
      });

      // Create transaction
      const transaction = new Transaction().add(transferInstruction);
      transaction.feePayer = selectedWallet.adapter.publicKey;
      
      // Get recent blockhash
      const { blockhash } = await connection.getLatestBlockhash();
      transaction.recentBlockhash = blockhash;

      toast({
        title: "Waiting for Approval",
        description: "Please approve the transaction in your Phantom wallet",
      });

      // Sign and send transaction
      const signedTransaction = await selectedWallet.adapter.sendTransaction!(transaction, connection);
      
      toast({
        title: "Transaction Sent",
        description: "Transaction sent and awaiting confirmation...",
      });

      // Wait for confirmation
      const confirmation = await connection.confirmTransaction(signedTransaction, 'confirmed');
      
      if (confirmation.value.err) {
        throw new Error('Transaction failed');
      }

      toast({
        title: "Transaction Confirmed",
        description: `Payment successful! Recording purchase...`,
      });

      // Record the purchase in database
      const { error: purchaseError } = await supabase
        .from('nft_purchases')
        .insert({
          nft_id: nftId,
          wallet_address: walletAddress,
          username: username,
          purchase_price_sol: nft.price_sol,
          transaction_hash: signedTransaction,
          is_active: true,
          activated_at: new Date().toISOString()
        });

      if (purchaseError) throw purchaseError;

      // Mark NFT as taken and update ownership
      const { error: updateError } = await supabase
        .from('nft_collections')
        .update({ 
          is_available: false,
          purchased_by_wallet: walletAddress,
          purchased_at: new Date().toISOString()
        })
        .eq('id', nftId);

      if (updateError) throw updateError;

      toast({
        title: "Purchase Successful!",
        description: `You now own ${nft.name}. Check your inventory to activate it.`,
      });

      // Refresh data
      fetchNFTItems();
      fetchUserNFTs();
      
    } catch (error: any) {
      console.error('Error purchasing NFT:', error);
      
      if (error.message?.includes('User rejected')) {
        toast({
          title: "Transaction Cancelled",
          description: "You cancelled the transaction",
          variant: "destructive",
        });
      } else if (error.message?.includes('Insufficient')) {
        toast({
          title: "Insufficient Balance",
          description: "You don't have enough SOL for this purchase",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Purchase Failed",
          description: `Transaction failed: ${error.message || 'Please try again'}`,
          variant: "destructive",
        });
      }
    } finally {
      setPurchasing(null);
    }
  };

  const handleActivateBoost = async (purchaseId: string) => {
    if (!walletAddress) return;

    try {
      const { error } = await supabase
        .from('nft_purchases')
        .update({ 
          is_active: true,
          activated_at: new Date().toISOString()
        })
        .eq('id', purchaseId);

      if (error) throw error;

      toast({
        title: "Boost Activated!",
        description: "Your NFT boost is now active and providing benefits.",
      });

      fetchUserNFTs();
    } catch (error) {
      console.error('Error activating boost:', error);
      toast({
        title: "Activation Failed",
        description: "Failed to activate boost. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen relative">
        <UnifiedNavigation />
        <div className="container mx-auto px-4 pt-32 pb-16">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      <UnifiedNavigation />
      
      <div className="container mx-auto px-4 pt-32 pb-16">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-foreground mb-4">🛒 NFT Boost</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Purchase exclusive boost to enhance your Farion experience. 
            From coin multipliers to staking APY boosts, find the perfect enhancement for your strategy.
          </p>
        </motion.div>

        {!connected && (
          <div className="mb-8">
            <WalletConnectionPrompt 
              title="Connect Wallet to Shop"
              description="Connect your wallet to browse and purchase boost"
            />
          </div>
        )}

        <Tabs defaultValue="marketplace" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
            <TabsTrigger value="inventory">My Inventory</TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace" className="space-y-8">
            {/* Filters and Search */}
            <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-lg p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search NFTs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
                >
                  {categories.map(category => (
                    <option key={category.value} value={category.value}>
                      {category.label}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedRarity}
                  onChange={(e) => setSelectedRarity(e.target.value)}
                  className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
                >
                  {rarities.map(rarity => (
                    <option key={rarity.value} value={rarity.value}>
                      {rarity.label}
                    </option>
                  ))}
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
                >
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="rarity">Rarity</option>
                  <option value="boost">Boost Value</option>
                </select>
              </div>

              <div className="text-sm text-muted-foreground">
                Showing {filteredItems.length} of {nftItems.length} NFTs
              </div>
            </div>

            {/* NFT Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map((nft, index) => (
                <motion.div
                  key={nft.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  {nft.purchased_by_wallet ? (
                    <Card className="p-4 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-orange-500/20 z-0" />
                      <div className="relative z-10">
                        <Badge className="mb-2 bg-red-500 text-white">TAKEN</Badge>
                        <h3 className="font-semibold text-lg mb-2">{nft.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{nft.description}</p>
                        <div className="text-xs text-muted-foreground">
                          Owned by: {nft.purchased_by_wallet.slice(0, 8)}...{nft.purchased_by_wallet.slice(-4)}
                        </div>
                      </div>
                    </Card>
                  ) : (
                    <NFTCard
                      nft={nft}
                      index={index}
                      onPurchase={handlePurchase}
                      isConnected={connected}
                      isPurchasing={purchasing === nft.id}
                    />
                  )}
                </motion.div>
              ))}
            </div>

            {filteredItems.length === 0 && (
              <div className="text-center py-12">
                <ShoppingBag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No NFTs Found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search criteria or browse different categories.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="inventory">
            <NFTOwnership 
              userNFTs={userNFTs}
              onActivateBoost={handleActivateBoost}
              isConnected={connected}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default NFTMarketplace;