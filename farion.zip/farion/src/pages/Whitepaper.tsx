import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Zap, Shield, Coins, Users, Trophy, Rocket, Lock, Code, TrendingUp } from 'lucide-react';
import Footer from '@/components/Footer';

const Whitepaper = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </div>
      </header>

      {/* Cover Section */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-background">
        <div className="container mx-auto px-4 text-center">
          <motion.img 
            src="/farion-logo.png" 
            alt="Farion Logo"
            className="w-32 h-32 mx-auto mb-8"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          />
          <motion.h1 
            className="text-5xl md:text-6xl font-bold text-primary mb-4"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            FARION
          </motion.h1>
          <motion.p 
            className="text-2xl md:text-3xl text-muted-foreground mb-6"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            Next-Generation Fair Launch Token Launchpad
          </motion.p>
          <motion.p 
            className="text-lg text-muted-foreground"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Built on Solana • Version 1.0 • January 2025
          </motion.p>
        </div>
      </section>

      {/* Content */}
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        {/* Abstract */}
        <Section title="Abstract" icon={<Zap className="w-6 h-6" />}>
          <p>
            Farion is a revolutionary token launchpad built on the Solana blockchain, designed to democratize 
            token creation and trading. By implementing fair launch mechanics, transparent bonding curves, 
            and creator-friendly fee structures, Farion addresses the fundamental problems plaguing the 
            current memecoin and token launch ecosystem.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <StatCard label="Creation Fee" value="0.01 SOL" />
            <StatCard label="Buy Fee" value="0%" />
            <StatCard label="Sell Fee" value="1%" />
            <StatCard label="Graduation" value="85 SOL" />
          </div>
        </Section>

        {/* The Problem */}
        <Section title="The Problem" icon={<Shield className="w-6 h-6" />}>
          <p className="mb-4">
            The current token launch landscape is plagued by several critical issues:
          </p>
          <ul className="space-y-3">
            <li className="flex items-start gap-3">
              <span className="text-destructive font-bold">•</span>
              <span><strong>Unfair Advantages:</strong> Insider trading, pre-sales, and team allocations that disadvantage regular users</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-destructive font-bold">•</span>
              <span><strong>Rug Pull Vulnerabilities:</strong> Lack of transparency and security measures enabling malicious actors</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-destructive font-bold">•</span>
              <span><strong>High Barriers to Entry:</strong> Complex token creation processes and expensive launch costs</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-destructive font-bold">•</span>
              <span><strong>Opaque Pricing:</strong> Unclear price discovery mechanisms that confuse traders</span>
            </li>
          </ul>
        </Section>

        {/* Our Solution */}
        <Section title="Our Solution" icon={<Rocket className="w-6 h-6" />}>
          <div className="grid md:grid-cols-2 gap-6">
            <SolutionCard 
              title="Fair Launch" 
              description="No presales, no team allocations. Everyone starts equal with the same opportunity."
            />
            <SolutionCard 
              title="Transparent Pricing" 
              description="Mathematical bonding curves ensure predictable, fair price discovery."
            />
            <SolutionCard 
              title="Creator Rewards" 
              description="Customizable creator fees (0-5%) reward token creators for their work."
            />
            <SolutionCard 
              title="Security First" 
              description="Escrow-protected trades, no private keys in code, and secure wallet integration."
            />
          </div>
        </Section>

        {/* Token Launchpad */}
        <Section title="Token Launchpad" icon={<Coins className="w-6 h-6" />}>
          <p className="mb-6">
            Creating a token on Farion is simple, affordable, and fair. Our launchpad ensures every token 
            starts with equal opportunity.
          </p>
          <div className="bg-card rounded-xl p-6 border border-border">
            <h4 className="font-bold text-lg mb-4">Launch Parameters</h4>
            <div className="space-y-3">
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Creation Fee</span>
                <span className="font-mono font-bold">0.01 SOL</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Total Supply</span>
                <span className="font-mono font-bold">1,000,000,000 tokens</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="text-muted-foreground">Creator Fee</span>
                <span className="font-mono font-bold">0-5% (customizable)</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-muted-foreground">Initial Price</span>
                <span className="font-mono font-bold">Bonding Curve</span>
              </div>
            </div>
          </div>
        </Section>

        {/* Bonding Curve */}
        <Section title="Bonding Curve Trading" icon={<TrendingUp className="w-6 h-6" />}>
          <p className="mb-6">
            Farion uses a mathematical bonding curve to determine token prices. This ensures transparent, 
            predictable pricing that cannot be manipulated.
          </p>
          <div className="bg-card rounded-xl p-6 border border-border font-mono text-center mb-6">
            <p className="text-lg mb-2">Price Formula:</p>
            <p className="text-2xl text-primary">P = k × S²</p>
            <p className="text-sm text-muted-foreground mt-2">
              Where P = Price, k = Constant, S = Current Supply
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-accent/50 rounded-lg p-4">
              <h5 className="font-bold text-primary mb-2">Buy Trades</h5>
              <p className="text-sm">0% platform fee - maximize your investment</p>
            </div>
            <div className="bg-accent/50 rounded-lg p-4">
              <h5 className="font-bold text-primary mb-2">Sell Trades</h5>
              <p className="text-sm">1% platform fee - sustainable revenue model</p>
            </div>
          </div>
        </Section>

        {/* Graduation System */}
        <Section title="Graduation System" icon={<Trophy className="w-6 h-6" />}>
          <p className="mb-6">
            When a token's bonding curve reaches 85 SOL in liquidity, it automatically "graduates" 
            to Raydium DEX for broader market access.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-4">
            <div className="bg-card rounded-xl p-6 border border-border text-center flex-1">
              <div className="text-3xl font-bold text-primary mb-2">85 SOL</div>
              <div className="text-sm text-muted-foreground">Graduation Threshold</div>
            </div>
            <div className="text-2xl">→</div>
            <div className="bg-card rounded-xl p-6 border border-border text-center flex-1">
              <div className="text-3xl font-bold text-primary mb-2">Raydium</div>
              <div className="text-sm text-muted-foreground">DEX Migration</div>
            </div>
            <div className="text-2xl">→</div>
            <div className="bg-card rounded-xl p-6 border border-border text-center flex-1">
              <div className="text-3xl font-bold text-primary mb-2">Locked</div>
              <div className="text-sm text-muted-foreground">LP Tokens Burned</div>
            </div>
          </div>
        </Section>

        {/* Ecosystem Features */}
        <Section title="Ecosystem Features" icon={<Users className="w-6 h-6" />}>
          <div className="grid md:grid-cols-2 gap-6">
            <FeatureCard 
              title="Staking System"
              features={[
                "Lock periods: 30, 60, 90, 120 days",
                "Up to 35% APY",
                "NFT boost multipliers",
                "Auto-compounding rewards"
              ]}
            />
            <FeatureCard 
              title="Jackpot System"
              features={[
                "Live SOL betting",
                "Real-time prize pools",
                "Fair winner selection",
                "NFT luck boosts"
              ]}
            />
            <FeatureCard 
              title="Powerball"
              features={[
                "Holder-exclusive lottery",
                "Every 6 hours draws",
                "Volume-based prizes",
                "FARION holder verification"
              ]}
            />
            <FeatureCard 
              title="NFT Boost Marketplace"
              features={[
                "APY boost NFTs",
                "Jackpot luck boosts",
                "Coin multipliers",
                "4 rarity tiers"
              ]}
            />
            <FeatureCard 
              title="P2P Trading"
              features={[
                "SOL/fiat trading",
                "Escrow protection",
                "Multiple payment methods",
                "Dispute resolution"
              ]}
            />
            <FeatureCard 
              title="Collateralized Loans"
              features={[
                "50% LTV ratio",
                "7-90 day terms",
                "5-15% interest",
                "SOL collateral"
              ]}
            />
          </div>
        </Section>

        {/* Security */}
        <Section title="Security Architecture" icon={<Lock className="w-6 h-6" />}>
          <div className="space-y-4">
            <SecurityItem 
              title="No Private Keys in Code"
              description="All sensitive operations use secure wallet connections. Private keys never touch our servers."
            />
            <SecurityItem 
              title="Escrow System"
              description="All trades and loans are protected by smart escrow mechanisms with automatic release."
            />
            <SecurityItem 
              title="Row-Level Security"
              description="Database access is protected with strict policies ensuring users can only access their own data."
            />
            <SecurityItem 
              title="Multi-Wallet Support"
              description="Integration with Phantom, Solflare, Backpack, and Trust Wallet for maximum compatibility."
            />
          </div>
        </Section>

        {/* Tokenomics */}
        <Section title="Tokenomics" icon={<Coins className="w-6 h-6" />}>
          <div className="bg-card rounded-xl p-6 border border-border mb-6">
            <h4 className="font-bold text-lg mb-2">$FARION Token</h4>
            <p className="text-sm text-muted-foreground font-mono break-all">
              CMXuYtw7JUyoJdGVMvYfjp89GX5eA4o83477HJZypump
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold mb-4">Token Utility</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Platform fee payments</li>
                <li>• Staking rewards</li>
                <li>• Powerball eligibility</li>
                <li>• NFT purchases</li>
                <li>• Future governance</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Fair Launch</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>• No presale</li>
                <li>• No team allocation</li>
                <li>• No insider advantages</li>
                <li>• 100% fair distribution</li>
                <li>• Community-driven</li>
              </ul>
            </div>
          </div>
        </Section>

        {/* Technology */}
        <Section title="Technology Stack" icon={<Code className="w-6 h-6" />}>
          <div className="grid md:grid-cols-2 gap-6">
            <TechCard 
              title="Frontend"
              items={["React 18", "TypeScript", "Tailwind CSS", "Framer Motion"]}
            />
            <TechCard 
              title="Blockchain"
              items={["Solana Mainnet", "SPL Token", "Web3.js", "Wallet Adapter"]}
            />
            <TechCard 
              title="Backend"
              items={["Edge Functions", "PostgreSQL", "Real-time Subscriptions"]}
            />
            <TechCard 
              title="Infrastructure"
              items={["Cloudflare CDN", "DDoS Protection", "99.9% Uptime SLA"]}
            />
          </div>
        </Section>

        {/* Roadmap */}
        <Section title="Roadmap" icon={<Rocket className="w-6 h-6" />}>
          <div className="space-y-8">
            <RoadmapPhase 
              phase="Phase 1"
              status="Completed"
              items={[
                "Core launchpad functionality",
                "Bonding curve trading",
                "Staking system",
                "Jackpot & Powerball",
                "NFT marketplace",
                "P2P trading & loans",
                "Community forum"
              ]}
            />
            <RoadmapPhase 
              phase="Phase 2"
              status="In Progress"
              items={[
                "Real SPL token minting",
                "Raydium DEX migration",
                "Mobile app (PWA)",
                "Advanced analytics"
              ]}
            />
            <RoadmapPhase 
              phase="Phase 3"
              status="Future"
              items={[
                "Cross-chain expansion",
                "DAO governance",
                "Developer API",
                "Institutional features"
              ]}
            />
          </div>
        </Section>

        {/* Disclaimer */}
        <section className="mt-16 p-6 bg-muted/50 rounded-xl border border-border">
          <h3 className="font-bold text-lg mb-4">Legal Disclaimer</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            This whitepaper is for informational purposes only and does not constitute financial advice, 
            investment recommendation, or an offer to sell securities. Cryptocurrency investments carry 
            significant risks including potential loss of principal. Past performance does not guarantee 
            future results. Users should conduct their own research and consult qualified professionals 
            before making investment decisions. Farion makes no guarantees about token performance or 
            platform availability. By using Farion, you acknowledge these risks and agree to our terms 
            of service.
          </p>
        </section>
      </div>

      <Footer />
    </div>
  );
};

// Helper Components
const Section = ({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) => (
  <motion.section 
    className="mb-16"
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5 }}
  >
    <div className="flex items-center gap-3 mb-6">
      <div className="text-primary">{icon}</div>
      <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
    </div>
    <div className="text-muted-foreground leading-relaxed">{children}</div>
  </motion.section>
);

const StatCard = ({ label, value }: { label: string; value: string }) => (
  <div className="bg-card rounded-lg p-4 border border-border text-center">
    <div className="text-xl font-bold text-primary">{value}</div>
    <div className="text-xs text-muted-foreground">{label}</div>
  </div>
);

const SolutionCard = ({ title, description }: { title: string; description: string }) => (
  <div className="bg-card rounded-xl p-6 border border-border">
    <h4 className="font-bold text-lg text-primary mb-2">{title}</h4>
    <p className="text-sm text-muted-foreground">{description}</p>
  </div>
);

const FeatureCard = ({ title, features }: { title: string; features: string[] }) => (
  <div className="bg-card rounded-xl p-6 border border-border">
    <h4 className="font-bold text-lg mb-4">{title}</h4>
    <ul className="space-y-2">
      {features.map((feature, i) => (
        <li key={i} className="text-sm text-muted-foreground flex items-center gap-2">
          <span className="text-primary">✓</span> {feature}
        </li>
      ))}
    </ul>
  </div>
);

const SecurityItem = ({ title, description }: { title: string; description: string }) => (
  <div className="flex items-start gap-4 p-4 bg-card rounded-lg border border-border">
    <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
    <div>
      <h5 className="font-bold mb-1">{title}</h5>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  </div>
);

const TechCard = ({ title, items }: { title: string; items: string[] }) => (
  <div className="bg-card rounded-xl p-6 border border-border">
    <h4 className="font-bold mb-4">{title}</h4>
    <div className="flex flex-wrap gap-2">
      {items.map((item, i) => (
        <span key={i} className="px-3 py-1 bg-accent text-accent-foreground rounded-full text-sm">
          {item}
        </span>
      ))}
    </div>
  </div>
);

const RoadmapPhase = ({ phase, status, items }: { phase: string; status: string; items: string[] }) => (
  <div className="flex gap-6">
    <div className="flex flex-col items-center">
      <div className={`w-4 h-4 rounded-full ${status === 'Completed' ? 'bg-primary' : status === 'In Progress' ? 'bg-yellow-500' : 'bg-muted'}`} />
      <div className="w-0.5 h-full bg-border" />
    </div>
    <div className="flex-1 pb-8">
      <div className="flex items-center gap-3 mb-3">
        <h4 className="font-bold text-lg">{phase}</h4>
        <span className={`px-2 py-0.5 rounded text-xs ${
          status === 'Completed' ? 'bg-primary/20 text-primary' : 
          status === 'In Progress' ? 'bg-yellow-500/20 text-yellow-500' : 
          'bg-muted text-muted-foreground'
        }`}>
          {status}
        </span>
      </div>
      <ul className="space-y-1">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-muted-foreground">• {item}</li>
        ))}
      </ul>
    </div>
  </div>
);

export default Whitepaper;
