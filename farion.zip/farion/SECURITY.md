# Security Policy

## Reporting a Vulnerability

We take security seriously at Farion. If you discover a security vulnerability, please report it responsibly.

### How to Report

1. **Do NOT** open a public GitHub issue for security vulnerabilities
2. Email us at: security@farion.io
3. Include as much detail as possible:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Any suggested fixes

### What to Expect

- **Response Time**: We aim to respond within 48 hours
- **Updates**: We'll keep you informed of our progress
- **Credit**: With your permission, we'll credit you in our security acknowledgments

---

## Security Measures

### Private Key Management
- ✅ All private keys are stored in secure environment variables
- ✅ Never hardcoded in the codebase
- ✅ Rotated regularly

### Escrow System
- ✅ All trades go through a secure escrow wallet
- ✅ Atomic transaction processing
- ✅ No direct user-to-user transfers

### Database Security
- ✅ Row-Level Security (RLS) enabled on all tables
- ✅ Parameterized queries to prevent SQL injection
- ✅ Regular security audits

### Frontend Security
- ✅ No sensitive data exposed in client-side code
- ✅ Wallet connections use standard adapters
- ✅ Transaction signing requires user approval

### API Security
- ✅ CORS properly configured
- ✅ Rate limiting on sensitive endpoints
- ✅ Input validation on all requests

---

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| Latest  | :white_check_mark: |

---

## Acknowledgments

We thank the following individuals for responsibly disclosing security issues:

*No acknowledgments yet. Be the first to help us improve!*

---

## Contact

For security concerns: security@farion.io

For general inquiries: hello@farion.io
